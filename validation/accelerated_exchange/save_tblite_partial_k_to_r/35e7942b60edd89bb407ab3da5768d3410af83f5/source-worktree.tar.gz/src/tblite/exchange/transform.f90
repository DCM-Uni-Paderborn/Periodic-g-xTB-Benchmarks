! This file is part of tblite.
! SPDX-Identifier: LGPL-3.0-or-later

!> Factorized regular-grid Fourier transforms for BvK exchange meshes.
module tblite_exchange_transform
   use, intrinsic :: iso_fortran_env, only : int64
   use mctc_env, only : wp
   implicit none
   private

   !> Dense phase-table/BLAS reference backend.
   integer, parameter, public :: bvk_transform_dense = 1
   !> Separable direct-DFT backend.  This is deliberately not called an FFT:
   !> it factorizes a three-dimensional transform into one-dimensional dense
   !> DFTs, reducing O(Nk**2) character products to O(Nk*sum(nmesh)).
   integer, parameter, public :: bvk_transform_separable_dft = 2

   public :: bvk_separable_k_to_r, bvk_separable_r_to_k

contains

!> Weighted inverse transform from arbitrary input k order to representative
!> order.  With `normalized=.true.`, the uniform 1/Nk BZ normalization is
!> applied.  Setting it false gives the exact adjoint of the unnormalised
!> R-to-k transform.
subroutine bvk_separable_k_to_r(mesh_k, mesh_r, nmesh, input_to_grid, reps, &
   & phase_roots, twist_phase, normalized)
   complex(wp), intent(in) :: mesh_k(:, :)
   complex(wp), intent(out) :: mesh_r(:, :)
   integer, intent(in) :: nmesh(3), input_to_grid(:), reps(:, :)
   complex(wp), intent(in) :: phase_roots(:, :), twist_phase(:)
   logical, intent(in) :: normalized

   integer :: icell, igrid, ik, nk
   real(wp) :: scale
   complex(wp), allocatable :: work_a(:, :), work_b(:, :)

   nk = product(nmesh)
   allocate(work_a(size(mesh_k, 1), nk), work_b(size(mesh_k, 1), nk), &
      & source=(0.0_wp, 0.0_wp))
   scale = 1.0_wp
   if (normalized) scale = 1.0_wp/real(nk, wp)

   ! The external k order may be arbitrary.  Canonical grid order has the
   ! first reciprocal direction as its fastest varying index.
   do ik = 1, nk
      work_a(:, input_to_grid(ik)) = scale*mesh_k(:, ik)
   end do
   call transform_axis(work_a, work_b, nmesh, 1, phase_roots, .false.)
   call transform_axis(work_b, work_a, nmesh, 2, phase_roots, .false.)
   call transform_axis(work_a, work_b, nmesh, 3, phase_roots, .false.)

   ! Representatives need not be returned in canonical grid order.  The
   ! common shifted-mesh character is applied only once after factorization.
   do icell = 1, nk
      igrid = representative_grid_index(reps(:, icell), nmesh)
      mesh_r(:, icell) = conjg(twist_phase(icell))*work_b(:, igrid)
   end do
end subroutine bvk_separable_k_to_r


!> Unnormalised forward transform from arbitrary representative order to the
!> original input k order.  This is the exact inverse/adjoint partner of the
!> normalized k-to-R transform; callers attach k weights to reverse-source
!> adjoints after this routine.
subroutine bvk_separable_r_to_k(mesh_r, mesh_k, nmesh, input_to_grid, reps, &
   & phase_roots, twist_phase)
   complex(wp), intent(in) :: mesh_r(:, :)
   complex(wp), intent(out) :: mesh_k(:, :)
   integer, intent(in) :: nmesh(3), input_to_grid(:), reps(:, :)
   complex(wp), intent(in) :: phase_roots(:, :), twist_phase(:)

   integer :: icell, igrid, ik, nk
   complex(wp), allocatable :: work_a(:, :), work_b(:, :)

   nk = product(nmesh)
   allocate(work_a(size(mesh_r, 1), nk), work_b(size(mesh_r, 1), nk), &
      & source=(0.0_wp, 0.0_wp))
   do icell = 1, nk
      igrid = representative_grid_index(reps(:, icell), nmesh)
      work_a(:, igrid) = twist_phase(icell)*mesh_r(:, icell)
   end do
   call transform_axis(work_a, work_b, nmesh, 1, phase_roots, .true.)
   call transform_axis(work_b, work_a, nmesh, 2, phase_roots, .true.)
   call transform_axis(work_a, work_b, nmesh, 3, phase_roots, .true.)
   do ik = 1, nk
      mesh_k(:, ik) = work_b(:, input_to_grid(ik))
   end do
end subroutine bvk_separable_r_to_k


!> Apply one one-dimensional DFT to all pencils of a canonical 3D mesh.
subroutine transform_axis(input, output, nmesh, idim, phase_roots, forward)
   complex(wp), intent(in) :: input(:, :)
   complex(wp), intent(out) :: output(:, :)
   integer, intent(in) :: nmesh(3), idim
   complex(wp), intent(in) :: phase_roots(:, :)
   logical, intent(in) :: forward

   integer :: coord_in, coord_out, g(3), idx_in, idx_out, root
   integer :: i1, i2, i3, n
   integer(int64) :: root64
   complex(wp) :: phase

   n = nmesh(idim)
   output = (0.0_wp, 0.0_wp)
   do i3 = 0, nmesh(3)-1
      do i2 = 0, nmesh(2)-1
         do i1 = 0, nmesh(1)-1
            g = [i1, i2, i3]
            coord_out = g(idim)
            idx_out = 1 + g(1) + nmesh(1)*(g(2)+nmesh(2)*g(3))
            do coord_in = 0, n-1
               g(idim) = coord_in
               idx_in = 1 + g(1) + nmesh(1)*(g(2)+nmesh(2)*g(3))
               root64 = modulo(int(coord_in, int64)*int(coord_out, int64), &
                  & int(n, int64))
               root = int(root64)
               phase = phase_roots(root+1, idim)
               if (.not.forward) phase = conjg(phase)
               output(:, idx_out) = output(:, idx_out) + phase*input(:, idx_in)
            end do
         end do
      end do
   end do
end subroutine transform_axis


pure integer function representative_grid_index(rep, nmesh) result(index)
   integer, intent(in) :: rep(3), nmesh(3)
   integer :: grid(3)

   grid = modulo(rep, nmesh)
   index = 1 + grid(1) + nmesh(1)*(grid(2)+nmesh(2)*grid(3))
end function representative_grid_index

end module tblite_exchange_transform
