! This file is part of tblite.
! SPDX-Identifier: LGPL-3.0-or-later
!
! tblite is free software: you can redistribute it and/or modify it under
! the terms of the GNU Lesser General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.
!
! tblite is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
! GNU Lesser General Public License for more details.
!
! You should have received a copy of the GNU Lesser General Public License
! along with tblite.  If not, see <https://www.gnu.org/licenses/>.

!> @file tblite/coulomb/charge/effective.f90
!> Provides an effective Coulomb operator for isotropic electrostatic interactions

!> Isotropic second-order electrostatics using an effective Coulomb operator
module tblite_coulomb_charge_effective
   use mctc_env, only : wp
   use mctc_io, only : structure_type
   use mctc_io_math, only : matdet_3x3, matinv_3x3
   use mctc_io_constants, only : pi
   use tblite_blas, only : dot, gemv, symv, gemm
   use tblite_coulomb_cache, only : coulomb_cache
   use tblite_coulomb_charge_type, only : coulomb_charge_type
   use tblite_coulomb_ewald, only : get_dir_cutoff, get_rec_cutoff
   use tblite_cutoff, only : get_lattice_points
   use tblite_scf_potential, only : potential_type
   use tblite_utils_average, only : average_type
   use tblite_wavefunction_type, only : wavefunction_type
   use tblite_wignerseitz, only : wignerseitz_cell, get_wignerseitz_weights
   implicit none
   private

   public :: new_effective_coulomb


   !> Effective, Klopman-Ohno-type, second-order electrostatics
   type, public, extends(coulomb_charge_type) :: effective_coulomb
      !> Averager for the hubbard parameters
      type(average_type), allocatable :: average
      !> CN-dependence of Hubbard parameter for each species
      real(wp), allocatable :: hubbard_cn(:)
      !> Exponent of radius dependent hubbard scaling
      real(wp) :: hubbard_exp
       !> Exponent of Coulomb kernel
       real(wp) :: gexp
    contains
      !> Evaluate Coulomb matrix
      procedure :: get_coulomb_matrix
      !> Evaluate uncontracted derivatives of Coulomb matrix
      procedure :: get_coulomb_derivs
   end type effective_coulomb

   real(wp), parameter :: twopi = 2 * pi
   real(wp), parameter :: sqrtpi = sqrt(pi)
   real(wp), parameter :: eps = sqrt(epsilon(0.0_wp))
   real(wp), parameter :: cn_reg = 1e-6_wp
   character(len=*), parameter :: label = "isotropic Klopman-Ohno-Mataga-Nishimoto electrostatics"

contains

!> Construct new effective electrostatic interaction container
subroutine new_effective_coulomb(self, mol, gexp, hubbard, &
   & average, hubbard_cn, hubbard_exp, refqsh, nshell)
   !> Instance of the electrostatic container
   type(effective_coulomb), intent(out) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Exponent of Coulomb kernel
   real(wp), intent(in) :: gexp
   !> Hubbard parameter for all shells and species
   real(wp), intent(in) :: hubbard(:, :)
   !> Averaging function for Hubbard parameter of a shell-pair
   type(average_type), intent(in) :: average
   !> CN-dependence of Hubbard parameters
   real(wp), intent(in), optional :: hubbard_cn(:)
   !> Exponent of radius-dependent hubbard scaling
   real(wp), intent(in), optional :: hubbard_exp
   !> Shell-resolved reference partial charges
   !> for first/pseudo-second-order offsite tight-binding
   real(wp), intent(in), optional :: refqsh(:)
   !> Number of shells for each species
   integer, intent(in), optional :: nshell(:)

   integer :: mshell
   integer :: isp, jsp, ish, jsh, ind, iat

   self%label = label

   self%shell_resolved = present(nshell)
   if (present(nshell)) then
      mshell = maxval(nshell)
      self%nshell = nshell(mol%id)
   else
      mshell = 1
      self%nshell = spread(1, 1, mol%nat)
   end if
   allocate(self%offset(mol%nat))
   ind = 0
   do iat = 1, mol%nat
      self%offset(iat) = ind
      ind = ind + self%nshell(iat)
   end do

   self%gexp = gexp

   if (present(nshell)) then
      allocate(self%hubbard(mshell, mol%nid))
      do isp = 1, mol%nid
         self%hubbard(:, isp) = 0.0_wp
         do ish = 1, nshell(isp)
            self%hubbard(ish, isp) = hubbard(ish, isp)
         end do
      end do
   else
      allocate(self%hubbard(1, mol%nid))
      do isp = 1, mol%nid
         self%hubbard(1, isp) = hubbard(1, isp)
      end do
   end if

   if (present(hubbard_cn)) then
      self%hubbard_cn = hubbard_cn
      self%cn_dep = .true.
   else
      allocate(self%hubbard_cn(mol%nid))
      self%hubbard_cn = 0.0_wp
      self%cn_dep = .false.
   end if

   if (present(hubbard_exp)) then
      self%hubbard_exp = hubbard_exp
   else
      self%hubbard_exp = 0.0_wp
   end if

   self%average = average

   if (present(refqsh)) then
      self%refqsh = refqsh
   end if

end subroutine new_effective_coulomb


!> Evaluate coulomb matrix
subroutine get_coulomb_matrix(self, mol, cache, amat)
   !> Instance of the electrostatic container
   class(effective_coulomb), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(inout) :: cache
   !> Coulomb matrix
   real(wp), contiguous, intent(out) :: amat(:, :)

   amat(:, :) = 0.0_wp

    if (any(mol%periodic)) then
       call get_amat_3d(mol, self%nshell, self%offset, self%hubbard, &
          & self%hubbard_cn, self%hubbard_exp, self%average, self%gexp, &
          & cache%cn, cache%wsc, cache%alpha, amat)
    else
      call get_amat_0d(mol, self%nshell, self%offset, self%hubbard, &
         & self%hubbard_cn, self%hubbard_exp, self%average, self%gexp, & 
         & cache%cn, amat)
   end if

end subroutine get_coulomb_matrix


!> Get real lattice vectors
subroutine get_dir_trans(lattice, alpha, trans)
   !> Lattice parameters
   real(wp), intent(in) :: lattice(:, :)
   !> Parameter for Ewald summation
   real(wp), intent(in) :: alpha
   !> Translation vectors
   real(wp), allocatable, intent(out) :: trans(:, :)

   call get_lattice_points([.true.], lattice, get_dir_cutoff(alpha, .false.), trans)

end subroutine get_dir_trans

!> Get reciprocal lattice translations
subroutine get_rec_trans(lattice, alpha, volume, trans)
   !> Lattice parameters
   real(wp), intent(in) :: lattice(:, :)
   !> Parameter for Ewald summation
   real(wp), intent(in) :: alpha
   !> Cell volume
   real(wp), intent(in) :: volume
   !> Translation vectors
   real(wp), allocatable, intent(out) :: trans(:, :)

   real(wp) :: rec_lat(3, 3)

    rec_lat = twopi*transpose(matinv_3x3(lattice))
    call get_lattice_points([.true.], rec_lat, get_rec_cutoff(alpha, volume, .false.), trans)

end subroutine get_rec_trans


!> Evaluate Coulomb matrix for finite systems
subroutine get_amat_0d(mol, nshell, offset, hubbard, hubbard_cn, hubbard_exp, &
   & average, gexp, cn, amat)
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Number of shells for each atom
   integer, intent(in) :: nshell(:)
   !> Index offset for each shell
   integer, intent(in) :: offset(:)
   !> Hubbard parameter for each shell
   real(wp), intent(in) :: hubbard(:, :)
   !> CN-dependence of Hubbard parameters
   real(wp), intent(in) :: hubbard_cn(:)
   !> Exponent of radius-dependent hubbard scaling
   real(wp), intent(in) :: hubbard_exp
   !> Averaging function for Hubbard parameter of a shell-pair
   type(average_type), intent(in) :: average
   !> Exponent of Coulomb kernel
   real(wp), intent(in) :: gexp
   !> Coordination number
   real(wp), intent(in) :: cn(:)
   !> Coulomb matrix
   real(wp), intent(inout) :: amat(:, :)

   integer :: iat, jat, izp, jzp, ii, jj, ish, jsh
   real(wp) :: sqrtcni, sqrtcnj, scalei, scalej
   real(wp) :: vec(3), r1, r1g, gam, hubi, hubj, damp, tmp

   !$omp parallel do default(none) schedule(runtime) shared(amat, mol, cn) &
   !$omp shared(nshell, offset, hubbard, hubbard_cn, hubbard_exp, average, gexp) &
   !$omp private(iat, izp, ii, ish, jat, jzp, jj, jsh, scalei, scalej) &
   !$omp private(sqrtcni, sqrtcnj, vec, r1, r1g, damp, hubi, hubj, gam, tmp)
   do iat = 1, mol%nat
      izp = mol%id(iat)
      ii = offset(iat)
      ! Coordination number scaling with regularization
      sqrtcni = sqrt(cn(iat) + cn_reg**2) - cn_reg
      scalei = 1.0_wp + hubbard_cn(izp) * sqrtcni
      do jat = 1, iat-1
         jzp = mol%id(jat)
         jj = offset(jat)
         ! Coordination number scaling with regularization
         sqrtcnj = sqrt(cn(jat) + cn_reg**2) - cn_reg
         scalej = 1.0_wp + hubbard_cn(jzp) * sqrtcnj
         vec = mol%xyz(:, jat) - mol%xyz(:, iat)
         r1 = norm2(vec)
         r1g = r1**gexp
         ! Damping factor for distance-dependent hubbard scaling
         damp = exp (-hubbard_exp * r1)
         do ish = 1, nshell(iat)
            ! CN dependent hubbard parameter
            hubi = hubbard(ish, izp) * scalei
            do jsh = 1, nshell(jat)
               ! CN dependent hubbard parameter
               hubj = hubbard(jsh, jzp) * scalej
               ! Damped average hubbard parameter
               gam = average%value(hubi, hubj) / damp
               ! Effective Coulomb interaction
               tmp = 1.0_wp/(r1g + gam**(-gexp))**(1.0_wp/gexp)
               amat(jj+jsh, ii+ish) = amat(jj+jsh, ii+ish) + tmp
               amat(ii+ish, jj+jsh) = amat(ii+ish, jj+jsh) + tmp
            end do
         end do
      end do
      do ish = 1, nshell(iat)
         hubi = hubbard(ish, izp) * scalei
         do jsh = 1, ish-1
            hubj = hubbard(jsh, izp) * scalei
            ! Diagonal average hubbard parameter
            gam = average%value(hubi, hubj)
            amat(ii+jsh, ii+ish) = amat(ii+jsh, ii+ish) + gam
            amat(ii+ish, ii+jsh) = amat(ii+ish, ii+jsh) + gam
         end do
         amat(ii+ish, ii+ish) = amat(ii+ish, ii+ish) + hubi
      end do
   end do

end subroutine get_amat_0d

!> Evaluate the coulomb matrix for 3D systems
subroutine get_amat_3d(mol, nshell, offset, hubbard, hubbard_cn, hubbard_exp, &
   & average, gexp, cn, wsc, alpha, amat)
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Number of shells per atom
   integer, intent(in) :: nshell(:)
   !> Index offset for each atom
   integer, intent(in) :: offset(:)
   !> Hubbard parameter for each shell
   real(wp), intent(in) :: hubbard(:, :)
   !> CN-dependence of Hubbard parameters
   real(wp), intent(in) :: hubbard_cn(:)
   !> Exponent of radius-dependent hubbard scaling
   real(wp), intent(in) :: hubbard_exp
   !> Averaging function for Hubbard parameter of a shell-pair
   type(average_type), intent(in) :: average
   !> Exponent of the interaction kernel
   real(wp), intent(in) :: gexp
   !> Coordination number
   real(wp), intent(in) :: cn(:)
   !> Wigner-Seitz cell
   type(wignerseitz_cell), intent(in) :: wsc
   !> Convergence factor
   real(wp), intent(in) :: alpha
   !> Coulomb matrix
   real(wp), intent(inout) :: amat(:, :)

   integer :: iat, jat, izp, jzp, img, ii, jj, ish, jsh
   real(wp) :: sqrtcni, sqrtcnj, scalei, scalej
   real(wp) :: vec(3), gam, hubi, hubj, dtmp, rtmp, stmp, vol, aval
   real(wp) :: weight(size(wsc%tridx, 1))
   real(wp), allocatable :: dtrans(:, :), rtrans(:, :)

   vol = abs(matdet_3x3(mol%lattice))
   call get_dir_trans(mol%lattice, alpha, dtrans)
   call get_rec_trans(mol%lattice, alpha, vol, rtrans)

   !$omp parallel do default(none) schedule(runtime) shared(amat) &
   !$omp shared(mol, nshell, offset, hubbard, hubbard_cn, hubbard_exp) &
   !$omp shared(average, gexp, cn, wsc, dtrans, rtrans, alpha, vol) &
   !$omp private(iat, izp, jat, jzp, ii, jj, ish, jsh, scalei, scalej) &
   !$omp private(sqrtcni, sqrtcnj, hubi, hubj, gam, weight, vec, dtmp, rtmp, stmp, aval)
   do iat = 1, mol%nat
      izp = mol%id(iat)
      ii = offset(iat)
      ! Coordination number scaling with regularization
      sqrtcni = sqrt(cn(iat) + cn_reg**2) - cn_reg
      scalei = 1.0_wp + hubbard_cn(izp) * sqrtcni
      do jat = 1, iat-1
         jzp = mol%id(jat)
         jj = offset(jat)
         ! Coordination number scaling with regularization
         sqrtcnj = sqrt(cn(jat) + cn_reg**2) - cn_reg
         scalej = 1.0_wp + hubbard_cn(jzp) * sqrtcnj
         vec = mol%xyz(:, iat) - mol%xyz(:, jat)
         call get_wignerseitz_weights(wsc, jat, iat, vec, weight)
         call get_amat_dir_3d(vec, alpha, dtrans, dtmp)
         call get_amat_rec_3d(vec, vol, alpha, rtrans, rtmp)
         do img = 1, wsc%nimg(jat, iat)
            vec = mol%xyz(:, iat) - mol%xyz(:, jat) - wsc%trans(:, wsc%tridx(img, jat, iat))
            do ish = 1, nshell(iat)
               hubi = hubbard(ish, izp) * scalei
               do jsh = 1, nshell(jat)
                  hubj = hubbard(jsh, jzp) * scalej
                  gam = average%value(hubi, hubj)
                  call get_amat_wsc_3d(vec, gam, hubbard_exp, gexp, stmp)
                  aval = (dtmp + rtmp + stmp) * weight(img)
                  amat(jj+jsh, ii+ish) = amat(jj+jsh, ii+ish) + aval
                  amat(ii+ish, jj+jsh) = amat(ii+ish, jj+jsh) + aval
               end do
            end do
         end do
      end do

      vec = 0.0_wp
      call get_wignerseitz_weights(wsc, iat, iat, vec, weight)
      call get_amat_dir_3d(vec, alpha, dtrans, dtmp)
      call get_amat_rec_3d(vec, vol, alpha, rtrans, rtmp)
      rtmp = rtmp - 2 * alpha / sqrtpi
      do img = 1, wsc%nimg(iat, iat)
         vec = wsc%trans(:, wsc%tridx(img, iat, iat))
         do ish = 1, nshell(iat)
            hubi = hubbard(ish, izp) * scalei
            do jsh = 1, ish-1
               hubj = hubbard(jsh, izp) * scalei
               gam = average%value(hubi, hubj)
               call get_amat_wsc_3d(vec, gam, hubbard_exp, gexp, stmp)
               aval = (dtmp + rtmp + stmp + gam) * weight(img)
               amat(ii+jsh, ii+ish) = amat(ii+jsh, ii+ish) + aval
               amat(ii+ish, ii+jsh) = amat(ii+ish, ii+jsh) + aval
            end do
            gam = hubi
            call get_amat_wsc_3d(vec, gam, hubbard_exp, gexp, stmp)
            aval = (dtmp + rtmp + stmp + gam) * weight(img)
            amat(ii+ish, ii+ish) = amat(ii+ish, ii+ish) + aval
         end do
      end do

   end do

end subroutine get_amat_3d

!> Calculate direct space Ewald contribution for a pair under 3D periodic boundary conditions
subroutine get_amat_dir_3d(rij, alp, trans, amat)
   !> Distance between pair
   real(wp), intent(in) :: rij(3)
   !> Convergence factor
   real(wp), intent(in) :: alp
   !> Translation vectors to consider
   real(wp), intent(in) :: trans(:, :)
   !> Interaction matrix element
   real(wp), intent(out) :: amat

   integer :: itr
   real(wp) :: vec(3), r1

   amat = 0.0_wp

   do itr = 1, size(trans, 2)
      vec(:) = rij + trans(:, itr)
      r1 = norm2(vec)
      if (r1 < eps) cycle
      amat = amat + erfc(alp*r1)/r1
   end do

end subroutine get_amat_dir_3d

!> Calculate Wigner-Seitz averaged short range correction for a pair
subroutine get_amat_wsc_3d(rij, gam, hubbard_exp, gexp, amat)
   !> Distance between pair
   real(wp), intent(in) :: rij(3)
   !> Hubbard parameter
   real(wp), intent(in) :: gam
   !> Exponent of radius-dependent hubbard scaling
   real(wp), intent(in) :: hubbard_exp
   !> Exponent for interaction kernel
   real(wp), intent(in) :: gexp
   !> Interaction matrix element
   real(wp), intent(out) :: amat

   real(wp) :: r1, damp

   amat = 0.0_wp

   r1 = norm2(rij)
   if (r1 < eps) return
   damp = exp(-gexp * hubbard_exp * r1)
   amat = 1.0_wp/(r1**gexp + gam**(-gexp) * damp)**(1.0_wp/gexp) - 1.0_wp/r1

end subroutine get_amat_wsc_3d

!> Calculate reciprocal space contributions for a pair under 3D periodic boundary conditions
subroutine get_amat_rec_3d(rij, vol, alp, trans, amat)
   !> Distance between pair
   real(wp), intent(in) :: rij(3)
   !> Volume of cell
   real(wp), intent(in) :: vol
   !> Convergence factor
   real(wp), intent(in) :: alp
   !> Translation vectors to consider
   real(wp), intent(in) :: trans(:, :)
   !> Interaction matrix element
   real(wp), intent(out) :: amat

   integer :: itr
   real(wp) :: fac, vec(3), g2, gv, expk, cosk

   amat = 0.0_wp
   fac = 4*pi/vol

   do itr = 1, size(trans, 2)
      vec(:) = trans(:, itr)
      g2 = dot_product(vec, vec)
      if (g2 < eps) cycle
      gv = dot_product(rij, vec)
      expk = fac * exp(-0.25_wp*g2/(alp*alp))/g2
      cosk = cos(gv) * expk
      amat = amat + cosk
   end do

end subroutine get_amat_rec_3d


!> Evaluate uncontracted derivatives of Coulomb matrix
subroutine get_coulomb_derivs(self, mol, cache, qat, qsh, dadr, dadL, &
   & atrace, dadcn, datracedcn)
   !> Instance of the electrostatic container
   class(effective_coulomb), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(inout) :: cache
   !> Atomic partial charges
   real(wp), intent(in) :: qat(:)
   !> Shell-resolved partial charges
   real(wp), intent(in) :: qsh(:)
   !> Derivative of interactions with respect to cartesian displacements
   real(wp), contiguous, intent(out) :: dadr(:, :, :)
   !> Derivative of interactions with respect to strain deformations
   real(wp), contiguous, intent(out) :: dadL(:, :, :)
   !> On-site derivatives with respect to cartesian displacements
   real(wp), contiguous, intent(out) :: atrace(:, :)
   !> Coulomb matrix derivative w.r.t. the coordination numbers
   real(wp), contiguous, intent(out) :: dadcn(:, :)
   !> On-site derivatives with respect to coordination numbers
   real(wp), contiguous, intent(out) :: datracedcn(:)

   if(self%shell_resolved) then
      if (any(mol%periodic)) then
         if (allocated(self%refqsh)) then
            call get_damat_3d(mol, self%nshell, self%offset, self%hubbard, & 
               & self%hubbard_cn, self%hubbard_exp, self%average, self%gexp, &
               & cache%cn, cache%wsc, cache%alpha, qsh, &
               & dadr, dadL, atrace, dadcn, datracedcn, &
               & self%refqsh, cache%sigma_self)
         else
            call get_damat_3d(mol, self%nshell, self%offset, self%hubbard, & 
               & self%hubbard_cn, self%hubbard_exp, self%average, self%gexp, &
               & cache%cn, cache%wsc, cache%alpha, qsh, &
               & dadr, dadL, atrace, dadcn, datracedcn)
         end if
      else
         call get_damat_0d(mol, self%nshell, self%offset, self%hubbard, & 
            & self%hubbard_cn, self%hubbard_exp, self%average, self%gexp, &
            & cache%cn, qsh, dadr, dadL, atrace, dadcn, datracedcn)
      end if
   else
      if (any(mol%periodic)) then
         call get_damat_3d(mol, self%nshell, self%offset, self%hubbard, &
            & self%hubbard_cn, self%hubbard_exp, self%average, self%gexp, &
            & cache%cn, cache%wsc, cache%alpha, qat, &
            & dadr, dadL, atrace, dadcn, datracedcn)
      else
         call get_damat_0d(mol, self%nshell, self%offset, self%hubbard, &
            & self%hubbard_cn, self%hubbard_exp, self%average, self%gexp, &
            & cache%cn, qat, dadr, dadL, atrace, dadcn, datracedcn)
      end if
   end if 

end subroutine get_coulomb_derivs


!> Evaluate uncontracted derivatives of Coulomb matrix for finite system
subroutine get_damat_0d(mol, nshell, offset, hubbard, hubbard_cn, hubbard_exp, &
   & average, gexp, cn, qvec, dadr, dadL, atrace, dadcn, datracedcn)
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Number of shells for each atom
   integer, intent(in) :: nshell(:)
   !> Index offset for each shell
   integer, intent(in) :: offset(:)
   !> Hubbard parameter for each shell and species
   real(wp), intent(in) :: hubbard(:, :)
   !> CN-dependence of Hubbard parameters
   real(wp), intent(in) :: hubbard_cn(:)
   !> Exponent of radius-dependent hubbard scaling
   real(wp), intent(in) :: hubbard_exp
   !> Averaging function for Hubbard parameter of a shell-pair
   type(average_type), intent(in) :: average
   !> Exponent of Coulomb kernel
   real(wp), intent(in) :: gexp
   !> Coordination number
   real(wp), intent(in) :: cn(:)
   !> Partial charge vector
   real(wp), intent(in) :: qvec(:)
   !> Derivative of interactions with respect to cartesian displacements
   real(wp), intent(out) :: dadr(:, :, :)
   !> Derivative of interactions with respect to strain deformations
   real(wp), intent(out) :: dadL(:, :, :)
   !> On-site derivatives with respect to cartesian displacements
   real(wp), intent(out) :: atrace(:, :)
   !> Coulomb matrix derivative w.r.t. the coordination numbers
   real(wp), intent(out) :: dadcn(:, :)
   !> On-site derivatives with respect to coordination numbers
   real(wp), intent(out) :: datracedcn(:)

   integer :: iat, jat, izp, jzp, ii, jj, ish, jsh
   real(wp) :: vec(3), r1, r1g, damp, hubi, hubj, dhubidcn, dhubjdcn
   real(wp) :: sqrtcni, sqrtcnj, scalei, scalej, dscaleidcn, dscalejdcn 
   real(wp) :: gam, dgami, dgamj, denom, dtmp, dtmpdgam, dG(3), dS(3, 3)
   real(wp), allocatable :: itrace(:, :), didr(:, :, :), didL(:, :, :)
   real(wp), allocatable :: didcn(:, :), ditracedcn(:)

   atrace(:, :) = 0.0_wp
   dadr(:, :, :) = 0.0_wp
   dadL(:, :, :) = 0.0_wp
   dadcn(:, :) = 0.0_wp
   datracedcn(:) = 0.0_wp

   !$omp parallel default(none) &
   !$omp shared(dadr, dadL, atrace, dadcn, datracedcn, mol, qvec, nshell) &
   !$omp shared(offset, hubbard, hubbard_cn, hubbard_exp, average, gexp, cn) &
   !$omp private(iat, izp, ii, ish, jat, jzp, jj, jsh, r1, r1g, vec, damp) &
   !$omp private(sqrtcni, sqrtcnj, scalei, scalej, dscaleidcn, dscalejdcn) &
   !$omp private(hubi, hubj, dhubidcn, dhubjdcn, gam, dgami, dgamj, denom) &
   !$omp private(dtmp, dtmpdgam, dG, dS, itrace, didr, didL, didcn, ditracedcn)
   allocate(itrace, source=atrace)
   allocate(didr, source=dadr)
   allocate(didL, source=dadL)
   allocate(didcn, source=dadcn)
   allocate(ditracedcn, source=datracedcn)
   !$omp do schedule(runtime)
   do iat = 1, mol%nat
      izp = mol%id(iat)
      ii = offset(iat)
      ! Coordination number scaling
      sqrtcni = sqrt(cn(iat) + cn_reg**2) - cn_reg
      scalei = 1.0_wp + hubbard_cn(izp) * sqrtcni
      dscaleidcn = 0.5_wp * hubbard_cn(izp) / (sqrtcni + cn_reg)
      do jat = 1, iat-1
         jzp = mol%id(jat)
         jj = offset(jat)
         ! Coordination number scaling
         sqrtcnj = sqrt(cn(jat) + cn_reg**2) - cn_reg
         scalej = 1.0_wp + hubbard_cn(jzp) * sqrtcnj
         dscalejdcn = 0.5_wp * hubbard_cn(jzp) / (sqrtcnj + cn_reg)
         vec = mol%xyz(:, iat) - mol%xyz(:, jat)
         r1 = norm2(vec)
         r1g = r1**gexp
         ! Damping factor for distance-dependent hubbard scaling
         damp = exp(-hubbard_exp * r1)
         do ish = 1, nshell(iat)
            ! CN dependent hubbard parameter and its CN derivative
            hubi = hubbard(ish, izp) * scalei
            dhubidcn = hubbard(ish, izp) * dscaleidcn
            do jsh = 1, nshell(jat)
               ! CN dependent hubbard parameter and its CN derivative
               hubj = hubbard(jsh, jzp) * scalej
               dhubjdcn = hubbard(jsh, jzp) * dscalejdcn
               ! Damped average hubbard parameter and its CN derivative
               gam = average%value(hubi, hubj) / damp
               dgami = (average%deriv(hubi, hubj) * dhubidcn) / damp
               dgamj = (average%deriv(hubj, hubi) * dhubjdcn) / damp
               ! Chain rule derivative of effective Coulomb interaction
               denom = 1.0_wp / (r1g + gam**(-gexp))**(1.0_wp + 1.0_wp/gexp)
               ! Direct position derivative of the effective Coulomb interaction
               dtmp = -(r1**(gexp-1.0_wp) - hubbard_exp * gam**(-gexp)) * denom
               ! Implicit damped averaged hubbard parameter derivative
               dtmpdgam = gam**(-gexp-1.0_wp) * denom
               dG = dtmp*vec/r1
               dS = spread(dG, 1, 3) * spread(vec, 2, 3)
               ! Build once-contracted derivatives ∂γ · q, including 
               ! only other atom contributions as second order is bilinear in q
               itrace(:, ii+ish) = +dG*qvec(jj+jsh) + itrace(:, ii+ish)
               itrace(:, jj+jsh) = -dG*qvec(ii+ish) + itrace(:, jj+jsh)
               didr(:, iat, jj+jsh) = +dG*qvec(ii+ish) + didr(:, iat, jj+jsh)
               didr(:, jat, ii+ish) = -dG*qvec(jj+jsh) + didr(:, jat, ii+ish)
               didL(:, :, jj+jsh) = +dS*qvec(ii+ish) + didL(:, :, jj+jsh)
               didL(:, :, ii+ish) = +dS*qvec(jj+jsh) + didL(:, :, ii+ish)
               didcn(jat, ii+ish) = +dtmpdgam*dgamj*qvec(jj+jsh) + didcn(jat, ii+ish)
               didcn(iat, jj+jsh) = +dtmpdgam*dgami*qvec(ii+ish) + didcn(iat, jj+jsh)
               ditracedcn(ii+ish) = +dtmpdgam*dgami*qvec(jj+jsh) + ditracedcn(ii+ish)
               ditracedcn(jj+jsh) = +dtmpdgam*dgamj*qvec(ii+ish) + ditracedcn(jj+jsh)
            end do
         end do
      end do
      do ish = 1, nshell(iat)
         ! CN dependent hubbard parameter and its CN derivative
         hubi = hubbard(ish, izp) * scalei
         dhubidcn = hubbard(ish, izp) * dscaleidcn
         do jsh = 1, ish-1
            ! CN dependent hubbard parameter and its CN derivative
            hubj = hubbard(jsh, izp) * scalei
            dhubjdcn = hubbard(jsh, izp) * dscaleidcn
            ! CN derivative of diagonal averaged hubbard parameter
            dgami = average%deriv(hubi, hubj) * dhubidcn
            dgamj = average%deriv(hubj, hubi) * dhubjdcn
            didcn(iat, ii+ish) = +dgami*qvec(ii+jsh) + didcn(iat, ii+ish)
            didcn(iat, ii+jsh) = +dgamj*qvec(ii+ish) + didcn(iat, ii+jsh)
            ditracedcn(ii+ish) = -dgami*qvec(ii+jsh) + ditracedcn(ii+ish)
            ditracedcn(ii+jsh) = -dgamj*qvec(ii+ish) + ditracedcn(ii+jsh)
         end do
         didcn(iat, ii+ish) = +0.5_wp*dhubidcn*qvec(ii+ish) + didcn(iat, ii+ish)
         ditracedcn(ii+ish) = -0.5_wp*dhubidcn*qvec(ii+ish) + ditracedcn(ii+ish)
      end do
   end do
   !$omp critical (get_damat_0d_)
   atrace(:, :) = atrace + itrace
   dadr(:, :, :) = dadr + didr
   dadL(:, :, :) = dadL + didL
   dadcn(:, :) = dadcn + didcn
   datracedcn(:) = datracedcn + ditracedcn
   !$omp end critical (get_damat_0d_)
   deallocate(didL, didr, itrace, didcn, ditracedcn)
   !$omp end parallel

end subroutine get_damat_0d

!> Evaluate uncontracted derivatives of Coulomb matrix for 3D periodic system
subroutine get_damat_3d(mol, nshell, offset, hubbard, hubbard_cn, hubbard_exp, &
      & average, gexp, cn, wsc, alpha, qvec, dadr, dadL, atrace, dadcn, &
      & datracedcn, refqsh, sigma_self)
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Number of shells for each atom
   integer, intent(in) :: nshell(:)
   !> Index offset for each shell
   integer, intent(in) :: offset(:)
   !> Hubbard parameter for each shell and species
   real(wp), intent(in) :: hubbard(:, :)
   !> CN-dependence of Hubbard parameters
   real(wp), intent(in) :: hubbard_cn(:)
   !> Exponent of radius-dependent hubbard scaling
   real(wp), intent(in) :: hubbard_exp
   !> Averaging function for Hubbard parameter of a shell-pair
   type(average_type), intent(in) :: average
   !> Exponent of Coulomb kernel
   real(wp), intent(in) :: gexp
   !> Coordination number
   real(wp), intent(in) :: cn(:)
   !> Wigner-Seitz image information
   type(wignerseitz_cell), intent(in) :: wsc
   !> Convergence factor for Ewald sum
   real(wp), intent(in) :: alpha
   !> Partial charge vector
   real(wp), intent(in) :: qvec(:)
   !> Derivative of interactions with respect to cartesian displacements
   real(wp), intent(out) :: dadr(:, :, :)
   !> Derivative of interactions with respect to strain deformations
   real(wp), intent(out) :: dadL(:, :, :)
   !> On-site derivatives with respect to cartesian displacements
   real(wp), intent(out) :: atrace(:, :)
   !> Coulomb matrix derivative w.r.t. the coordination numbers
   real(wp), intent(out) :: dadcn(:, :)
   !> On-site derivatives with respect to coordination numbers
   real(wp), intent(out) :: datracedcn(:)
   !> Reference shell charges for the self-image strain correction
   real(wp), intent(in), optional :: refqsh(:)
   !> Self-image strain correction already contracted with qvec and refqsh
   real(wp), intent(out), optional :: sigma_self(:, :)

   integer :: iat, jat, izp, jzp, img, ii, jj, ish, jsh
   logical :: need_weight_energy
   real(wp) :: sqrtcni, sqrtcnj, scalei, scalej, dscaleidcn, dscalejdcn
   real(wp) :: vol, gam, hubi, hubj, vec(3), dG(3), dS(3, 3), stmp
   real(wp) :: dGd(3), dSd(3, 3), dGr(3), dSr(3, 3), dGw(3), dSw(3, 3)
   real(wp) :: dhubidcn, dhubjdcn, dgami, dgamj, dtmpdgam
   real(wp) :: weight(size(wsc%tridx, 1))
   real(wp) :: dwdr(3, size(wsc%tridx, 1)), dwdL(3, 3, size(wsc%tridx, 1))
   real(wp) :: isigma_self(3, 3)
   real(wp), allocatable :: itrace(:, :), didr(:, :, :), didL(:, :, :)
   real(wp), allocatable :: didcn(:, :), ditracedcn(:)
   real(wp), allocatable :: dtrans(:, :), rtrans(:, :)
   logical :: do_sigma_self

   atrace(:, :) = 0.0_wp
   dadr(:, :, :) = 0.0_wp
   dadL(:, :, :) = 0.0_wp
   dadcn(:, :) = 0.0_wp
   datracedcn(:) = 0.0_wp

   vol = abs(matdet_3x3(mol%lattice))
   call get_dir_trans(mol%lattice, alpha, dtrans)
   call get_rec_trans(mol%lattice, alpha, vol, rtrans)

   do_sigma_self = present(sigma_self) .and. present(refqsh)
   if (do_sigma_self) sigma_self(:, :) = 0.0_wp

   !$omp parallel default(none) shared(atrace, dadr, dadL, dadcn, datracedcn) &
   !$omp shared(mol, wsc, alpha, vol, dtrans, rtrans, qvec, nshell, offset) &
   !$omp shared(hubbard, hubbard_cn, hubbard_exp, cn, average, gexp) &
   !$omp shared(do_sigma_self, sigma_self, refqsh) &
   !$omp private(iat, izp, jat, jzp, img, ii, jj, ish, jsh, vec, gam, stmp) &
   !$omp private(need_weight_energy, weight, dwdr, dwdL) &
   !$omp private(scalei, scalej, sqrtcni, sqrtcnj, hubi, hubj, dG, dS) &
   !$omp private(dGr, dSr, dGd, dSd, dGw, dSw, itrace, didr, didL, didcn, ditracedcn, isigma_self) &
   !$omp private(dscaleidcn, dscalejdcn, dhubidcn, dhubjdcn, dgami, dgamj, dtmpdgam)
   allocate(itrace, source=atrace)
   allocate(didr, source=dadr)
   allocate(didL, source=dadL)
   allocate(didcn, source=dadcn)
   allocate(ditracedcn, source=datracedcn)
   if (do_sigma_self) isigma_self(:, :) = 0.0_wp
   !$omp do schedule(runtime)
   do iat = 1, mol%nat
      izp = mol%id(iat)
      ii = offset(iat)
      ! Coordination number scaling
      sqrtcni = sqrt(cn(iat) + cn_reg**2) - cn_reg
      scalei = 1.0_wp + hubbard_cn(izp) * sqrtcni
      dscaleidcn = 0.5_wp * hubbard_cn(izp) / (sqrtcni + cn_reg)
      do jat = 1, iat-1
         jzp = mol%id(jat)
         jj = offset(jat)

         ! Coordination number scaling
         sqrtcnj = sqrt(cn(jat) + cn_reg**2) - cn_reg
         scalej = 1.0_wp + hubbard_cn(jzp) * sqrtcnj
         dscalejdcn = 0.5_wp * hubbard_cn(jzp) / (sqrtcnj + cn_reg)

         vec = mol%xyz(:, iat) - mol%xyz(:, jat)
         call get_wignerseitz_weights(wsc, jat, iat, vec, weight, dwdr, dwdL)
         need_weight_energy = any(dwdr(:, :wsc%nimg(jat, iat)) /= 0.0_wp) &
            & .or. any(dwdL(:, :, :wsc%nimg(jat, iat)) /= 0.0_wp)
         call get_damat_dir_3d(vec, alpha, dtrans, dGd, dSd)
         call get_damat_rec_3d(vec, vol, alpha, rtrans, dGr, dSr)
         do img = 1, wsc%nimg(jat, iat)
            vec = mol%xyz(:, iat) - mol%xyz(:, jat) - wsc%trans(:, wsc%tridx(img, jat, iat))
            do ish = 1, nshell(iat)
               hubi = hubbard(ish, izp) * scalei
               dhubidcn = hubbard(ish, izp) * dscaleidcn
               do jsh = 1, nshell(jat)
                  hubj = hubbard(jsh, jzp) * scalej
                  dhubjdcn = hubbard(jsh, jzp) * dscalejdcn
                  gam = average%value(hubi, hubj)
                  dgami = average%deriv(hubi, hubj) * dhubidcn
                  dgamj = average%deriv(hubj, hubi) * dhubjdcn
                  stmp = 0.0_wp
                  if (need_weight_energy) then
                     call get_amat_wsc_3d(vec, gam, hubbard_exp, gexp, stmp)
                  end if
                  call get_damat_wsc_3d(vec, gam, hubbard_exp, gexp, dGw, dSw, dtmpdgam)
                  dG = (dGd + dGr + dGw) * weight(img) + stmp*dwdr(:, img)
                  dS = (dSd + dSr + dSw) * weight(img) + stmp*dwdL(:, :, img)
                  itrace(:, ii+ish) = +dG*qvec(jj+jsh) + itrace(:, ii+ish)
                  itrace(:, jj+jsh) = -dG*qvec(ii+ish) + itrace(:, jj+jsh)
                  didr(:, iat, jj+jsh) = +dG*qvec(ii+ish) + didr(:, iat, jj+jsh)
                  didr(:, jat, ii+ish) = -dG*qvec(jj+jsh) + didr(:, jat, ii+ish)
                  didL(:, :, jj+jsh) = +dS*qvec(ii+ish) + didL(:, :, jj+jsh)
                  didL(:, :, ii+ish) = +dS*qvec(jj+jsh) + didL(:, :, ii+ish)
                  didcn(jat, ii+ish) = +(dtmpdgam*weight(img))*dgamj*qvec(jj+jsh) + didcn(jat, ii+ish)
                  didcn(iat, jj+jsh) = +(dtmpdgam*weight(img))*dgami*qvec(ii+ish) + didcn(iat, jj+jsh)
                  ditracedcn(ii+ish) = +(dtmpdgam*weight(img))*dgami*qvec(jj+jsh) + ditracedcn(ii+ish)
                  ditracedcn(jj+jsh) = +(dtmpdgam*weight(img))*dgamj*qvec(ii+ish) + ditracedcn(jj+jsh)
               end do
            end do
         end do
      end do

      vec = 0.0_wp
      call get_wignerseitz_weights(wsc, iat, iat, vec, weight, dwdr, dwdL)
      need_weight_energy = any(dwdL(:, :, :wsc%nimg(iat, iat)) /= 0.0_wp)
      call get_damat_dir_3d(vec, alpha, dtrans, dGd, dSd)
      call get_damat_rec_3d(vec, vol, alpha, rtrans, dGr, dSr)
      do img = 1, wsc%nimg(iat, iat)
         vec = wsc%trans(:, wsc%tridx(img, iat, iat))
         do ish = 1, nshell(iat)
            hubi = hubbard(ish, izp) * scalei
            dhubidcn = hubbard(ish, izp) * dscaleidcn
            do jsh = 1, ish-1
               hubj = hubbard(jsh, izp) * scalei
               dhubjdcn = hubbard(jsh, izp) * dscaleidcn
               gam = average%value(hubi, hubj)
               dgami = average%deriv(hubi, hubj) * dhubidcn
               dgamj = average%deriv(hubj, hubi) * dhubjdcn
               stmp = 0.0_wp
               if (need_weight_energy) then
                  call get_amat_wsc_3d(vec, gam, hubbard_exp, gexp, stmp)
               end if
               call get_damat_wsc_3d(vec, gam, hubbard_exp, gexp, dGw, dSw, dtmpdgam)
               dS = (dSd + dSr + dSw) * weight(img) + stmp*dwdL(:, :, img)
               didL(:, :, ii+jsh) = +dS*qvec(ii+ish) + didL(:, :, ii+jsh)
               didL(:, :, ii+ish) = +dS*qvec(ii+jsh) + didL(:, :, ii+ish)
               if (do_sigma_self) then
                  isigma_self(:, :) = isigma_self(:, :) + dS * &
                     & (qvec(ii+ish) * refqsh(ii+jsh) + qvec(ii+jsh) * refqsh(ii+ish))
               end if
               didcn(iat, ii+ish) = +(dtmpdgam+1.0_wp)*weight(img)*dgami*qvec(ii+jsh) + didcn(iat, ii+ish)
               didcn(iat, ii+jsh) = +(dtmpdgam+1.0_wp)*weight(img)*dgamj*qvec(ii+ish) + didcn(iat, ii+jsh)
               ditracedcn(ii+ish) = -(dtmpdgam+1.0_wp)*weight(img)*dgami*qvec(ii+jsh) + ditracedcn(ii+ish)
               ditracedcn(ii+jsh) = -(dtmpdgam+1.0_wp)*weight(img)*dgamj*qvec(ii+ish) + ditracedcn(ii+jsh)
            end do
            gam = hubi
            stmp = 0.0_wp
            if (need_weight_energy) then
               call get_amat_wsc_3d(vec, gam, hubbard_exp, gexp, stmp)
            end if
            call get_damat_wsc_3d(vec, gam, hubbard_exp, gexp, dGw, dSw, dtmpdgam)
            dS = (dSd + dSr + dSw) * weight(img) + stmp*dwdL(:, :, img)
            didL(:, :, ii+ish) = +dS*qvec(ii+ish) + didL(:, :, ii+ish)
            if (do_sigma_self) then
               isigma_self(:, :) = isigma_self(:, :) + dS * qvec(ii+ish) * refqsh(ii+ish)
            end if
            didcn(iat, ii+ish) = +0.5_wp*(dtmpdgam+1.0_wp)*weight(img)*dhubidcn*qvec(ii+ish) &
               & + didcn(iat, ii+ish)
            ditracedcn(ii+ish) = -0.5_wp*(dtmpdgam+1.0_wp)*weight(img)*dhubidcn*qvec(ii+ish) &
               & + ditracedcn(ii+ish)
         end do
      end do
   end do
   !$omp critical (get_damat_3d_)
   atrace(:, :) = atrace + itrace
   dadr(:, :, :) = dadr + didr
   dadL(:, :, :) = dadL + didL
   dadcn(:, :) = dadcn + didcn
   datracedcn(:) = datracedcn + ditracedcn
   if (do_sigma_self) sigma_self(:, :) = sigma_self(:, :) + isigma_self(:, :)
   !$omp end critical (get_damat_3d_)
   deallocate(didL, didr, itrace, didcn, ditracedcn) 
   !$omp end parallel

end subroutine get_damat_3d


!> Calculate direct space Ewald contribution for a pair under 3D periodic boundary conditions
subroutine get_damat_dir_3d(rij, alp, trans, dg, ds)
   !> Distance between pair
   real(wp), intent(in) :: rij(3)
   !> Convergence factor
   real(wp), intent(in) :: alp
   !> Translation vectors to consider
   real(wp), intent(in) :: trans(:, :)
   !> Derivative with respect to cartesian displacements
   real(wp), intent(out) :: dg(3)
   !> Derivative with respect to strain deformations
   real(wp), intent(out) :: ds(3, 3)

   integer :: itr
   real(wp) :: vec(3), r1, r2, dtmp, alp2

   dg(:) = 0.0_wp
   ds(:, :) = 0.0_wp

   alp2 = alp*alp

   do itr = 1, size(trans, 2)
      vec(:) = rij + trans(:, itr)
      r1 = norm2(vec)
      if (r1 < eps) cycle
      r2 = r1*r1
      dtmp = -erfc(alp*r1)/(r2*r1) - 2*alp*exp(-r2*alp2)/(sqrtpi*r2)
      dg(:) = dg + dtmp * vec
      ds(:, :) = ds + dtmp * spread(vec, 1, 3) * spread(vec, 2, 3)
   end do

end subroutine get_damat_dir_3d

!> Calculate Wigner-Seitz averaged short range correction for a pair
subroutine get_damat_wsc_3d(rij, gam, hubbard_exp, gexp, dg, ds, dgam)
   !> Distance between pair
   real(wp), intent(in) :: rij(3)
   !> Hubbard parameter
   real(wp), intent(in) :: gam
   !> Exponent of radius-dependent Hubbard scaling
   real(wp), intent(in) :: hubbard_exp
   !> Exponent for interaction kernel
   real(wp), intent(in) :: gexp
   !> Derivative with respect to cartesian displacements
   real(wp), intent(out) :: dg(3)
   !> Derivative with respect to strain deformations
   real(wp), intent(out) :: ds(3, 3)
   !> Derivative with respect to Hubbard parameter
   real(wp), intent(out) :: dgam

   real(wp) :: r1, r2, damp, ainv, inv, kernel, dtmp

   dg(:) = 0.0_wp
   ds(:, :) = 0.0_wp
   dgam = 0.0_wp

   r1 = norm2(rij)
   if (r1 < eps) return
   r2 = r1*r1

   damp = exp(-gexp * hubbard_exp * r1)
   ainv = gam**(-gexp) * damp
   inv = 1.0_wp / (r1**gexp + ainv)
   kernel = inv**(1.0_wp/gexp)

   ! derivative w.r.t. the undamped Hubbard parameter gam
   dgam = inv * kernel * gam**(-gexp-1.0_wp) * damp

   ! derivative of (kernel - 1/r) w.r.t. r1
   dtmp = (-r1**(gexp-2.0_wp) + hubbard_exp * ainv / r1) * inv * kernel &
      & + 1.0_wp/(r2*r1)

   dg(:) = dtmp * rij
   ds(:, :) = dtmp * spread(rij, 1, 3) * spread(rij, 2, 3)

end subroutine get_damat_wsc_3d


!> Calculate reciprocal space contributions for a pair under 3D periodic boundary conditions
subroutine get_damat_rec_3d(rij, vol, alp, trans, dg, ds)
   !> Distance between pair
   real(wp), intent(in) :: rij(3)
   !> Cell volume
   real(wp), intent(in) :: vol
   !> Convergence factor
   real(wp), intent(in) :: alp
   !> Translation vectors to consider
   real(wp), intent(in) :: trans(:, :)
   !> Derivative with respect to cartesian displacements
   real(wp), intent(out) :: dg(3)
   !> Derivative with respect to strain deformations
   real(wp), intent(out) :: ds(3, 3)

   integer :: itr
   real(wp) :: fac, vec(3), g2, gv, expk, sink, cosk, alp2
   real(wp), parameter :: unity(3, 3) = reshape(&
      & [1, 0, 0, 0, 1, 0, 0, 0, 1], shape(unity))

   dg(:) = 0.0_wp
   ds(:, :) = 0.0_wp
   fac = 4*pi/vol
   alp2 = alp*alp

   do itr = 1, size(trans, 2)
      vec(:) = trans(:, itr)
      g2 = dot_product(vec, vec)
      if (g2 < eps) cycle
      gv = dot_product(rij, vec)
      expk = fac * exp(-0.25_wp*g2/alp2)/g2
      cosk = cos(gv) * expk
      sink = sin(gv) * expk
      dg(:) = dg - sink * vec
      ds(:, :) = ds + cosk &
         & * ((2.0_wp/g2 + 0.5_wp/alp2) * spread(vec, 1, 3)*spread(vec, 2, 3) &
         &     - unity)
   end do

end subroutine get_damat_rec_3d


end module tblite_coulomb_charge_effective
