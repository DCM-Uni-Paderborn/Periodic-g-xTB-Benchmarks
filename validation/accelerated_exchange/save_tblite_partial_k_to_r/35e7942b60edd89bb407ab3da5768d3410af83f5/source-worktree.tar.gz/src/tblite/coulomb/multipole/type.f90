! This file is part of tblite.
! SPDX-Identifier: LGPL-3.0-or-later
!
! tblite is free software: you can redistribute it and/or modify it under
! the terms of the GNU Lesser General Public License as published by
! the Free Software Foundation, either version 3 of the License, or
! (at your option) any later version.
!
! tblite is distributed in the hope that it will be useful,
! but WITHOUT ANY WARRANTY; without even the implied warranty of
! MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
! GNU Lesser General Public License for more details.
!
! You should have received a copy of the GNU Lesser General Public License
! along with tblite.  If not, see <https://www.gnu.org/licenses/>.

!> @file tblite/coulomb/multipole/type.f90
!> Provides an implemenation of a damped multipole based second-order electrostatic

!> Anisotropic second-order electrostatics using a damped multipole expansion
module tblite_coulomb_multipole_type
   use mctc_env, only : error_type, wp
   use mctc_io, only : structure_type
   use mctc_io_math, only : matdet_3x3, matinv_3x3
   use mctc_io_constants, only : pi
   use tblite_blas, only : dot, gemv, symv, gemm
   use tblite_container_cache, only : container_cache
   use tblite_coulomb_cache, only : coulomb_cache
   use tblite_coulomb_ewald, only : get_dir_cutoff, get_rec_cutoff
   use tblite_coulomb_type, only : coulomb_type
   use tblite_cutoff, only : get_lattice_points
   use tblite_scf_potential, only : potential_type
   use tblite_wavefunction_type, only : wavefunction_type
   use tblite_wignerseitz, only : wignerseitz_cell, get_wignerseitz_weights
   implicit none
   private

   !> Container to handle multipole electrostatics
   type, public, extends(coulomb_type), abstract :: damped_multipole
      !> Ewald splitting parameter
      real(wp) :: alpha = 0.0_wp
      !> Damping prefactor for inverse quadratic interactions
      real(wp) :: kdmp3 = 0.0_wp
      !> Damping prefactor for inverse cubic interactions
      real(wp) :: kdmp5 = 0.0_wp
      !> Damping prefactor for inverse quartic interactions
      real(wp) :: kdmp7 = 0.0_wp
      !> Damping prefactor for inverse quintic interactions
      real(wp) :: kdmp9 = 0.0_wp
      !> Damping function exponent for inverse quadratic interactions
      real(wp) :: kexp3 = 0.0_wp
      !> Damping function exponent for inverse cubic interactions
      real(wp) :: kexp5 = 0.0_wp
      !> Damping function exponent for inverse quartic interactions
      real(wp) :: kexp7 = 0.0_wp 
      !> Damping function exponent for inverse quintic interactions
      real(wp) :: kexp9 = 0.0_wp
      !> Kernel for on-site dipole exchange-correlation
      real(wp), allocatable :: dkernel(:)
      !> Kernel for on-site quadrupolar exchange-correlation
      real(wp), allocatable :: qkernel(:)
      !> Scaling factor for atomic dipole moments
      real(wp), allocatable :: dip_scale(:)
   contains
      !> Return dependency on density
      procedure :: variable_info
      !> Get anisotropic electrostatic energy
      procedure :: get_energy
      !> Get anisotropic electrostatic potential
      procedure :: get_potential
      !> Get derivatives of anisotropic electrostatics
      procedure :: get_gradient
      ! These additional functions are necessary as the atomic contributions to AES are not 
      ! the same in this implementation and in the GFN2 paper,
      ! for details see https://github.com/tblite/tblite/pull/224/files#r1970341792
      !> Get only AXC part of the anisotropic energy
      procedure :: get_energy_axc
      !> Get AES energy of the anisotropic electrostatics
      procedure :: get_energy_aes
      !> Get interaction matrix for all multipole moments up to quadrupoles
      procedure :: get_multipole_matrix
      !> Evaluate multipole damping radius
      procedure(get_mrad_pair), deferred :: get_mrad_pair
      !> Evaluate multipole damping radius derivatives
      procedure(get_mrad_derivs), deferred :: get_mrad_derivs
      !> Evaluate pairwise damping factors
      procedure(get_damping_pair), deferred :: get_damping_pair
      !> Evaluate derivatives of damping factors
      procedure(get_damping_derivs), deferred :: get_damping_derivs
   end type damped_multipole


   abstract interface
      !> Evaluate multipole damping radius for a diatomic pair
      pure subroutine get_mrad_pair(self, cache, iat, jat, isp, jsp, mrad)
         import :: damped_multipole, coulomb_cache, wp
         !> Instance of the multipole containeris
         class(damped_multipole), intent(in) :: self
         !> Reusable data container
         type(coulomb_cache), intent(in) :: cache
         !> Index of atom i
         integer, intent(in) :: iat
         !> Index of atom j
         integer, intent(in) :: jat
         !> Species of atom i
         integer, intent(in) :: isp
         !> Species of atom j
         integer, intent(in) :: jsp
         !> Multipole damping radius for the pair
         real(wp), intent(out) :: mrad
      end subroutine get_mrad_pair

      !> Evaluate multipole damping radius derivatives for a diatomic pair
      pure subroutine get_mrad_derivs(self, cache, iat, jat, isp, jsp, mrad, &
         & dmraddcni, dmraddcnj)
         import :: damped_multipole, coulomb_cache, wp
         !> Instance of the multipole containeris
         class(damped_multipole), intent(in) :: self
         !> Reusable data container
         type(coulomb_cache), intent(in) :: cache
         !> Index of atom i
         integer, intent(in) :: iat
         !> Index of atom j
         integer, intent(in) :: jat
         !> Species of atom i
         integer, intent(in) :: isp
         !> Species of atom j
         integer, intent(in) :: jsp
         !> Multipole damping radius for the pair
         real(wp), intent(out) :: mrad
         !> Derivative of the multipole damping radius w.r.t. the CN of atom i
         real(wp), intent(out) :: dmraddcni
         !> Derivative of the multipole damping radius w.r.t. the CN of atom j
         real(wp), intent(out) :: dmraddcnj
      end subroutine get_mrad_derivs

      !> Evaluate damping function for a diatomic pair
      pure subroutine get_damping_pair(self, r, rinv, mrad, fdmp3, fdmp5, &
         & fdmp7, fdmp9)
         import :: damped_multipole, wp
         !> Instance of the multipole containeris
         class(damped_multipole), intent(in) :: self
         !> Interatomic distance
         real(wp), intent(in) :: r
         !> Inverse interatomic distance
         real(wp), intent(in) :: rinv
         !> Pairwise reference radius
         real(wp), intent(in) :: mrad
         !> Damping factor for inverse quadratic interactions
         real(wp), intent(out) :: fdmp3
         !> Damping factor for inverse cubic interactions
         real(wp), intent(out) :: fdmp5
         !> Damping factor for inverse quartic interactions
         real(wp), intent(out) :: fdmp7
         !> Damping factor for inverse quintic interactions
         real(wp), intent(out) :: fdmp9
      end subroutine get_damping_pair

      !> Evaluate derivatives of the damping function for a diatomic pair
      pure subroutine get_damping_derivs(self, r, rinv, mrad, fdmp3, fdmp5, &
         & fdmp7, fdmp9, dfdmp3dr, dfdmp5dr, dfdmp7dr, dfdmp9dr, &
         & dfdmp3dmrad, dfdmp5dmrad, dfdmp7dmrad, dfdmp9dmrad)
         import :: damped_multipole, wp
         !> Instance of the multipole container
         class(damped_multipole), intent(in) :: self
         !> Interatomic distance
         real(wp), intent(in) :: r
         !> Inverse interatomic distance
         real(wp), intent(in) :: rinv
         !> Averaged pairwise reference radius
         real(wp), intent(in) :: mrad
         !> Damping factor for inverse quadratic interactions
         real(wp), intent(out) :: fdmp3
         !> Damping factor for inverse cubic interactions
         real(wp), intent(out) :: fdmp5
         !> Damping factor for inverse quartic interactions
         real(wp), intent(out) :: fdmp7
         !> Damping factor for inverse quintic interactions
         real(wp), intent(out) :: fdmp9
         !> Derivative of damping factor for inverse quadratic interactions w.r.t. the distance
         real(wp), intent(out) :: dfdmp3dr
         !> Derivative of damping factor for inverse cubic interactions w.r.t. the distance
         real(wp), intent(out) :: dfdmp5dr
         !> Derivative of damping factor for inverse quartic interactions w.r.t. the distance
         real(wp), intent(out) :: dfdmp7dr
         !> Derivative of damping factor for inverse quintic interactions w.r.t. the distance
         real(wp), intent(out) :: dfdmp9dr
         !> Derivative of damping factor for inverse quadratic interactions w.r.t. the radius
         real(wp), intent(out) :: dfdmp3dmrad
         ! Derivative of damping factor for inverse cubic interactions w.r.t. the radius
         real(wp), intent(out) :: dfdmp5dmrad
         !> Derivative of damping factor for inverse quartic interactions w.r.t. the radius
         real(wp), intent(out) :: dfdmp7dmrad
         !> Derivative of damping factor for inverse quintic interactions w.r.t. the radius
         real(wp), intent(out) :: dfdmp9dmrad
      end subroutine get_damping_derivs
   end interface

   real(wp), parameter :: twopi = 2 * pi
   real(wp), parameter :: sqrtpi = sqrt(pi)
   real(wp), parameter :: eps = sqrt(epsilon(0.0_wp))
   real(wp), parameter :: conv = eps
   real(wp), parameter :: cn_reg = 1e-6_wp

contains


!> Get anisotropic electrostatic energy
subroutine get_energy(self, mol, cache, wfn, energies)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Wavefunction data
   type(wavefunction_type), intent(in) :: wfn
   !> Electrostatic energy
   real(wp), intent(inout) :: energies(:)
   !> Reusable data container
   type(container_cache), intent(inout) :: cache

   real(wp), allocatable :: vs(:), vd(:, :), vq(:, :)
   type(coulomb_cache), pointer :: ptr

   call view(cache, ptr)

   allocate(vs(mol%nat), vd(3, mol%nat), vq(6, mol%nat))

   ! Damped multipole electrostatics
   call gemv(ptr%amat_sd, wfn%qat(:, 1), vd)
   call gemv(ptr%amat_dd, wfn%dpat(:, :, 1), vd, beta=1.0_wp, alpha=0.5_wp)
   call gemv(ptr%amat_sq, wfn%qat(:, 1), vq)
   call gemv(ptr%amat_dq, wfn%qpat(:, :, 1), vd, beta=1.0_wp)
   call gemv(ptr%amat_qq, wfn%qpat(:, :, 1), vq, beta=1.0_wp, alpha=0.5_wp/3.0_wp)

   energies(:) = energies + sum(wfn%dpat(:, :, 1) * vd, 1) &
      & + sum(wfn%qpat(:, :, 1) * vq, 1)

   ! Onsite multipole exchange-correlation kernel
   if (allocated(self%dkernel)) then
      call get_kernel_energy(mol, self%dkernel, wfn%dpat(:, :, 1), energies)
   end if
   if (allocated(self%qkernel)) then
      call get_kernel_energy(mol, self%qkernel, wfn%qpat(:, :, 1), energies)
   end if
end subroutine get_energy


!> Get anisotropic electrostatic energy
subroutine get_energy_aes(self, mol, cache, wfn, energies)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Wavefunction data
   type(wavefunction_type), intent(in) :: wfn
   !> Electrostatic energy
   real(wp), intent(inout) :: energies(:)
   !> Reusable data container
   type(container_cache), intent(inout) :: cache

   real(wp), allocatable :: vd(:, :), vq(:, :)
   real(wp), allocatable :: mur(:), t1(:)
   real(wp), allocatable :: e01(:), e11(:), e02(:), e12(:), e22(:)
   type(coulomb_cache), pointer :: ptr
   integer :: i

   call view(cache, ptr)

   allocate(vd(3, mol%nat), vq(6, mol%nat))
   allocate(mur(mol%nat), t1(mol%nat), source=0.0_wp)
   allocate(e01(mol%nat), e11(mol%nat), e02(mol%nat), e12(mol%nat), e22(mol%nat), &
      source=0.0_wp)

   ! charge-dipole: e01 = q^T (A_sd^T d) + d^T (A_sd q)
   vd = 0.0_wp
   mur = 0.0_wp
   call gemv(ptr%amat_sd, wfn%qat(:, 1), vd)
   do i = 1, 3
      call gemv(ptr%amat_sd(i,:,:), wfn%dpat(i,:,1), mur, beta=1.0_wp, trans="T")
   end do
   e01 = mur*wfn%qat(:, 1) + sum(wfn%dpat(:,:,1) * vd, 1)

   ! dipole-dipole: e11 = d^T (A_dd d)
   vd = 0.0_wp
   call gemv(ptr%amat_dd, wfn%dpat(:, :, 1), vd, beta=1.0_wp)
   e11 = sum(wfn%dpat(:, :, 1) * vd, 1)

   ! charge-quadrupole: e02 = q^T (A_sq^T Q) + Q^T (A_sq q)
   vq = 0.0_wp
   t1 = 0.0_wp
   call gemv(ptr%amat_sq, wfn%qat(:, 1), vq)
   do i = 1, 6
      call gemv(ptr%amat_sq(i,:,:), wfn%qpat(i,:,1), t1, beta=1.0_wp, trans="T")
   end do
   e02 = t1*wfn%qat(:,1) + sum(wfn%qpat(:,:,1) * vq, 1)

   ! dipole-quadrupole: e12 = d^T (A_dq Q) + Q^T (A_dq^T d)
   vd = 0.0_wp
   vq = 0.0_wp
   call gemv(ptr%amat_dq, wfn%qpat(:, :, 1), vd, beta=1.0_wp)
   call gemv(ptr%amat_dq, wfn%dpat(:, :, 1), vq, beta=1.0_wp, trans="T")
   e12 = sum(wfn%dpat(:,:,1) * vd, 1) + sum(wfn%qpat(:,:,1) * vq, 1)

   ! quadrupole-quadrupole: e22 = Q^T (A_qq Q)
   vq = 0.0_wp
   call gemv(ptr%amat_qq, wfn%qpat(:, :, 1), vq, beta=1.0_wp)
   e22 = sum(wfn%qpat(:, :, 1) * vq, 1) / 3.0_wp

   energies(:) = energies(:) + 0.5_wp * (e01 + e11 + e02 + e12 + e22)
end subroutine get_energy_aes


!> Get only AXC part of the anisotropic energy
subroutine get_energy_axc(self, mol, wfn, energies)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Wavefunction data
   type(wavefunction_type), intent(in) :: wfn
   !> Electrostatic energy
   real(wp), intent(inout) :: energies(:)

   call get_kernel_energy(mol, self%dkernel, wfn%dpat(:, :, 1), energies)
   call get_kernel_energy(mol, self%qkernel, wfn%qpat(:, :, 1), energies)

end subroutine get_energy_axc


!> Get multipolar anisotropic exchange-correlation kernel energy
subroutine get_kernel_energy(mol, kernel, mpat, energies)
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Multipole kernel
   real(wp), intent(in) :: kernel(:)
   !> Atomic multipole momemnt
   real(wp), intent(in) :: mpat(:, :)
   !> Electrostatic energy
   real(wp), intent(inout) :: energies(:)

   integer :: iat, izp
   real(wp) :: mpt(size(mpat, 1)), mpscale(size(mpat, 1))

   mpscale(:) = 1
   if (size(mpat, 1) == 6) mpscale([2, 4, 5]) = 2

   do iat = 1, mol%nat
      izp = mol%id(iat)
      mpt(:) = mpat(:, iat) * mpscale
      energies(iat) = energies(iat) + kernel(izp) * dot_product(mpt, mpat(:, iat))
   end do
end subroutine get_kernel_energy


!> Get anisotropic electrostatic potential
subroutine get_potential(self, mol, cache, wfn, pot)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Wavefunction data
   type(wavefunction_type), intent(in) :: wfn
   !> Density dependent potential
   type(potential_type), intent(inout) :: pot
   !> Reusable data container
   type(container_cache), intent(inout) :: cache

   type(coulomb_cache), pointer :: ptr

   call view(cache, ptr)

   ! Damped multipole electrostatics
   call gemv(ptr%amat_sd, wfn%qat(:, 1), pot%vdp(:, :, 1), beta=1.0_wp)
   call gemv(ptr%amat_sd, wfn%dpat(:, :, 1), pot%vat(:, 1), beta=1.0_wp, trans="T")

   call gemv(ptr%amat_dd, wfn%dpat(:, :, 1), pot%vdp(:, :, 1), beta=1.0_wp)

   call gemv(ptr%amat_sq, wfn%qat(:, 1), pot%vqp(:, :, 1), beta=1.0_wp)
   call gemv(ptr%amat_sq, wfn%qpat(:, :, 1), pot%vat(:, 1), beta=1.0_wp, trans="T")

   call gemv(ptr%amat_dq, wfn%qpat(:, :, 1), pot%vdp(:, :, 1), beta=1.0_wp)
   call gemv(ptr%amat_dq, wfn%dpat(:, :, 1), pot%vqp(:, :, 1), beta=1.0_wp, trans="T")

   call gemv(ptr%amat_qq, wfn%qpat(:, :, 1), pot%vqp(:, :, 1), beta=1.0_wp, alpha=1.0_wp/3.0_wp)

   ! Onsite multipole exchange-correlation kernel
   if (allocated(self%dkernel)) then
      call get_kernel_potential(mol, self%dkernel, wfn%dpat(:, :, 1), pot%vdp(:, :, 1))
   end if
   if (allocated(self%qkernel)) then
      call get_kernel_potential(mol, self%qkernel, wfn%qpat(:, :, 1), pot%vqp(:, :, 1))
   end if
end subroutine get_potential


!> Get multipolar anisotropic potential contribution
subroutine get_kernel_potential(mol, kernel, mpat, vm)
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Multipole kernel
   real(wp), intent(in) :: kernel(:)
   !> Atomic multipole momemnt
   real(wp), intent(in) :: mpat(:, :)
   !> Potential shoft on atomic multipole moment
   real(wp), intent(inout) :: vm(:, :)

   integer :: iat, izp
   real(wp) :: mpscale(size(mpat, 1))

   mpscale(:) = 1
   if (size(mpat, 1) == 6) mpscale([2, 4, 5]) = 2

   do iat = 1, mol%nat
      izp = mol%id(iat)
      vm(:, iat) = vm(:, iat) + 2*kernel(izp) * mpat(:, iat) * mpscale
   end do
end subroutine get_kernel_potential


!> Get derivatives of anisotropic electrostatics
subroutine get_gradient(self, mol, cache, wfn, gradient, sigma)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(container_cache), intent(inout) :: cache
   !> Wavefunction data
   type(wavefunction_type), intent(in) :: wfn
   !> Molecular gradient of the multipole electrostatics energy
   real(wp), contiguous, intent(inout) :: gradient(:, :)
   !> Strain derivatives of the multipole electrostatics energy
   real(wp), contiguous, intent(inout) :: sigma(:, :)

   real(wp), allocatable :: dEdcn(:)
   type(coulomb_cache), pointer :: ptr

   call view(cache, ptr)

   allocate(dEdcn(mol%nat))
   dEdcn = 0.0_wp

   call get_multipole_gradient(self, mol, ptr, &
      & wfn%qat(:, 1), wfn%dpat(:, :, 1), wfn%qpat(:, :, 1), &
      & dEdcn, gradient, sigma)

   call gemv(ptr%dcndr, dEdcn, gradient, beta=1.0_wp)
   call gemv(ptr%dcndL, dEdcn, sigma, beta=1.0_wp)
end subroutine get_gradient


!> Get real lattice vectors
subroutine get_dir_trans(lattice, alpha, rcut, trans)
   !> Lattice parameters
   real(wp), intent(in) :: lattice(:, :)
   !> Parameter for Ewald summation
   real(wp), intent(in) :: alpha
   !> Direct space cutoff distance
   real(wp), intent(in) :: rcut
   !> Translation vectors
   real(wp), allocatable, intent(out) :: trans(:, :)

   call get_lattice_points([.true.], lattice, rcut, trans)

end subroutine get_dir_trans


!> Get reciprocal lattice translations
subroutine get_rec_trans(lattice, alpha, kcut, trans)
   !> Lattice parameters
   real(wp), intent(in) :: lattice(:, :)
   !> Parameter for Ewald summation
   real(wp), intent(in) :: alpha
   !> Reciprocal space cutoff distance
   real(wp), intent(in) :: kcut
   !> Translation vectors
   real(wp), allocatable, intent(out) :: trans(:, :)

   real(wp) :: rec_lat(3, 3)

   rec_lat = twopi*transpose(matinv_3x3(lattice))
   call get_lattice_points([.true.], rec_lat, kcut, trans)

end subroutine get_rec_trans


!> Get interaction matrix for all multipole moments up to quadrupoles
subroutine get_multipole_matrix(self, mol, cache, amat_sd, amat_dd, &
   & amat_sq, amat_dq, amat_qq)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(in) :: cache
   !> Interaction matrix for charges and dipoles
   real(wp), contiguous, intent(out) :: amat_sd(:, :, :)
   !> Interaction matrix for dipoles and dipoles
   real(wp), contiguous, intent(out) :: amat_dd(:, :, :, :)
   !> Interaction matrix for charges and quadrupoles
   real(wp), contiguous, intent(out) :: amat_sq(:, :, :)
   !> Interaction matrix for dipoles and quadrupoles
   real(wp), contiguous, intent(out) :: amat_dq(:, :, :, :)
   !> Interaction matrix for quadrupoles and quadrupoles
   real(wp), contiguous, intent(out) :: amat_qq(:, :, :, :)

   amat_sd(:, :, :) = 0.0_wp
   amat_dd(:, :, :, :) = 0.0_wp
   amat_sq(:, :, :) = 0.0_wp
   amat_dq(:, :, :, :) = 0.0_wp
   amat_qq(:, :, :, :) = 0.0_wp
   if (any(mol%periodic)) then
      call get_multipole_matrix_3d(self, mol, cache, &
         & cache%alpha_multipole, amat_sd, amat_dd, amat_sq, amat_dq, amat_qq)
   else
      call get_multipole_matrix_0d(self, mol, cache, &
         & amat_sd, amat_dd, amat_sq, amat_dq, amat_qq)
   end if
end subroutine get_multipole_matrix

!> Calculate the multipole interaction matrix for finite systems
subroutine get_multipole_matrix_0d(self, mol, cache, &
   & amat_sd, amat_dd, amat_sq, amat_dq, amat_qq)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(in) :: cache
   !> Interaction matrix for charges and dipoles
   real(wp), intent(inout) :: amat_sd(:, :, :)
   !> Interaction matrix for dipoles and dipoles
   real(wp), intent(inout) :: amat_dd(:, :, :, :)
   !> Interaction matrix for charges and quadrupoles
   real(wp), intent(inout) :: amat_sq(:, :, :)
   !> Interaction matrix for dipoles and quadrupoles
   real(wp), intent(inout) :: amat_dq(:, :, :, :)
   !> Interaction matrix for quadrupoles and quadrupoles
   real(wp), intent(inout) :: amat_qq(:, :, :, :)

   integer :: iat, jat, izp, jzp
   real(wp) :: r1, vec(3), tdd(3,3), tsq(6), tdq(3,6), tqq(6,6)
   real(wp) :: x2, y2, z2, xy, xz, yz, g1, g2, g3, g5, g7, g9
   real(wp) :: scale_di, scale_dj, sqrtcni, sqrtcnj
   real(wp) :: dg3, dg5, dg7, dg9, mrad, fdmp3, fdmp5, fdmp7, fdmp9
   
   !$omp parallel do default(none) schedule(runtime) collapse(2) &
   !$omp shared(self, cache, mol, amat_sd, amat_dd, amat_sq, amat_dq, amat_qq) &
   !$omp private(iat, jat, izp, jzp, r1, vec, g1, g2, g3, g5, g7, g9, sqrtcni) & 
   !$omp private(sqrtcnj, scale_di, scale_dj, mrad, fdmp3, fdmp5, fdmp7, fdmp9) & 
   !$omp private(x2, y2, z2, xy, xz, yz, dg3, dg5, dg7, dg9, tdd, tsq, tdq, tqq)
   do iat = 1, mol%nat
      do jat = 1, mol%nat
         vec(:) = mol%xyz(:, iat) - mol%xyz(:, jat)
         izp = mol%id(iat)
         jzp = mol%id(jat)
         r1 = norm2(vec)
         if (r1 < eps) cycle ! as alternative to iat==jat cycle
         g1 = 1.0_wp / r1
         g2 = g1 * g1
         g3 = g1 * g2
         g5 = g3 * g2
         g7 = g5 * g2
         g9 = g7 * g2

         ! Get the atomic dipole scaling factors
         sqrtcni = sqrt(cache%cn(iat) + cn_reg**2) - cn_reg
         sqrtcnj = sqrt(cache%cn(jat) + cn_reg**2) - cn_reg
         scale_di = 1.0_wp + self%dip_scale(izp) * sqrtcni
         scale_dj = 1.0_wp + self%dip_scale(jzp) * sqrtcnj

         ! Get the multipole damping radii
         call self%get_mrad_pair(cache, iat, jat, izp, jzp, mrad)

         ! Get the pairwise damping functions
         call self%get_damping_pair(r1, g1, mrad, fdmp3, fdmp5, &
            & fdmp7, fdmp9)

         ! Charge-dipole interaction
         dg3 = g3 * fdmp3 * scale_dj
         amat_sd(:, jat, iat) = amat_sd(:, jat, iat) + vec * dg3

         ! Dipole-dipole interaction
         x2 = vec(1)*vec(1)
         y2 = vec(2)*vec(2)
         z2 = vec(3)*vec(3)
         xy = vec(1)*vec(2)
         xz = vec(1)*vec(3)
         yz = vec(2)*vec(3)
         dg3 = g3 * fdmp5 * scale_dj * scale_di
         dg5 = g5 * fdmp5 * scale_dj * scale_di
         ! x-component of the dipole
         tdd(1, 1) = -3.0_wp*dg5*x2 + dg3
         tdd(2, 1) = -3.0_wp*dg5*xy
         tdd(3, 1) = -3.0_wp*dg5*xz
         ! y-component of the dipole
         tdd(1, 2) = -3.0_wp*dg5*xy
         tdd(2, 2) = -3.0_wp*dg5*y2 + dg3
         tdd(3, 2) = -3.0_wp*dg5*yz
         ! z-component of the dipole
         tdd(1, 3) = -3.0_wp*dg5*xz
         tdd(2, 3) = -3.0_wp*dg5*yz
         tdd(3, 3) = -3.0_wp*dg5*z2 + dg3

         amat_dd(:, jat, :, iat) = amat_dd(:, jat, :, iat) + tdd

         ! Charge-quadrupole interaction packed with doubled off-diagonal elements
         dg5 = g5 * fdmp5
         tsq(1) = dg5*x2
         tsq(2) = 2.0_wp*dg5*xy
         tsq(3) = dg5*y2
         tsq(4) = 2.0_wp*dg5*xz
         tsq(5) = 2.0_wp*dg5*yz
         tsq(6) = dg5*z2

         amat_sq(:, jat, iat) = amat_sq(:, jat, iat) + tsq 

         ! Dipole-quadrupole interaction packed with doubled off-diagonal elements
         dg7 = g7 * fdmp7 * scale_dj
         dg5 = g5 * fdmp7 * scale_dj
         ! xx-component of the quadrupole
         tdq(1, 1) = -5.0_wp*dg7*x2*vec(1) + 3.0_wp*dg5*vec(1)
         tdq(2, 1) = -5.0_wp*dg7*xy*vec(1) + dg5*vec(2)
         tdq(3, 1) = -5.0_wp*dg7*xz*vec(1) + dg5*vec(3)
         ! xy-component of the quadrupole
         tdq(1, 2) = -10.0_wp*dg7*x2*vec(2) + 2.0_wp*dg5*vec(2)
         tdq(2, 2) = -10.0_wp*dg7*y2*vec(1) + 2.0_wp*dg5*vec(1)
         tdq(3, 2) = -10.0_wp*dg7*xz*vec(2)
         ! yy-component of the quadrupole
         tdq(1, 3) = -5.0_wp*dg7*xy*vec(2) + dg5*vec(1)
         tdq(2, 3) = -5.0_wp*dg7*y2*vec(2) + 3.0_wp*dg5*vec(2)
         tdq(3, 3) = -5.0_wp*dg7*yz*vec(2) + dg5*vec(3)
         ! xz-component of the quadrupole
         tdq(1, 4) = -10.0_wp*dg7*x2*vec(3) + 2.0_wp*dg5*vec(3)
         tdq(2, 4) = -10.0_wp*dg7*xy*vec(3)
         tdq(3, 4) = -10.0_wp*dg7*z2*vec(1) + 2.0_wp*dg5*vec(1)
         ! yz-component of the quadrupole
         tdq(1, 5) = -10.0_wp*dg7*xy*vec(3)
         tdq(2, 5) = -10.0_wp*dg7*y2*vec(3) + 2.0_wp*dg5*vec(3)
         tdq(3, 5) = -10.0_wp*dg7*z2*vec(2) + 2.0_wp*dg5*vec(2)
         ! zz-component of the quadrupole
         tdq(1, 6) = -5.0_wp*dg7*xz*vec(3) + dg5*vec(1)
         tdq(2, 6) = -5.0_wp*dg7*yz*vec(3) + dg5*vec(2)
         tdq(3, 6) = -5.0_wp*dg7*z2*vec(3) + 3.0_wp*dg5*vec(3)

         ! Negative sign consistent with the definition of the interatomic vector j to i
         amat_dq(:, jat, :, iat) = amat_dq(:, jat, :, iat) - tdq

         ! Quadrupole-quadrupole interaction packed with doubled off-diagonal elements
         dg9 = g9 * fdmp9
         dg7 = g7 * fdmp9
         dg5 = g5 * fdmp9
         ! xx-component of the quadrupole
         tqq(1, 1) = 35.0_wp*dg9*x2*x2 - 30.0_wp*dg7*x2 + 4.5_wp*dg5
         tqq(2, 1) = 70.0_wp*dg9*x2*xy - 30.0_wp*dg7*xy
         tqq(3, 1) = 35.0_wp*dg9*x2*y2 - 5.0_wp*dg7*(x2+y2) + 1.5_wp*dg5
         tqq(4, 1) = 70.0_wp*dg9*x2*xz - 30.0_wp*dg7*xz
         tqq(5, 1) = 70.0_wp*dg9*x2*yz - 10.0_wp*dg7*yz
         tqq(6, 1) = 35.0_wp*dg9*x2*z2 - 5.0_wp*dg7*(x2+z2) + 1.5_wp*dg5
         ! xy-component of the quadrupole
         tqq(1, 2) = 70.0_wp*dg9*x2*xy - 30.0_wp*dg7*xy
         tqq(2, 2) = 140.0_wp*dg9*x2*y2 - 20.0_wp*dg7*(x2+y2) + 6.0_wp*dg5
         tqq(3, 2) = 70.0_wp*dg9*y2*xy - 30.0_wp*dg7*xy
         tqq(4, 2) = 140.0_wp*dg9*x2*yz - 20.0_wp*dg7*yz
         tqq(5, 2) = 140.0_wp*dg9*y2*xz - 20.0_wp*dg7*xz
         tqq(6, 2) = 70.0_wp*dg9*z2*xy - 10.0_wp*dg7*xy
         ! yy-component of the quadrupole
         tqq(1, 3) = 35.0_wp*dg9*x2*y2 - 5.0_wp*dg7*(x2+y2) + 1.5_wp*dg5
         tqq(2, 3) = 70.0_wp*dg9*y2*xy - 30.0_wp*dg7*xy
         tqq(3, 3) = 35.0_wp*dg9*y2*y2 - 30.0_wp*dg7*y2 + 4.5_wp*dg5
         tqq(4, 3) = 70.0_wp*dg9*y2*xz - 10.0_wp*dg7*xz
         tqq(5, 3) = 70.0_wp*dg9*y2*yz - 30.0_wp*dg7*yz
         tqq(6, 3) = 35.0_wp*dg9*y2*z2 - 5.0_wp*dg7*(y2+z2) + 1.5_wp*dg5
         ! xz-component of the quadrupole
         tqq(1, 4) = 70.0_wp*dg9*x2*xz - 30.0_wp*dg7*xz
         tqq(2, 4) = 140.0_wp*dg9*x2*yz - 20.0_wp*dg7*yz
         tqq(3, 4) = 70.0_wp*dg9*y2*xz - 10.0_wp*dg7*xz
         tqq(4, 4) = 140.0_wp*dg9*x2*z2 - 20.0_wp*dg7*(x2+z2) + 6.0_wp*dg5
         tqq(5, 4) = 140.0_wp*dg9*z2*xy - 20.0_wp*dg7*xy
         tqq(6, 4) = 70.0_wp*dg9*z2*xz - 30.0_wp*dg7*xz
         ! yz-component of the quadrupole
         tqq(1, 5) = 70.0_wp*dg9*x2*yz - 10.0_wp*dg7*yz
         tqq(2, 5) = 140.0_wp*dg9*y2*xz - 20.0_wp*dg7*xz
         tqq(3, 5) = 70.0_wp*dg9*y2*yz - 30.0_wp*dg7*yz
         tqq(4, 5) = 140.0_wp*dg9*z2*xy - 20.0_wp*dg7*xy
         tqq(5, 5) = 140.0_wp*dg9*y2*z2 - 20.0_wp*dg7*(y2+z2) + 6.0_wp*dg5
         tqq(6, 5) = 70.0_wp*dg9*z2*yz - 30.0_wp*dg7*yz
         ! zz-component of the quadrupole
         tqq(1, 6) = 35.0_wp*dg9*x2*z2 - 5.0_wp*dg7*(x2+z2) + 1.5_wp*dg5
         tqq(2, 6) = 70.0_wp*dg9*z2*xy - 10.0_wp*dg7*xy
         tqq(3, 6) = 35.0_wp*dg9*y2*z2 - 5.0_wp*dg7*(y2+z2) + 1.5_wp*dg5
         tqq(4, 6) = 70.0_wp*dg9*z2*xz - 30.0_wp*dg7*xz
         tqq(5, 6) = 70.0_wp*dg9*z2*yz - 30.0_wp*dg7*yz
         tqq(6, 6) = 35.0_wp*dg9*z2*z2 - 30.0_wp*dg7*z2 + 4.5_wp*dg5

         amat_qq(:, jat, :, iat) = amat_qq(:, jat, :, iat) + tqq

      end do
   end do

end subroutine get_multipole_matrix_0d

!> Evaluate multipole interaction matrix under 3D periodic boundary conditions
subroutine get_multipole_matrix_3d(self, mol, cache, alpha, &
   & amat_sd, amat_dd, amat_sq, amat_dq, amat_qq)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(in) :: cache
   !> Ewald splitting parameter
   real(wp), intent(in) :: alpha
   !> Interaction matrix for charges and dipoles
   real(wp), intent(inout) :: amat_sd(:, :, :)
   !> Interaction matrix for dipoles and dipoles
   real(wp), intent(inout) :: amat_dd(:, :, :, :)
   !> Interaction matrix for charges and quadrupoles
   real(wp), intent(inout) :: amat_sq(:, :, :)
   !> Interaction matrix for dipoles and quadrupoles
   real(wp), intent(inout) :: amat_dq(:, :, :, :)
   !> Interaction matrix for quadrupoles and quadrupoles
   real(wp), intent(inout) :: amat_qq(:, :, :, :)

   integer :: iat, jat, izp, jzp, img
   real(wp) :: sqrtcni, sqrtcnj, scale_di, scale_dj, mrad, vol, rr
   real(wp), allocatable :: dtrans(:, :), rtrans(:, :)
   real(wp) :: rij(3), vec(3)
   real(wp) :: weight(size(cache%wsc%tridx, 1))
   real(wp) :: t_sd(3), t_dd(3,3), t_sq(6), t_dq(3,6), t_qq(6,6)
   real(wp) :: r_sd(3), r_dd(3,3), r_sq(6), r_dq(3,6), r_qq(6,6)

   vol = abs(matdet_3x3(mol%lattice))
   call get_dir_trans(mol%lattice, alpha, cache%rcut_mp, dtrans)
   call get_rec_trans(mol%lattice, alpha, cache%kcut_mp, rtrans)

   !$omp parallel do default(none) schedule(runtime) collapse(2) &
   !$omp shared(self, cache, amat_sd, amat_dd, amat_sq, amat_dq, amat_qq) &
   !$omp shared(mol, dtrans, rtrans, vol, alpha) &
   !$omp private(iat, jat, izp, jzp, img, mrad, sqrtcni, sqrtcnj) &
   !$omp private(scale_di, scale_dj, t_sd, t_dd, t_sq, t_dq, t_qq, rij, vec, weight, rr) &
   !$omp private(r_sd, r_dd, r_sq, r_dq, r_qq)
   do iat = 1, mol%nat
      do jat = 1, mol%nat
         izp = mol%id(iat)
         jzp = mol%id(jat)

         ! Get the atomic dipole scaling factors
         sqrtcni = sqrt(cache%cn(iat) + cn_reg**2) - cn_reg
         sqrtcnj = sqrt(cache%cn(jat) + cn_reg**2) - cn_reg
         scale_di = 1.0_wp + self%dip_scale(izp) * sqrtcni
         scale_dj = 1.0_wp + self%dip_scale(jzp) * sqrtcnj

         ! Get the multipole damping radii
         call self%get_mrad_pair(cache, iat, jat, izp, jzp, mrad)

         rij(:) = mol%xyz(:, iat) - mol%xyz(:, jat)
         call get_wignerseitz_weights(cache%wsc, jat, iat, rij, weight)
         do img = 1, cache%wsc%nimg(jat, iat)
            vec = rij - cache%wsc%trans(:, cache%wsc%tridx(img, jat, iat))
            call get_amat_sdq_dir_3d(self, vec, dtrans, alpha, mrad, scale_di, scale_dj, &
               & t_sd, t_dd, t_sq, t_dq, t_qq)
            call get_amat_sdq_rec_3d(self, vec, rtrans, alpha, vol, mrad, scale_di, scale_dj, &
               & r_sd, r_dd, r_sq, r_dq, r_qq)
            amat_sd(:, jat, iat) = amat_sd(:, jat, iat) + weight(img) * (t_sd + r_sd)
            amat_dd(:, jat, :, iat) = amat_dd(:, jat, :, iat) + weight(img) * (t_dd + r_dd)
            amat_sq(:, jat, iat) = amat_sq(:, jat, iat) + weight(img) * (t_sq + r_sq)
            amat_dq(:, jat, :, iat) = amat_dq(:, jat, :, iat) + weight(img) * (t_dq + r_dq)
            amat_qq(:, jat, :, iat) = amat_qq(:, jat, :, iat) + weight(img) * (t_qq + r_qq)
         end do
      end do
   end do

   do iat = 1, mol%nat
      izp = mol%id(iat)
      sqrtcni = sqrt(cache%cn(iat) + cn_reg**2) - cn_reg
      scale_di = 1.0_wp + self%dip_scale(izp) * sqrtcni

      ! dipole-dipole selfenergy: -2/3·α³/sqrt(π) Σ(i) μ²(i)
      rr = -2.0_wp/3.0_wp * alpha**3 / sqrtpi * scale_di**2 * self%kdmp5
      amat_dd(1, iat, 1, iat) = amat_dd(1, iat, 1, iat) + 2*rr
      amat_dd(2, iat, 2, iat) = amat_dd(2, iat, 2, iat) + 2*rr
      amat_dd(3, iat, 3, iat) = amat_dd(3, iat, 3, iat) + 2*rr

      ! charge-quadrupole selfenergy: 4/9·α³/sqrt(π) Σ(i) q(i)Tr(θi)
      ! (no actual energy contribution since quadrupoles are traceless)
      rr = 4.0_wp/9.0_wp * alpha**3 / sqrtpi * self%kdmp5
      amat_sq([1, 3, 6], iat, iat) = amat_sq([1, 3, 6], iat, iat) + rr

      ! Charge-dipole and Dipole-quadrupole selfenergies are rigorously 0

      ! quadrupole-quadrupole selfenergy: -8/15·α⁵/sqrt(π) Σ(i) Trace(θi·θi)
      ! NOTE: 8/45 would be expected if 1/3 was not applied in energy calculation
      rr = -8.0_wp/15.0_wp * alpha**5 / sqrtpi * self%kdmp9

      ! Diagonal components (xx, yy, zz)
      amat_qq(1, iat, 1, iat) = amat_qq(1, iat, 1, iat) + 3*rr
      amat_qq(3, iat, 3, iat) = amat_qq(3, iat, 3, iat) + 3*rr
      amat_qq(6, iat, 6, iat) = amat_qq(6, iat, 6, iat) + 3*rr

      ! diagonal-diagonal cross terms
      amat_qq(1,iat,3,iat) = amat_qq(1,iat,3,iat) + rr
      amat_qq(3,iat,1,iat) = amat_qq(3,iat,1,iat) + rr
      amat_qq(1,iat,6,iat) = amat_qq(1,iat,6,iat) + rr
      amat_qq(6,iat,1,iat) = amat_qq(6,iat,1,iat) + rr
      amat_qq(3,iat,6,iat) = amat_qq(3,iat,6,iat) + rr
      amat_qq(6,iat,3,iat) = amat_qq(6,iat,3,iat) + rr

      ! Off-diagonal components (xy, xz, yz)
      amat_qq(2, iat, 2, iat) = amat_qq(2, iat, 2, iat) + 4*rr
      amat_qq(4, iat, 4, iat) = amat_qq(4, iat, 4, iat) + 4*rr
      amat_qq(5, iat, 5, iat) = amat_qq(5, iat, 5, iat) + 4*rr
   end do
end subroutine get_multipole_matrix_3d


!> Direct space contribution to Ewald summation
subroutine get_amat_sdq_dir_3d(self, rij, trans, alp, &
   & mrad, scale_di, scale_dj, &
   & t_sd, t_dd, t_sq, t_dq, t_qq)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Vector from atom j to atom i (ri - rj)
   real(wp), intent(in) :: rij(3)
   !> Lattice translation vectors
   real(wp), intent(in) :: trans(:, :)
   !> Ewald splitting parameter
   real(wp), intent(in) :: alp
   !> Multipole damping radius for this pair
   real(wp), intent(in) :: mrad
   !> Dipole scaling factor for atom i
   real(wp), intent(in) :: scale_di
   !> Dipole scaling factor for atom j
   real(wp), intent(in) :: scale_dj
   !> Accumulated charge-dipole matrix for this image
   real(wp), intent(out) :: t_sd(3)
   !> Accumulated dipole-dipole matrix for this image
   real(wp), intent(out) :: t_dd(3, 3)
   !> Accumulated charge-quadrupole matrix for this image
   real(wp), intent(out) :: t_sq(6)
   !> Accumulated dipole-quadrupole matrix for this image
   real(wp), intent(out) :: t_dq(3, 6)
   !> Accumulated quadrupole-quadrupole matrix for this image
   real(wp), intent(out) :: t_qq(6, 6)

   integer :: itr
   real(wp) :: vec(3), r1
   real(wp) :: g1, g2, g3, g5, g7, g9
   real(wp) :: x2, y2, z2, xy, xz, yz
   real(wp) :: dg3, dg5, dg7, dg9, fdmp3, fdmp5, fdmp7, fdmp9
   real(wp) :: tdd(3,3), tsq(6), tdq(3,6), tqq(6,6)
   real(wp) :: e1, e2, e3, e4, e1tmp, e2tmp, e3tmp, e4tmp, arg, alp2, expt, erft, arg2

   t_sd(:) = 0.0_wp
   t_dd(:, :) = 0.0_wp
   t_sq(:) = 0.0_wp
   t_dq(:, :) = 0.0_wp
   t_qq(:, :) = 0.0_wp
   alp2 = alp*alp

   do itr = 1, size(trans, 2)
      vec(:) = rij + trans(:, itr)
      r1 = norm2(vec)
      if (r1 < eps) cycle
      
      g1 = 1.0_wp / r1
      g2 = g1 * g1
      g3 = g1 * g2
      g5 = g3 * g2
      g7 = g5 * g2
      g9 = g7 * g2

      arg = r1*alp
      arg2 = arg*arg
      expt = exp(-arg2)/sqrtpi
      erft = -erf(arg)*g1
      e1 = g1*g1 * (erft + 2.0_wp*expt*alp)
      e2 = g1*g1 * (e1 +  4.0_wp/3.0_wp   * expt*alp2*alp)
      e3 = g1*g1 * (e2 +  8.0_wp/15.0_wp  * expt*alp2*alp2*alp)
      e4 = g1*g1 * (e3 + 16.0_wp/105.0_wp * expt*alp2*alp2*alp2*alp)

      ! Get the pairwise damping functions
      call self%get_damping_pair(r1, g1, mrad, fdmp3, fdmp5, &
         & fdmp7, fdmp9)

      ! Charge-dipole interaction
      dg3 = g3 * fdmp3 * scale_dj
      e1tmp = e1 * scale_dj * self%kdmp3
      t_sd(:) = t_sd + vec * (dg3 + e1tmp)

      ! Dipole-dipole interaction
      x2 = vec(1)*vec(1)
      y2 = vec(2)*vec(2)
      z2 = vec(3)*vec(3)
      xy = vec(1)*vec(2)
      xz = vec(1)*vec(3)
      yz = vec(2)*vec(3)
      dg3 = scale_dj * scale_di * (g3 * fdmp5 + self%kdmp5 * e1)
      dg5 = scale_dj * scale_di * (g5 * fdmp5 + self%kdmp5 * e2)
      tdd(1, 1) = -3.0_wp*x2*dg5 + dg3
      tdd(2, 1) = -3.0_wp*xy*dg5
      tdd(3, 1) = -3.0_wp*xz*dg5
      tdd(1, 2) = -3.0_wp*xy*dg5
      tdd(2, 2) = -3.0_wp*y2*dg5 + dg3
      tdd(3, 2) = -3.0_wp*yz*dg5
      tdd(1, 3) = -3.0_wp*xz*dg5
      tdd(2, 3) = -3.0_wp*yz*dg5
      tdd(3, 3) = -3.0_wp*z2*dg5 + dg3
      t_dd(:, :) = t_dd + tdd

      ! Charge-quadrupole interaction
      dg3 = g3 * fdmp5 + self%kdmp5 * e1
      dg5 = g5 * fdmp5 + self%kdmp5 * e2
      tsq(1) = x2*dg5 - dg3 / 3.0_wp
      tsq(2) = 2.0_wp*xy*dg5
      tsq(3) = y2*dg5 - dg3 / 3.0_wp
      tsq(4) = 2.0_wp*xz*dg5
      tsq(5) = 2.0_wp*yz*dg5
      tsq(6) = z2*dg5 - dg3 / 3.0_wp
      t_sq(:) = t_sq + tsq

      ! Dipole-quadrupole interaction
      dg7 = g7 * fdmp7 * scale_dj + e3 * scale_dj * self%kdmp7
      dg5 = g5 * fdmp7 * scale_dj + e2 * scale_dj * self%kdmp7
      
      tdq(1, 1) = -5.0_wp*dg7*x2*vec(1) + 3.0_wp*dg5*vec(1)
      tdq(2, 1) = -5.0_wp*dg7*xy*vec(1) + dg5*vec(2)
      tdq(3, 1) = -5.0_wp*dg7*xz*vec(1) + dg5*vec(3)
      tdq(1, 2) = -10.0_wp*dg7*x2*vec(2) + 2.0_wp*dg5*vec(2)
      tdq(2, 2) = -10.0_wp*dg7*y2*vec(1) + 2.0_wp*dg5*vec(1)
      tdq(3, 2) = -10.0_wp*dg7*xz*vec(2)
      tdq(1, 3) = -5.0_wp*dg7*xy*vec(2) + dg5*vec(1)
      tdq(2, 3) = -5.0_wp*dg7*y2*vec(2) + 3.0_wp*dg5*vec(2)
      tdq(3, 3) = -5.0_wp*dg7*yz*vec(2) + dg5*vec(3)
      tdq(1, 4) = -10.0_wp*dg7*x2*vec(3) + 2.0_wp*dg5*vec(3)
      tdq(2, 4) = -10.0_wp*dg7*xy*vec(3)
      tdq(3, 4) = -10.0_wp*dg7*z2*vec(1) + 2.0_wp*dg5*vec(1)
      tdq(1, 5) = -10.0_wp*dg7*xy*vec(3)
      tdq(2, 5) = -10.0_wp*dg7*y2*vec(3) + 2.0_wp*dg5*vec(3)
      tdq(3, 5) = -10.0_wp*dg7*z2*vec(2) + 2.0_wp*dg5*vec(2)
      tdq(1, 6) = -5.0_wp*dg7*xz*vec(3) + dg5*vec(1)
      tdq(2, 6) = -5.0_wp*dg7*yz*vec(3) + dg5*vec(2)
      tdq(3, 6) = -5.0_wp*dg7*z2*vec(3) + 3.0_wp*dg5*vec(3)
      t_dq(:, :) = t_dq - tdq

      ! Quadrupole-quadrupole interaction
      dg9 = g9 * fdmp9 + e4 * self%kdmp9
      dg7 = g7 * fdmp9 + e3 * self%kdmp9
      dg5 = g5 * fdmp9 + e2 * self%kdmp9
      
      ! NOTE:
      ! raw tensor: 6, 4.5, 1.5
      ! traceless convention: 4, 3, 1
      tqq(1, 1) = 35.0_wp*dg9*x2*x2 - 30.0_wp*dg7*x2 + 3.0_wp*dg5
      tqq(2, 1) = 70.0_wp*dg9*x2*xy - 30.0_wp*dg7*xy
      tqq(3, 1) = 35.0_wp*dg9*x2*y2 - 5.0_wp*dg7*(x2+y2) + 1.0_wp*dg5
      tqq(4, 1) = 70.0_wp*dg9*x2*xz - 30.0_wp*dg7*xz
      tqq(5, 1) = 70.0_wp*dg9*x2*yz - 10.0_wp*dg7*yz
      tqq(6, 1) = 35.0_wp*dg9*x2*z2 - 5.0_wp*dg7*(x2+z2) + 1.0_wp*dg5
      tqq(1, 2) = 70.0_wp*dg9*x2*xy - 30.0_wp*dg7*xy
      tqq(2, 2) = 140.0_wp*dg9*x2*y2 - 20.0_wp*dg7*(x2+y2) + 4.0_wp*dg5
      tqq(3, 2) = 70.0_wp*dg9*y2*xy - 30.0_wp*dg7*xy
      tqq(4, 2) = 140.0_wp*dg9*x2*yz - 20.0_wp*dg7*yz
      tqq(5, 2) = 140.0_wp*dg9*y2*xz - 20.0_wp*dg7*xz
      tqq(6, 2) = 70.0_wp*dg9*z2*xy - 10.0_wp*dg7*xy
      tqq(1, 3) = 35.0_wp*dg9*x2*y2 - 5.0_wp*dg7*(x2+y2) + 1.0_wp*dg5
      tqq(2, 3) = 70.0_wp*dg9*y2*xy - 30.0_wp*dg7*xy
      tqq(3, 3) = 35.0_wp*dg9*y2*y2 - 30.0_wp*dg7*y2 + 3.0_wp*dg5
      tqq(4, 3) = 70.0_wp*dg9*y2*xz - 10.0_wp*dg7*xz
      tqq(5, 3) = 70.0_wp*dg9*y2*yz - 30.0_wp*dg7*yz
      tqq(6, 3) = 35.0_wp*dg9*y2*z2 - 5.0_wp*dg7*(y2+z2) + 1.0_wp*dg5
      tqq(1, 4) = 70.0_wp*dg9*x2*xz - 30.0_wp*dg7*xz
      tqq(2, 4) = 140.0_wp*dg9*x2*yz - 20.0_wp*dg7*yz
      tqq(3, 4) = 70.0_wp*dg9*y2*xz - 10.0_wp*dg7*xz
      tqq(4, 4) = 140.0_wp*dg9*x2*z2 - 20.0_wp*dg7*(x2+z2) + 4.0_wp*dg5
      tqq(5, 4) = 140.0_wp*dg9*z2*xy - 20.0_wp*dg7*xy
      tqq(6, 4) = 70.0_wp*dg9*z2*xz - 30.0_wp*dg7*xz
      tqq(1, 5) = 70.0_wp*dg9*x2*yz - 10.0_wp*dg7*yz
      tqq(2, 5) = 140.0_wp*dg9*y2*xz - 20.0_wp*dg7*xz
      tqq(3, 5) = 70.0_wp*dg9*y2*yz - 30.0_wp*dg7*yz
      tqq(4, 5) = 140.0_wp*dg9*z2*xy - 20.0_wp*dg7*xy
      tqq(5, 5) = 140.0_wp*dg9*y2*z2 - 20.0_wp*dg7*(y2+z2) + 4.0_wp*dg5
      tqq(6, 5) = 70.0_wp*dg9*z2*yz - 30.0_wp*dg7*yz
      tqq(1, 6) = 35.0_wp*dg9*x2*z2 - 5.0_wp*dg7*(x2+z2) + 1.0_wp*dg5
      tqq(2, 6) = 70.0_wp*dg9*z2*xy - 10.0_wp*dg7*xy
      tqq(3, 6) = 35.0_wp*dg9*y2*z2 - 5.0_wp*dg7*(y2+z2) + 1.0_wp*dg5
      tqq(4, 6) = 70.0_wp*dg9*z2*xz - 30.0_wp*dg7*xz
      tqq(5, 6) = 70.0_wp*dg9*z2*yz - 30.0_wp*dg7*yz
      tqq(6, 6) = 35.0_wp*dg9*z2*z2 - 30.0_wp*dg7*z2 + 3.0_wp*dg5
      t_qq(:, :) = t_qq + tqq
   end do
end subroutine get_amat_sdq_dir_3d


!> Reciprocal space contribution to Ewald summation
subroutine get_amat_sdq_rec_3d(self, rij, trans, alp, vol, mrad, &
   & scale_di, scale_dj, r_sd, r_dd, r_sq, r_dq, r_qq)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Vector from atom j to atom i (ri - rj)
   real(wp), intent(in) :: rij(3)
   !> Lattice translation vectors
   real(wp), intent(in) :: trans(:, :)
   !> Ewald splitting parameter
   real(wp), intent(in) :: alp
   !> Volume of the central region
   real(wp), intent(in) :: vol
   !> Multipole damping radius for this pair
   real(wp), intent(in) :: mrad
   !> Dipole scaling factor for atom i
   real(wp), intent(in) :: scale_di
   !> Dipole scaling factor for atom j
   real(wp), intent(in) :: scale_dj
   !> Accumulated charge-dipole matrix for this image
   real(wp), intent(out) :: r_sd(3)
   !> Accumulated dipole-dipole matrix for this image
   real(wp), intent(out) :: r_dd(3, 3)
   !> Accumulated charge-quadrupole matrix for this image
   real(wp), intent(out) :: r_sq(6)
   !> Accumulated dipole-quadrupole matrix for this image
   real(wp), intent(out) :: r_dq(3, 6)
   !> Accumulated quadrupole-quadrupole matrix for this image
   real(wp), intent(out) :: r_qq(6, 6)

   real(wp) :: fac, vec(3), g2, gv, expk, sink, cosk, k_q(6), rtmp
   real(wp) :: x2, xy, y2, xz, yz, z2
   integer :: itr, i, j

   r_sd = 0.0_wp
   r_dd = 0.0_wp
   r_sq = 0.0_wp
   r_dq = 0.0_wp
   r_qq = 0.0_wp
   fac = 4*pi/vol

   ! k = 0 terms (surface convention)
   ! r_dd(1, 1) = fac/3.0_wp
   ! r_dd(2, 2) = fac/3.0_wp
   ! r_dd(3, 3) = fac/3.0_wp
   ! r_sq([1, 3, 6]) = -fac/9.0_wp

   do itr = 1, size(trans, 2)
      vec(:) = trans(:, itr)
      g2 = dot_product(vec, vec)
      if (g2 < eps) cycle
      
      gv = dot_product(rij, vec)
      expk = fac * exp(-0.25_wp * g2 / (alp * alp)) / g2
      sink = sin(gv) * expk
      cosk = cos(gv) * expk

      ! packed quadratic basis
      k_q(1) =          vec(1) * vec(1)
      k_q(2) = 2.0_wp * vec(1) * vec(2)
      k_q(3) =          vec(2) * vec(2)
      k_q(4) = 2.0_wp * vec(1) * vec(3)
      k_q(5) = 2.0_wp * vec(2) * vec(3)
      k_q(6) =          vec(3) * vec(3)

      rtmp = sink * scale_dj * self%kdmp3
      r_sd(:) = r_sd(:) + vec(:) * rtmp

      rtmp = -cosk / 3.0_wp * self%kdmp5
      r_sq(:) = r_sq(:) + k_q(:) * rtmp

      rtmp = cosk * scale_dj * scale_di * self%kdmp5
      do j = 1, 3
         do i = 1, 3
            r_dd(i, j) = r_dd(i, j) + vec(i) * vec(j) * rtmp
         end do
      end do

      rtmp = -sink / 3.0_wp * scale_dj * self%kdmp7
      do j = 1, 6
         do i = 1, 3
            r_dq(i, j) = r_dq(i, j) + vec(i) * k_q(j) * rtmp
         end do
      end do

      rtmp = cosk / 3.0_wp * self%kdmp9
      do j = 1, 6
         do i = 1, 6
            r_qq(i, j) = r_qq(i, j) + k_q(i) * k_q(j) * rtmp
         end do
      end do
   end do
end subroutine get_amat_sdq_rec_3d


!> Calculate derivatives of multipole interactions
subroutine get_multipole_gradient(self, mol, cache, qat, dpat, qpat, dEdcn, gradient, sigma)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(in) :: cache
   !> Atomic partial charges
   real(wp), contiguous, intent(in) :: qat(:)
   !> Atomic dipole moments
   real(wp), contiguous, intent(in) :: dpat(:, :)
   !> Atomic quadrupole moments
   real(wp), contiguous, intent(in) :: qpat(:, :)
   !> Derivative of the energy w.r.t. the coordination number
   real(wp), contiguous, intent(inout) :: dEdcn(:)
   !> Derivative of the energy w.r.t. atomic displacements
   real(wp), contiguous, intent(inout) :: gradient(:, :)
   !> Derivative of the energy w.r.t. strain deformations
   real(wp), contiguous, intent(inout) :: sigma(:, :)

   if (any(mol%periodic)) then
      call get_multipole_gradient_3d(self, mol, cache, qat, dpat, qpat, &
         & cache%alpha_multipole, dEdcn, gradient, sigma)
   else
      call get_multipole_gradient_0d(self, mol, cache, qat, dpat, qpat, &
         & dEdcn, gradient, sigma)
   end if
end subroutine get_multipole_gradient

!> Evaluate multipole derivatives for finite systems
subroutine get_multipole_gradient_0d(self, mol, cache, qat, dpat, qpat, &
   & dEdcn, gradient, sigma)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(in) :: cache
   !> Atomic partial charges
   real(wp), contiguous, intent(in) :: qat(:)
   !> Atomic dipole moments
   real(wp), contiguous, intent(in) :: dpat(:, :)
   !> Atomic quadrupole moments
   real(wp), contiguous, intent(in) :: qpat(:, :)
   !> Derivative of the energy w.r.t. the coordination number
   real(wp), contiguous, intent(inout) :: dEdcn(:)
   !> Derivative of the energy w.r.t. atomic displacements
   real(wp), contiguous, intent(inout) :: gradient(:, :)
   !> Derivative of the energy w.r.t. strain deformations
   real(wp), contiguous, intent(inout) :: sigma(:, :)

   integer :: iat, jat, izp, jzp
   real(wp) :: vec(3), r1, r2, g1, g2, g3, g5, g7, g9, g11
   real(wp) :: dG(3), dS(3, 3), dEdmrad, dEdsci, dEdscj, mrad, dmraddcni, dmraddcnj
   real(wp) :: fdmp3, fdmp5, fdmp7, fdmp9, dfdmp3dr, dfdmp5dr, dfdmp7dr, dfdmp9dr
   real(wp) :: dfdmp3dmrad, dfdmp5dmrad, dfdmp7dmrad, dfdmp9dmrad
   real(wp) :: esd, edd, esq, edq_g7, edq_g5, eqq_g9, eqq_g7, eqq_g5
   real(wp) :: sqrtcni, sqrtcnj, scale_di, scale_dj, dscale_didcn, dscale_djdcn
   real(wp) :: scale_dpati(3), scale_dpatj(3), dpiv, dpjv, dpi0v, dpj0v
   real(wp) :: dpidpj, dpi0dpj, dpj0dpi, qpiv(3), qpjv(3), vqpiv, vqpjv
   real(wp) :: qpidpj(3), qpjdpi(3), dpi0qpjv, dpj0qpiv, qpiqpjv(3), qpjqpiv(3)
   real(wp) :: tr_qpiqpj, dkernel3, dkernel5, dkernel7, dkernel9

   ! Thread-private array for reduction
   ! Set to 0 explicitly as the shared variants are potentially non-zero (inout)
   real(wp), allocatable :: dEdcn_local(:), gradient_local(:, :), sigma_local(:, :)

   !$omp parallel default(none) &
   !$omp shared(self, mol, cache, qat, dpat, qpat, dEdcn, gradient, sigma) &
   !$omp private(iat, jat, izp, jzp, r1, r2, vec, g1, g2, g3, g5, g7, g9, g11) &
   !$omp private(dG, dS, dEdmrad, dEdsci, dEdscj, mrad, dmraddcni, dmraddcnj) &
   !$omp private(fdmp3, fdmp5, fdmp7, fdmp9, dfdmp3dr, dfdmp5dr, dfdmp7dr, dfdmp9dr) &
   !$omp private(dfdmp3dmrad, dfdmp5dmrad, dfdmp7dmrad, dfdmp9dmrad) &
   !$omp private(esd, edd, esq, edq_g7, edq_g5, eqq_g9, eqq_g7, eqq_g5) &
   !$omp private(sqrtcni, sqrtcnj, scale_di, scale_dj, dscale_didcn, dscale_djdcn) &
   !$omp private(scale_dpati, scale_dpatj, dpiv, dpjv, dpi0v, dpj0v) &
   !$omp private(dpidpj, dpi0dpj, dpj0dpi, qpiv, qpjv, vqpiv, vqpjv) &
   !$omp private(qpidpj, qpjdpi, dpi0qpjv, dpj0qpiv, qpiqpjv, qpjqpiv) &
   !$omp private(tr_qpiqpj, dkernel3, dkernel5, dkernel7, dkernel9) &
   !$omp private(dEdcn_local, gradient_local, sigma_local)
   allocate(dEdcn_local(size(dEdcn)), source=0.0_wp)
   allocate(gradient_local(size(gradient, 1), size(gradient, 2)), source=0.0_wp)
   allocate(sigma_local(size(sigma, 1), size(sigma, 2)), source=0.0_wp)
   !$omp do schedule(runtime)
   do iat = 1, mol%nat
      izp = mol%id(iat)

      ! Get the scaled atomic dipole moments for atom i
      sqrtcni = sqrt(cache%cn(iat) + cn_reg**2) - cn_reg
      scale_di = 1.0_wp + self%dip_scale(izp) * sqrtcni
      dscale_didcn = self%dip_scale(izp) * 0.5_wp / (sqrtcni + cn_reg)
      scale_dpati(:) = dpat(:, iat) * scale_di

      do jat = 1, iat - 1
         jzp = mol%id(jat)

         ! Get the scaled atomic dipole moments for atom j
         sqrtcnj = sqrt(cache%cn(jat) + cn_reg**2) - cn_reg
         scale_dj = 1.0_wp + self%dip_scale(jzp) * sqrtcnj
         dscale_djdcn = self%dip_scale(jzp) * 0.5_wp / (sqrtcnj + cn_reg)
         scale_dpatj(:) = dpat(:, jat) * (1.0_wp + self%dip_scale(jzp) * sqrtcnj)

         ! Reset derivative accumulators
         dG(:) = 0.0_wp
         dS(:, :) = 0.0_wp
         dEdmrad = 0.0_wp
         dEdsci = 0.0_wp
         dEdscj = 0.0_wp

         ! Precompute the interatomic vector and distance
         vec(:) = mol%xyz(:, jat)-mol%xyz(:, iat)
         r1 = norm2(vec)
         r2 = r1 * r1
         ! Precompute powers of the inverse distance
         g1 = 1.0_wp/r1
         g2 = g1 * g1
         g3 = g2 * g1
         g5 = g3 * g2
         g7 = g5 * g2
         g9 = g7 * g2
         g11 = g9 * g2

         ! Get the multipole damping radii and their derivatives
         call self%get_mrad_derivs(cache, iat, jat, izp, jzp, mrad, &
            & dmraddcni, dmraddcnj)

         ! Get the pairwise damping functions and their derivatives
         call self%get_damping_derivs(r1, g1, mrad, fdmp3, fdmp5, &
            & fdmp7, fdmp9, dfdmp3dr, dfdmp5dr, dfdmp7dr, dfdmp9dr, &
            & dfdmp3dmrad, dfdmp5dmrad, dfdmp7dmrad, dfdmp9dmrad)

         ! Skip atom pairs with negligible multipole interactions
         if (abs(fdmp3) > eps) then
            ! Charge-dipole interaction
            ! Scalar products of (scaled) dipole moment and the interatomic vector
            dpiv = dot_product(scale_dpati, vec)
            dpi0v = dot_product(dpat(:, iat), vec)
            dpjv = dot_product(scale_dpatj, vec)
            dpj0v = dot_product(dpat(:, jat), vec)
            ! Scalar energy numerator for charge-dipole interaction
            esd = (qat(jat)*dpiv - qat(iat)*dpjv)
            ! Radial derivative of the charge-dipole interaction kernel
            dkernel3 = - 3.0_wp * g5 * fdmp3 + dfdmp3dr * g3 * g1
            ! Charge-dipole derivative w.r.t. the positions
            dG(:) = dG - dkernel3 * vec * esd &
               & + fdmp3 * g3 * (qat(iat)*scale_dpatj(:) - qat(jat)*scale_dpati(:))
            ! Charge-dipole derivative w.r.t. the multipole damping radius
            dEdmrad = dEdmrad + esd * dfdmp3dmrad * g3
            ! Charge-dipole derivative w.r.t. the dipole scaling factors
            dEdsci = dEdsci + qat(jat) * fdmp3 * g3 * dpi0v
            dEdscj = dEdscj - qat(iat) * fdmp3 * g3 * dpj0v
         end if

         ! Skip atom pairs with negligible multipole interactions
         if (abs(fdmp5) > eps) then 
            ! Dipole-dipole interaction
            ! Scalar product of (scaled) dipole moments
            dpidpj = dot_product(scale_dpatj, scale_dpati)
            dpi0dpj = dot_product(dpat(:, iat), scale_dpatj)
            dpj0dpi = dot_product(dpat(:, jat), scale_dpati)
            ! Scalar energy numerator for dipole-dipole interaction
            edd = dpidpj * r2 - 3.0_wp * dpjv * dpiv
            ! Radial derivative of the dipole-dipole interaction kernel
            dkernel5 = - 5.0_wp * g7 * fdmp5 + dfdmp5dr * g5 * g1
            ! Dipole-dipole derivative w.r.t. the positions
            dG(:) = dG - dkernel5 * vec * edd & 
               & - 2.0_wp * fdmp5 * g5 * dpidpj * vec & 
               & + 3.0_wp * fdmp5 * g5 * (dpiv * scale_dpatj(:) + dpjv * scale_dpati(:))
            ! Dipole-dipole derivative w.r.t. the multipole damping radius
            dEdmrad = dEdmrad + edd * g5 * dfdmp5dmrad
            ! Dipole-dipole derivative w.r.t. the dipole scaling factors
            dEdsci = dEdsci + fdmp5 * g5 * (r2 * dpi0dpj - 3.0_wp * dpjv * dpi0v)
            dEdscj = dEdscj + fdmp5 * g5 * (r2 * dpj0dpi - 3.0_wp * dpiv * dpj0v)


            ! Charge-quadrupole interaction
            ! Tensor products of quadrupole moments and interatomic vector
            qpiv(1) = qpat(1,iat)*vec(1) + qpat(2,iat)*vec(2) + qpat(4,iat)*vec(3)
            qpiv(2) = qpat(2,iat)*vec(1) + qpat(3,iat)*vec(2) + qpat(5,iat)*vec(3)
            qpiv(3) = qpat(4,iat)*vec(1) + qpat(5,iat)*vec(2) + qpat(6,iat)*vec(3)
            qpjv(1) = qpat(1,jat)*vec(1) + qpat(2,jat)*vec(2) + qpat(4,jat)*vec(3)
            qpjv(2) = qpat(2,jat)*vec(1) + qpat(3,jat)*vec(2) + qpat(5,jat)*vec(3)
            qpjv(3) = qpat(4,jat)*vec(1) + qpat(5,jat)*vec(2) + qpat(6,jat)*vec(3)
            ! Scalar vector-quadrupole-vector products
            vqpiv = dot_product(vec, qpiv)
            vqpjv = dot_product(vec, qpjv)
            ! Scalar energy numerator for the charge-quadrupole interaction
            esq = qat(jat) * vqpiv + qat(iat) * vqpjv
            ! Charge-quadrupole derivative w.r.t. the positions
            dG(:) = dG - dkernel5 * vec * esq &
               & - 2.0_wp * fdmp5 * g5 * (qat(iat) * qpjv(:) + qat(jat) * qpiv(:))
            ! Charge-quadrupole derivative w.r.t. the multipole damping radius
            dEdmrad = dEdmrad + esq * g5 * dfdmp5dmrad
         end if

         ! Skip atom pairs with negligible multipole interactions
         if (abs(fdmp7) > eps) then 
            ! Dipole-quadrupole interaction
            ! Tensor product of quadrupole and dipole moments
            qpidpj(1) = qpat(1,jat)*scale_dpati(1) + qpat(2,jat)*scale_dpati(2) &
               & + qpat(4,jat)*scale_dpati(3)
            qpidpj(2) = qpat(2,jat)*scale_dpati(1) + qpat(3,jat)*scale_dpati(2) &
               & + qpat(5,jat)*scale_dpati(3)
            qpidpj(3) = qpat(4,jat)*scale_dpati(1) + qpat(5,jat)*scale_dpati(2) &
               & + qpat(6,jat)*scale_dpati(3)
            qpjdpi(1) = qpat(1,iat)*scale_dpatj(1) + qpat(2,iat)*scale_dpatj(2) &
               & + qpat(4,iat)*scale_dpatj(3)
            qpjdpi(2) = qpat(2,iat)*scale_dpatj(1) + qpat(3,iat)*scale_dpatj(2) &
               & + qpat(5,iat)*scale_dpatj(3)
            qpjdpi(3) = qpat(4,iat)*scale_dpatj(1) + qpat(5,iat)*scale_dpatj(2) &
               & + qpat(6,iat)*scale_dpatj(3)
            ! Scalar product of unscaled dipole moment and quadrupole vector product
            dpi0qpjv = dot_product(dpat(:, iat), qpjv)
            dpj0qpiv = dot_product(dpat(:, jat), qpiv)
            ! Scalar energy numerator contributions for dipole-quadrupole interaction
            edq_g7 = - 5.0_wp * (dpiv * vqpjv - dpjv * vqpiv)
            edq_g5 = 2.0_wp * (dot_product(scale_dpati, qpjv) &
               & - dot_product(scale_dpatj, qpiv))
            ! Radial derivative of the dipole-quadrupole interaction kernel
            dkernel7 = - 7.0_wp * g9 * fdmp7 + dfdmp7dr * g7 * g1
            dkernel5 = - 5.0_wp * g7 * fdmp7 + dfdmp7dr * g5 * g1
            ! Dipole-quadrupole derivative w.r.t. the positions
            dG(:) = dG + vec * (edq_g7 * dkernel7 + edq_g5 * dkernel5) &
               & - 5.0_wp * fdmp7 * g7 * (scale_dpati(:)*vqpjv + 2.0_wp * dpiv * qpjv) &
               & + 5.0_wp * fdmp7 * g7 * (scale_dpatj(:)*vqpiv + 2.0_wp * dpjv * qpiv) &
               & + 2.0_wp * fdmp7 * g5 * (qpidpj(:) - qpjdpi(:))
            ! Dipole-quadrupole derivative w.r.t. the multipole damping radius
            dEdmrad = dEdmrad - (edq_g7 * g7 + edq_g5 * g5) * dfdmp7dmrad
            ! Dipole-quadrupole derivative w.r.t. the dipole scaling factors
            dEdsci = dEdsci - fdmp7 * (-5.0_wp*g7 * vqpjv * dpi0v + 2.0_wp*g5 * dpi0qpjv)
            dEdscj = dEdscj - fdmp7 * (+5.0_wp*g7 * vqpiv * dpj0v - 2.0_wp*g5 * dpj0qpiv)
         end if

         ! Skip atom pairs with negligible multipole interactions
         if (abs(fdmp9) > eps) then 
            ! Quadrupole-quadrupole interaction
            ! Tensor products of quadrupole moments and the quadrupole-vector products
            qpiqpjv(1) = qpat(1,iat)*qpjv(1) + qpat(2,iat)*qpjv(2) + qpat(4,iat)*qpjv(3)
            qpiqpjv(2) = qpat(2,iat)*qpjv(1) + qpat(3,iat)*qpjv(2) + qpat(5,iat)*qpjv(3)
            qpiqpjv(3) = qpat(4,iat)*qpjv(1) + qpat(5,iat)*qpjv(2) + qpat(6,iat)*qpjv(3)
            qpjqpiv(1) = qpat(1,jat)*qpiv(1) + qpat(2,jat)*qpiv(2) + qpat(4,jat)*qpiv(3)
            qpjqpiv(2) = qpat(2,jat)*qpiv(1) + qpat(3,jat)*qpiv(2) + qpat(5,jat)*qpiv(3)
            qpjqpiv(3) = qpat(4,jat)*qpiv(1) + qpat(5,jat)*qpiv(2) + qpat(6,jat)*qpiv(3)
            ! Trace of quadrupole-quadrupole product
            tr_qpiqpj = qpat(1,iat)*qpat(1,jat) + 2.0_wp*qpat(2,iat)*qpat(2,jat) & 
                  & + qpat(3,iat)*qpat(3,jat) + 2.0_wp*qpat(4,iat)*qpat(4,jat) &
                  & + 2.0_wp*qpat(5,iat)*qpat(5,jat) + qpat(6,iat)*qpat(6,jat)
            ! Scalar energy numerator contributions for quadrupole-quadrupole interaction
            eqq_g9 = (35.0_wp/3.0_wp) * vqpiv * vqpjv
            eqq_g7 = -(20.0_wp/3.0_wp) * dot_product(qpiv, qpjv)
            eqq_g5 = 1.0_wp * tr_qpiqpj
            ! Radial derivative of the quadrupole-quadrupole interaction kernel
            dkernel9 = - 9.0_wp * g11 * fdmp9 + dfdmp9dr * g9 * g1
            dkernel7 = - 7.0_wp * g9 * fdmp9 + dfdmp9dr * g7 * g1
            dkernel5 = - 5.0_wp * g7 * fdmp9 + dfdmp9dr * g5 * g1
            ! Quadrupole-quadrupole derivative w.r.t. the positions
            dG(:) = dG - vec * (eqq_g9 * dkernel9 + eqq_g7 * dkernel7 + eqq_g5 * dkernel5) &
               & - (70.0_wp/3.0_wp) * g9 * fdmp9 * (vqpjv * qpiv + vqpiv * qpjv) & 
               & + (20.0_wp/3.0_wp) * g7 * fdmp9 * (qpiqpjv + qpjqpiv)
            ! Quadrupole-quadrupole derivative w.r.t. the multipole damping radius
            dEdmrad = dEdmrad + (eqq_g9 * g9 + eqq_g7 * g7 + eqq_g5 * g5) * dfdmp9dmrad
         end if

         ! Calculate stress tensor contribution from the gradient for all terms
         dS(:, :) = dS - 0.5_wp * (spread(vec, 1, 3) * spread(dG, 2, 3) &
            & + spread(dG, 1, 3) * spread(vec, 2, 3))

         ! Accumulate contributions
         dEdcn_local(iat) = dEdcn_local(iat) + dEdmrad * dmraddcni &
            & + dEdsci * dscale_didcn
         dEdcn_local(jat) = dEdcn_local(jat) + dEdmrad * dmraddcnj &
            & + dEdscj * dscale_djdcn
         gradient_local(:, iat) = gradient_local(:, iat) + dG
         gradient_local(:, jat) = gradient_local(:, jat) - dG
         sigma_local(:, :) = sigma_local + dS
      end do
   end do
   !$omp end do
   !$omp critical (get_multipole_gradient_0d_)
   dEdcn(:) = dEdcn + dEdcn_local
   gradient(:, :) = gradient + gradient_local
   sigma(:, :) = sigma + sigma_local
   !$omp end critical (get_multipole_gradient_0d_)
   deallocate(dEdcn_local, gradient_local, sigma_local)
   !$omp end parallel

end subroutine get_multipole_gradient_0d

!> Evaluate multipole derivatives under 3D periodic boundary conditions
subroutine get_multipole_gradient_3d(self, mol, cache, qat, dpat, qpat, &
   & alpha, dEdcn, gradient, sigma)
   !> Instance of the multipole container
   class(damped_multipole), intent(in) :: self
   !> Molecular structure data
   type(structure_type), intent(in) :: mol
   !> Reusable data container
   type(coulomb_cache), intent(in) :: cache
   !> Atomic partial charges
   real(wp), contiguous, intent(in) :: qat(:)
   !> Atomic dipole moments
   real(wp), contiguous, intent(in) :: dpat(:, :)
   !> Atomic quadrupole moments
   real(wp), contiguous, intent(in) :: qpat(:, :)
   !> Ewald splitting parameter
   real(wp), intent(in) :: alpha
   !> Derivative of the energy w.r.t. the coordination number
   real(wp), contiguous, intent(inout) :: dEdcn(:)
   !> Derivative of the energy w.r.t. atomic displacements
   real(wp), contiguous, intent(inout) :: gradient(:, :)
   !> Derivative of the energy w.r.t. strain deformations
   real(wp), contiguous, intent(inout) :: sigma(:, :)

   integer :: iat, jat, izp, jzp, img
   logical :: need_weight_energy
   real(wp) :: dEdmrad, mrad, dmraddcni, dmraddcnj
   real(wp) :: sqrtcni, sqrtcnj, scale_di, scale_dj, dscale_didcn, dscale_djdcn
   real(wp) :: scale_dpati(3), scale_dpatj(3)
   real(wp) :: dpati2
   real(wp) :: vol, edir, erec, eimg
   real(wp), allocatable :: dtrans(:, :), rtrans(:, :)
   real(wp) :: dGd(3), dSd(3, 3), dEdscid, dEdscjd
   real(wp) :: dGr(3), dSr(3, 3), dEdscir, dEdscjr
   real(wp) :: dGt(3), dSt(3, 3), dEdmradt, dEdscit, dEdscjt, rij(3), vec(3)
   real(wp) :: weight(size(cache%wsc%tridx, 1))
   real(wp) :: dwdr(3, size(cache%wsc%tridx, 1))
   real(wp) :: dwdL(3, 3, size(cache%wsc%tridx, 1))

   ! Thread-private arrays for reduction
   real(wp), allocatable :: dEdcn_local(:), gradient_local(:, :), sigma_local(:, :)

   vol = abs(matdet_3x3(mol%lattice))
   call get_dir_trans(mol%lattice, alpha, cache%rcut_mp, dtrans)
   call get_rec_trans(mol%lattice, alpha, cache%kcut_mp, rtrans)

   !$omp parallel default(none) &
   !$omp shared(self, mol, cache, qat, dpat, qpat, alpha, dtrans, rtrans, dEdcn, gradient, sigma, vol) &
   !$omp private(iat, jat, izp, jzp, img) &
   !$omp private(dEdmrad, mrad, dmraddcni, dmraddcnj) &
   !$omp private(sqrtcni, sqrtcnj, scale_di, scale_dj, dscale_didcn, dscale_djdcn) &
   !$omp private(scale_dpati, scale_dpatj) &
   !$omp private(need_weight_energy, weight, dwdr, dwdL, dEdcn_local, gradient_local, sigma_local) &
   !$omp private(dGd, dSd, dEdscid, dEdscjd, dGr, dSr, dEdscir, dEdscjr) &
   !$omp private(dGt, dSt, dEdmradt, dEdscit, dEdscjt, rij, vec, edir, erec, eimg, dpati2)
   allocate(dEdcn_local(size(dEdcn)), source=0.0_wp)
   allocate(gradient_local(size(gradient, 1), size(gradient, 2)), source=0.0_wp)
   allocate(sigma_local(size(sigma, 1), size(sigma, 2)), source=0.0_wp)
   !$omp do schedule(runtime)
   do iat = 1, mol%nat
      izp = mol%id(iat)

      ! Get the scaled atomic dipole moments for atom i
      sqrtcni = sqrt(cache%cn(iat) + cn_reg**2) - cn_reg
      scale_di = 1.0_wp + self%dip_scale(izp) * sqrtcni
      dscale_didcn = self%dip_scale(izp) * 0.5_wp / (sqrtcni + cn_reg)
      scale_dpati(:) = dpat(:, iat) * scale_di

      ! Off-diagonal pairs: jat < iat
      do jat = 1, iat - 1
         jzp = mol%id(jat)

         ! Get the scaled atomic dipole moments for atom j
         sqrtcnj = sqrt(cache%cn(jat) + cn_reg**2) - cn_reg
         scale_dj = 1.0_wp + self%dip_scale(jzp) * sqrtcnj
         dscale_djdcn = self%dip_scale(jzp) * 0.5_wp / (sqrtcnj + cn_reg)
         scale_dpatj(:) = dpat(:, jat) * scale_dj

         ! Get the multipole damping radii and their derivatives
         call self%get_mrad_derivs(cache, iat, jat, izp, jzp, mrad, &
            & dmraddcni, dmraddcnj)

         rij(:) = mol%xyz(:, iat) - mol%xyz(:, jat)
         call get_wignerseitz_weights(cache%wsc, jat, iat, rij, weight, dwdr, dwdL)
         need_weight_energy = any(dwdr(:, :cache%wsc%nimg(jat, iat)) /= 0.0_wp) &
            & .or. any(dwdL(:, :, :cache%wsc%nimg(jat, iat)) /= 0.0_wp)

         do img = 1, cache%wsc%nimg(jat, iat)
            vec = rij - cache%wsc%trans(:, cache%wsc%tridx(img, jat, iat))
            call get_damat_sdq_dir_3d(self, vec, dtrans, alpha, &
               & mrad, scale_dpati, scale_dpatj, dpat(:,iat), dpat(:,jat), &
               & qat(iat), qat(jat), qpat(:,iat), qpat(:,jat), &
               & dGd, dSd, dEdmrad, dEdscid, dEdscjd, edir)
            call get_damat_sdq_rec_3d(self, vec, rtrans, &
               & alpha, vol, qat(iat), qat(jat), dpat(:, iat), dpat(:, jat), &
               & qpat(:,iat), qpat(:,jat), scale_di, scale_dj, &
               & dGr, dSr, dEdscir, dEdscjr, erec)
            eimg = 0.0_wp
            if (need_weight_energy) eimg = edir + erec

            gradient_local(:, iat) = gradient_local(:, iat) &
               & + (dGd + dGr) * weight(img) + eimg * dwdr(:, img)
            gradient_local(:, jat) = gradient_local(:, jat) &
               & - (dGd + dGr) * weight(img) - eimg * dwdr(:, img)
            sigma_local(:, :) = sigma_local + (dSd - dSr) * weight(img) &
               & + eimg * dwdL(:, :, img)
            dEdcn_local(iat) = dEdcn_local(iat) + weight(img) * &
               & (dEdmrad * dmraddcni + (dEdscid + dEdscir) * dscale_didcn)
            dEdcn_local(jat) = dEdcn_local(jat) + weight(img) * &
               & (dEdmrad * dmraddcnj + (dEdscjd + dEdscjr) * dscale_djdcn)
         end do
      end do

      ! Self-image: only sigma and dEdcn, no gradient
      call self%get_mrad_derivs(cache, iat, iat, izp, izp, mrad, &
         & dmraddcni, dmraddcnj)

      rij(:) = 0.0_wp
      call get_wignerseitz_weights(cache%wsc, iat, iat, rij, weight, dwdr, dwdL)
      need_weight_energy = any(dwdL(:, :, :cache%wsc%nimg(iat, iat)) /= 0.0_wp)
      do img = 1, cache%wsc%nimg(iat, iat)
         vec = rij - cache%wsc%trans(:, cache%wsc%tridx(img, iat, iat))
         call get_damat_sdq_dir_3d(self, vec, dtrans, alpha, &
            & mrad, scale_dpati, scale_dpati, dpat(:,iat), dpat(:,iat), &
            & qat(iat), qat(iat), qpat(:,iat), qpat(:,iat), &
            & dGt, dSt, dEdmradt, dEdscit, dEdscjt, edir)
         call get_damat_sdq_rec_3d(self, vec, rtrans, &
            & alpha, vol, qat(iat), qat(iat), dpat(:, iat), dpat(:, iat), &
            & qpat(:,iat), qpat(:,iat), scale_di, scale_di, &
            & dGr, dSr, dEdscir, dEdscjr, erec)
         eimg = 0.0_wp
         if (need_weight_energy) eimg = edir + erec

         ! For self-terms we need extra factor 1/2 because of double-counting
         sigma_local(:, :) = sigma_local + 0.5_wp * &
            & ((dSt - dSr) * weight(img) + eimg * dwdL(:, :, img))
         dEdcn_local(iat) = dEdcn_local(iat) + 0.5_wp * weight(img) * &
            & (dEdmradt * (dmraddcni + dmraddcnj) &
            & + (dEdscit + dEdscjt + dEdscir + dEdscjr) * dscale_didcn)
      end do

      ! Self-energy derivative of the dipole moment
      dpati2 = dot_product(dpat(:, iat), dpat(:, iat))
      dEdcn_local(iat) = dEdcn_local(iat) &
         & - (4.0_wp/3.0_wp) * alpha**3 / sqrtpi * self%kdmp5 &
         & * scale_di * dpati2 * dscale_didcn
   end do
   !$omp end do
   !$omp critical (get_multipole_gradient_3d_)
   dEdcn(:) = dEdcn + dEdcn_local
   gradient(:, :) = gradient + gradient_local
   sigma(:, :) = sigma + sigma_local
   !$omp end critical (get_multipole_gradient_3d_)
   deallocate(dEdcn_local, gradient_local, sigma_local)
   !$omp end parallel

end subroutine get_multipole_gradient_3d


subroutine get_damat_sdq_dir_3d(self, rij, trans, alp, &
   & mrad, scale_dpati, scale_dpatj, dpati, dpatj, qati, qatj, &
   & qpati, qpatj, dG, dS, dEdmrad, dEdsci, dEdscj, energy)
   class(damped_multipole), intent(in) :: self
   real(wp), intent(in) :: rij(3)
   real(wp), intent(in) :: trans(:, :)
   real(wp), intent(in) :: alp
   real(wp), intent(in) :: mrad
   real(wp), intent(in) :: scale_dpati(3)
   real(wp), intent(in) :: scale_dpatj(3)
   real(wp), intent(in) :: dpati(3)
   real(wp), intent(in) :: dpatj(3)
   real(wp), intent(in) :: qati
   real(wp), intent(in) :: qatj
   real(wp), intent(in) :: qpati(6)
   real(wp), intent(in) :: qpatj(6)
   real(wp), intent(out) :: dG(3)
   real(wp), intent(out) :: dS(3, 3)
   real(wp), intent(out) :: dEdmrad
   real(wp), intent(out) :: dEdsci
   real(wp), intent(out) :: dEdscj
   real(wp), intent(out), optional :: energy

   integer :: itr
   real(wp) :: vec(3), r1, r2, g1, g2, g3, g5, g7, g9, g11
   real(wp) :: dGt(3), dSt(3, 3), dEdmradt, dEdscit, dEdscjt
   real(wp) :: fdmp3, fdmp5, fdmp7, fdmp9
   real(wp) :: dfdmp3dr, dfdmp5dr, dfdmp7dr, dfdmp9dr
   real(wp) :: dfdmp3dmrad, dfdmp5dmrad, dfdmp7dmrad, dfdmp9dmrad
   real(wp) :: esd, edd, esq, edq_g7, edq_g5, eqq_g9, eqq_g7, eqq_g5
   real(wp) :: dpiv, dpjv, dpi0v, dpj0v
   real(wp) :: dpidpj, dpi0dpj, dpj0dpi
   real(wp) :: qpiv(3), qpjv(3), vqpiv, vqpjv
   real(wp) :: qpidpj(3), qpjdpi(3), dpi0qpjv, dpj0qpiv
   real(wp) :: qpiqpjv(3), qpjqpiv(3), tr_qpiqpj, tr_qpi, tr_qpj, ctr
   real(wp) :: kernel3, kernel5, kernel7, kernel9
   real(wp) :: dkernel3, dkernel5, dkernel7, dkernel9
   real(wp) :: e1, e2, e3, e4, e5, arg, arg2, expt, erft, alp2

   dG(:) = 0.0_wp
   dS(:, :) = 0.0_wp
   dEdmrad = 0.0_wp
   dEdsci = 0.0_wp
   dEdscj = 0.0_wp
   if (present(energy)) energy = 0.0_wp
   alp2 = alp*alp

   do itr = 1, size(trans, 2)
      vec(:) = -(rij + trans(:, itr))
      r1 = norm2(vec)
      if (r1 < eps) cycle

      dGt = 0.0_wp
      dEdmradt = 0.0_wp
      dEdscit = 0.0_wp
      dEdscjt = 0.0_wp

      r2 = r1 * r1
      g1 = 1.0_wp / r1
      g2 = g1 * g1
      g3 = g2 * g1
      g5 = g3 * g2
      g7 = g5 * g2
      g9 = g7 * g2
      g11 = g9 * g2

      arg = alp * r1
      arg2 = arg * arg
      expt = exp(-arg2) / sqrtpi
      erft = -erf(arg) * g1

      e1 = g2 * (erft + 2.0_wp*expt*alp)
      e2 = g2 * (e1 +  4.0_wp/3.0_wp   * expt*alp2*alp)
      e3 = g2 * (e2 +  8.0_wp/15.0_wp  * expt*alp2*alp2*alp)
      e4 = g2 * (e3 + 16.0_wp/105.0_wp * expt*alp2*alp2*alp2*alp)
      e5 = g2 * (e4 + 32.0_wp/945.0_wp * expt*alp2*alp2*alp2*alp2*alp)

      ! Get the pairwise damping functions and their derivatives
      call self%get_damping_derivs(r1, g1, mrad, fdmp3, fdmp5, &
         & fdmp7, fdmp9, dfdmp3dr, dfdmp5dr, dfdmp7dr, dfdmp9dr, &
         & dfdmp3dmrad, dfdmp5dmrad, dfdmp7dmrad, dfdmp9dmrad)

      dpiv = dot_product(scale_dpati, vec)
      dpi0v = dot_product(dpati, vec)
      dpjv = dot_product(scale_dpatj, vec)
      dpj0v = dot_product(dpatj, vec)

      qpiv(1) = qpati(1)*vec(1) + qpati(2)*vec(2) + qpati(4)*vec(3)
      qpiv(2) = qpati(2)*vec(1) + qpati(3)*vec(2) + qpati(5)*vec(3)
      qpiv(3) = qpati(4)*vec(1) + qpati(5)*vec(2) + qpati(6)*vec(3)
      qpjv(1) = qpatj(1)*vec(1) + qpatj(2)*vec(2) + qpatj(4)*vec(3)
      qpjv(2) = qpatj(2)*vec(1) + qpatj(3)*vec(2) + qpatj(5)*vec(3)
      qpjv(3) = qpatj(4)*vec(1) + qpatj(5)*vec(2) + qpatj(6)*vec(3)

      vqpiv = dot_product(vec, qpiv)
      vqpjv = dot_product(vec, qpjv)

      qpidpj(1) = qpatj(1)*scale_dpati(1) + qpatj(2)*scale_dpati(2) &
         & + qpatj(4)*scale_dpati(3)
      qpidpj(2) = qpatj(2)*scale_dpati(1) + qpatj(3)*scale_dpati(2) &
         & + qpatj(5)*scale_dpati(3)
      qpidpj(3) = qpatj(4)*scale_dpati(1) + qpatj(5)*scale_dpati(2) &
         & + qpatj(6)*scale_dpati(3)
      qpjdpi(1) = qpati(1)*scale_dpatj(1) + qpati(2)*scale_dpatj(2) &
         & + qpati(4)*scale_dpatj(3)
      qpjdpi(2) = qpati(2)*scale_dpatj(1) + qpati(3)*scale_dpatj(2) &
         & + qpati(5)*scale_dpatj(3)
      qpjdpi(3) = qpati(4)*scale_dpatj(1) + qpati(5)*scale_dpatj(2) &
         & + qpati(6)*scale_dpatj(3)

      dpi0qpjv = dot_product(dpati, qpjv)
      dpj0qpiv = dot_product(dpatj, qpiv)

      qpiqpjv(1) = qpati(1)*qpjv(1) + qpati(2)*qpjv(2) + qpati(4)*qpjv(3)
      qpiqpjv(2) = qpati(2)*qpjv(1) + qpati(3)*qpjv(2) + qpati(5)*qpjv(3)
      qpiqpjv(3) = qpati(4)*qpjv(1) + qpati(5)*qpjv(2) + qpati(6)*qpjv(3)
      qpjqpiv(1) = qpatj(1)*qpiv(1) + qpatj(2)*qpiv(2) + qpatj(4)*qpiv(3)
      qpjqpiv(2) = qpatj(2)*qpiv(1) + qpatj(3)*qpiv(2) + qpatj(5)*qpiv(3)
      qpjqpiv(3) = qpatj(4)*qpiv(1) + qpatj(5)*qpiv(2) + qpatj(6)*qpiv(3)
      tr_qpiqpj = qpati(1)*qpatj(1) + 2.0_wp*qpati(2)*qpatj(2) &
         & + qpati(3)*qpatj(3) + 2.0_wp*qpati(4)*qpatj(4) &
         & + 2.0_wp*qpati(5)*qpatj(5) + qpati(6)*qpatj(6)

      tr_qpi = qpati(1) + qpati(3) + qpati(6)
      tr_qpj = qpatj(1) + qpatj(3) + qpatj(6)
      ctr = qatj * tr_qpi + qati * tr_qpj

      if (abs(fdmp3) > eps) then
         ! Charge-dipole
         esd = qatj * dpiv - qati * dpjv
         kernel3 = fdmp3 * g3 + self%kdmp3 * e1
         dkernel3 = -3.0_wp * g5 * fdmp3 + dfdmp3dr * g3 * g1 - 3.0_wp * self%kdmp3 * e2

         if (present(energy)) energy = energy + kernel3 * esd

         dGt(:) = dGt - dkernel3 * vec * esd &
            & + kernel3 * (qati * scale_dpatj(:) - qatj * scale_dpati(:))
         dEdmradt = dEdmradt + esd * dfdmp3dmrad * g3
         dEdscit = dEdscit + qatj * kernel3 * dpi0v
         dEdscjt = dEdscjt - qati * kernel3 * dpj0v
      end if

      if (abs(fdmp5) > eps) then
         ! Dipole-dipole
         dpidpj = dot_product(scale_dpatj, scale_dpati)
         dpi0dpj = dot_product(dpati, scale_dpatj)
         dpj0dpi = dot_product(dpatj, scale_dpati)

         edd = dpidpj * r2 - 3.0_wp * dpjv * dpiv
         kernel3 = fdmp5 * g3 + self%kdmp5 * e1
         kernel5 = fdmp5 * g5 + self%kdmp5 * e2
         dkernel3 = -3.0_wp * g5 * fdmp5 + dfdmp5dr * g3 * g1 - 3.0_wp * self%kdmp5 * e2
         dkernel5 = -5.0_wp * g7 * fdmp5 + dfdmp5dr * g5 * g1 - 5.0_wp * self%kdmp5 * e3

         if (present(energy)) then
            energy = energy + kernel3 * dpidpj - 3.0_wp * kernel5 * dpiv * dpjv
         end if

         dGt(:) = dGt - dkernel3 * vec(:) * dpidpj &
            & + 3.0_wp * dkernel5 * vec(:) * dpiv * dpjv &
            & + 3.0_wp * kernel5 * (dpiv * scale_dpatj(:) + dpjv * scale_dpati(:))
         dEdmradt = dEdmradt + (dpidpj * g3 - 3.0_wp * dpiv * dpjv * g5) * dfdmp5dmrad
         dEdscit = dEdscit + kernel3 * dpi0dpj - 3.0_wp * kernel5 * dpjv * dpi0v
         dEdscjt = dEdscjt + kernel3 * dpj0dpi - 3.0_wp * kernel5 * dpiv * dpj0v

         ! Charge-quadrupole
         esq = qatj * vqpiv + qati * vqpjv
         kernel3 = fdmp5 * g3 + self%kdmp5 * e1
         kernel5 = fdmp5 * g5 + self%kdmp5 * e2
         dkernel3 = -3.0_wp * fdmp5 * g5 + dfdmp5dr * g3 * g1 - 3.0_wp * self%kdmp5 * e2
         dkernel5 = -5.0_wp * fdmp5 * g7 + dfdmp5dr * g5 * g1 - 5.0_wp * self%kdmp5 * e3

         if (present(energy)) energy = energy + kernel5 * esq - ctr / 3.0_wp * kernel3

         dGt(:) = dGt(:) - dkernel5 * vec(:) * esq &
            & - 2.0_wp * kernel5 * (qati * qpjv(:) + qatj * qpiv(:)) &
            & + ctr / 3.0_wp * dkernel3 * vec(:)
         dEdmradt = dEdmradt + esq * g5 * dfdmp5dmrad &
            & - ctr / 3.0_wp * g3 * dfdmp5dmrad
      end if

      if (abs(fdmp7) > eps) then
         ! Dipole-quadrupole
         edq_g7 = -5.0_wp * (dpiv * vqpjv - dpjv * vqpiv)
         edq_g5 = 2.0_wp * (dot_product(scale_dpati, qpjv) &
            & - dot_product(scale_dpatj, qpiv))

         kernel7 = fdmp7 * g7 + self%kdmp7 * e3
         kernel5 = fdmp7 * g5 + self%kdmp7 * e2
         dkernel7 = -7.0_wp * g9 * fdmp7 + dfdmp7dr * g7 * g1 - 7.0_wp * self%kdmp7 * e4
         dkernel5 = -5.0_wp * g7 * fdmp7 + dfdmp7dr * g5 * g1 - 5.0_wp * self%kdmp7 * e3

         if (present(energy)) energy = energy - edq_g7 * kernel7 - edq_g5 * kernel5

         dGt(:) = dGt + vec * (edq_g7 * dkernel7 + edq_g5 * dkernel5) &
            & - 5.0_wp * kernel7 * (scale_dpati(:)*vqpjv + 2.0_wp * dpiv * qpjv) &
            & + 5.0_wp * kernel7 * (scale_dpatj(:)*vqpiv + 2.0_wp * dpjv * qpiv) &
            & + 2.0_wp * kernel5 * (qpidpj(:) - qpjdpi(:))
         dEdmradt = dEdmradt - (edq_g7 * g7 + edq_g5 * g5) * dfdmp7dmrad
         dEdscit = dEdscit + 5.0_wp * kernel7 * vqpjv * dpi0v - 2.0_wp * kernel5 * dpi0qpjv
         dEdscjt = dEdscjt - 5.0_wp * kernel7 * vqpiv * dpj0v + 2.0_wp * kernel5 * dpj0qpiv
      end if

      if (abs(fdmp9) > eps) then
         ! Quadrupole-quadrupole
         eqq_g9 = (35.0_wp/3.0_wp) * vqpiv * vqpjv
         eqq_g7 = -(20.0_wp/3.0_wp) * dot_product(qpiv, qpjv)
         eqq_g5 = (2.0_wp * tr_qpiqpj + tr_qpi * tr_qpj) / 3.0_wp

         kernel9 = fdmp9 * g9 + self%kdmp9 * e4
         kernel7 = fdmp9 * g7 + self%kdmp9 * e3
         kernel5 = fdmp9 * g5 + self%kdmp9 * e2
         dkernel9 = -9.0_wp * g11 * fdmp9 + dfdmp9dr * g9 * g1 - 9.0_wp * self%kdmp9 * e5
         dkernel7 = -7.0_wp * g9 * fdmp9 + dfdmp9dr * g7 * g1 - 7.0_wp * self%kdmp9 * e4
         dkernel5 = -5.0_wp * g7 * fdmp9 + dfdmp9dr * g5 * g1 - 5.0_wp * self%kdmp9 * e3

         if (present(energy)) then
            energy = energy + eqq_g9 * kernel9 + eqq_g7 * kernel7 + eqq_g5 * kernel5
         end if

         dGt(:) = dGt - vec * (eqq_g9 * dkernel9 + eqq_g7 * dkernel7 &
            & + eqq_g5 * dkernel5) &
            & - (70.0_wp/3.0_wp) * kernel9 * (vqpjv * qpiv(:) + vqpiv * qpjv(:)) &
            & + (20.0_wp/3.0_wp) * kernel7 * (qpiqpjv(:) + qpjqpiv(:))
         dEdmradt = dEdmradt + (eqq_g9 * g9 + eqq_g7 * g7 + eqq_g5 * g5) &
            & * dfdmp9dmrad
      end if

      ! Calculate stress tensor contribution
      dSt(:, :) = -0.5_wp * (spread(vec, 1, 3) * spread(dGt, 2, 3) &
         & + spread(dGt, 1, 3) * spread(vec, 2, 3))

      dG(:) = dG + dGt
      dS(:, :) = dS + dSt

      dEdmrad = dEdmrad + dEdmradt
      dEdsci = dEdsci + dEdscit
      dEdscj = dEdscj + dEdscjt
   end do

end subroutine get_damat_sdq_dir_3d


subroutine get_damat_sdq_rec_3d(self, rij, trans, alp, vol, &
   & qi, qj, mi, mj, ti, tj, scale_di, scale_dj, dG, dS, dEdsci, dEdscj, energy)

   class(damped_multipole), intent(in) :: self
   real(wp), intent(in) :: rij(3)
   real(wp), intent(in) :: trans(:, :)
   real(wp), intent(in) :: alp
   real(wp), intent(in) :: vol
   real(wp), intent(in) :: qi, qj
   real(wp), intent(in) :: mi(3), mj(3)
   real(wp), intent(in) :: ti(6), tj(6)
   real(wp), intent(in) :: scale_di, scale_dj
   real(wp), intent(out) :: dG(3)
   real(wp), intent(out) :: dS(3, 3)
   real(wp), intent(out) :: dEdsci, dEdscj
   real(wp), intent(out), optional :: energy

   real(wp) :: fac, alp2, qfac, qqfac
   real(wp) :: vec(3), g2, gv, expk, sink, cosk, metr
   real(wp) :: smi(3), smj(3)
   real(wp) :: di0, dj0, di, dj
   real(wp) :: tik(3), tjk(3), wi, wj
   real(wp) :: csd, cdd, csq, cdq, cqq
   real(wp) :: bsd, bdd, bsq, bdq, bqq
   integer :: itr, a, b
   real(wp), parameter :: unity(3, 3) = reshape(&
      & [1, 0, 0, 0, 1, 0, 0, 0, 1], [3, 3])

   dG(:) = 0.0_wp
   dS(:, :) = 0.0_wp
   dEdsci = 0.0_wp
   dEdscj = 0.0_wp
   if (present(energy)) energy = 0.0_wp

   fac = 4*pi/vol
   alp2 = alp*alp

   qfac  = 1.0_wp / 3.0_wp
   qqfac = qfac*qfac

   smi(:) = scale_di * mi(:)
   smj(:) = scale_dj * mj(:)

   do itr = 1, size(trans, 2)
      vec(:) = trans(:, itr)
      g2 = dot_product(vec, vec)
      if (g2 < eps) cycle

      gv = dot_product(rij, vec)
      expk = fac * exp(-0.25_wp * g2 / alp2) / g2
      sink = sin(gv) * expk
      cosk = cos(gv) * expk

      ! k·mu
      di0 = dot_product(vec, mi)
      dj0 = dot_product(vec, mj)
      di  = scale_di * di0
      dj  = scale_dj * dj0

      ! Q·k
      tik(1) = ti(1)*vec(1) + ti(2)*vec(2) + ti(4)*vec(3)
      tik(2) = ti(2)*vec(1) + ti(3)*vec(2) + ti(5)*vec(3)
      tik(3) = ti(4)*vec(1) + ti(5)*vec(2) + ti(6)*vec(3)

      tjk(1) = tj(1)*vec(1) + tj(2)*vec(2) + tj(4)*vec(3)
      tjk(2) = tj(2)*vec(1) + tj(3)*vec(2) + tj(5)*vec(3)
      tjk(3) = tj(4)*vec(1) + tj(5)*vec(2) + tj(6)*vec(3)

      ! k·Q·k
      wi = dot_product(vec, tik)
      wj = dot_product(vec, tjk)

      ! scalar amplitudes
      csd = qj*di - qi*dj
      cdd = di*dj
      csq = qj*wi + qi*wj
      cdq = di*wj - dj*wi
      cqq = wi*wj

      if (present(energy)) then
         energy = energy - sink * self%kdmp3 * csd &
            & + cosk * self%kdmp5 * cdd &
            & - cosk * self%kdmp5 * qfac * csq &
            & + sink * self%kdmp7 * qfac * cdq &
            & + cosk * self%kdmp9 * qqfac * cqq
      end if

      ! Cartesian derivative
      dG(:) = dG(:) &
         & - vec(:) * cosk * self%kdmp3 * csd &
         & - vec(:) * sink * self%kdmp5 * cdd &
         & + vec(:) * sink * self%kdmp5 * qfac  * csq &
         & + vec(:) * cosk * self%kdmp7 * qfac  * cdq &
         & - vec(:) * sink * self%kdmp9 * qqfac * cqq

      ! derivatives wrt dipole scaling factors
      dEdsci = dEdsci &
         & - sink * self%kdmp3 * qj * di0 &
         & + cosk * self%kdmp5 * di0 * dj &
         & + sink * self%kdmp7 * qfac * di0 * wj

      dEdscj = dEdscj &
         & + sink * self%kdmp3 * qi * dj0 &
         & + cosk * self%kdmp5 * dj0 * di &
         & - sink * self%kdmp7 * qfac * dj0 * wi

      do b = 1, 3
         do a = 1, 3
            metr = (2.0_wp/g2 + 0.5_wp/alp2) * vec(a)*vec(b) - unity(a, b)

            bsd = vec(a) * (qj*smi(b) - qi*smj(b)) &
               & + vec(b) * (qj*smi(a) - qi*smj(a))

            bdd = vec(a) * (smi(b)*dj + smj(b)*di) &
               & + vec(b) * (smi(a)*dj + smj(a)*di)

            bsq = vec(a) * (qj*tik(b) + qi*tjk(b)) &
               & + vec(b) * (qj*tik(a) + qi*tjk(a))

            bdq = vec(a) * (smi(b)*wj + 2.0_wp*di*tjk(b) - smj(b)*wi - 2.0_wp*dj*tik(b)) &
               & + vec(b) * (smi(a)*wj + 2.0_wp*di*tjk(a) - smj(a)*wi - 2.0_wp*dj*tik(a))

            bqq = vec(a) * (wi*tjk(b) + wj*tik(b)) &
               & + vec(b) * (wi*tjk(a) + wj*tik(a))

            dS(a, b) = dS(a, b) &
               & +          sink * self%kdmp3 * csd * metr &
               & - 0.5_wp * sink * self%kdmp3 * bsd &
               & -          cosk * self%kdmp5 * cdd * metr &
               & + 0.5_wp * cosk * self%kdmp5 * bdd &
               & +          cosk * self%kdmp5 * qfac  * csq * metr &
               & -          cosk * self%kdmp5 * qfac  * bsq &
               & -          sink * self%kdmp7 * qfac  * cdq * metr &
               & + 0.5_wp * sink * self%kdmp7 * qfac  * bdq &
               & -          cosk * self%kdmp9 * qqfac * cqq * metr &
               & +          cosk * self%kdmp9 * qqfac * bqq
         end do
      end do
   end do
end subroutine get_damat_sdq_rec_3d


!> Get information about density dependent quantities used in the energy
pure function variable_info(self) result(info)
   use tblite_scf_info, only : scf_info, atom_resolved
   !> Instance of the electrostatic container
   class(damped_multipole), intent(in) :: self
   !> Information on the required potential data
   type(scf_info) :: info

   info = scf_info(dipole=atom_resolved, quadrupole=atom_resolved)
end function variable_info


!> Return reference to container cache after resolving its type
subroutine view(cache, ptr)
   !> Instance of the container cache
   type(container_cache), target, intent(inout) :: cache
   !> Reference to the container cache
   type(coulomb_cache), pointer, intent(out) :: ptr
   nullify(ptr)
   select type(target => cache%raw)
   type is(coulomb_cache)
      ptr => target
   end select
end subroutine view

end module tblite_coulomb_multipole_type
