# This file is part of tblite.
# SPDX-Identifier: LGPL-3.0-or-later
#
# tblite is free software: you can redistribute it and/or modify it under
# the terms of the GNU Lesser General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
#
# tblite is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU Lesser General Public License for more details.
#
# You should have received a copy of the GNU Lesser General Public License
# along with tblite.  If not, see <https://www.gnu.org/licenses/>.
"""Tests for the qcelemental interface."""
from typing import Any, Dict, Optional

import numpy as np
import pytest

try:
    from tblite.qcschema import qcel_v1, qcel_v2, run_schema
except ModuleNotFoundError:
    qcel_v1 = None
    qcel_v2 = None

v1_available = pytest.mark.skipif(
    qcel_v1 is None, reason="QCSchema v1 not available for py314+"
)
v2_available = pytest.mark.skipif(
    qcel_v2 is None, reason="QCSchema v2 not available in current QCElemental"
)


@pytest.fixture(
    params=[pytest.param(1, marks=v1_available), pytest.param(2, marks=v2_available)]
)
def qcsk_version(request):
    return request.param


@pytest.fixture
def multiplicity(request) -> int:
    """Multiplicity fixture."""
    return getattr(request, "param", 1)


@pytest.fixture(params=["ala-xab"])
def molecule(request, multiplicity: int, qcsk_version: int) -> "Molecule":
    """Get a molecule for testing."""
    if qcsk_version == 1:
        Molecule = qcel_v1.Molecule
    elif qcsk_version == 2:
        Molecule = qcel_v2.Molecule

    if request.param == "ala-xab":
        return Molecule(
            symbols=list("NHCHCCHHHOCCHHHONHCHHH"),
            geometry=np.array(
                [
                    [+2.65893135608838, -2.39249423371715, -3.66065400053935],
                    [+3.49612941769371, -0.88484673975624, -2.85194146578362],
                    [-0.06354076626069, -2.63180732150005, -3.28819116275323],
                    [-1.07444177498884, -1.92306930149582, -4.93716401361053],
                    [-0.83329925447427, -5.37320588052218, -2.81379718546920],
                    [-0.90691285352090, -1.04371377845950, -1.04918016247507],
                    [-2.86418317801214, -5.46484901686185, -2.49961410229771],
                    [-0.34235262692151, -6.52310417728877, -4.43935278498325],
                    [+0.13208660968384, -6.10946566962768, -1.15032982743173],
                    [-2.96060093623907, +0.01043357425890, -0.99937552379387],
                    [+3.76519127865000, -3.27106236675729, -5.83678272799149],
                    [+6.47957316843231, -2.46911747464509, -6.21176914665408],
                    [+7.32688324906998, -1.67889171278096, -4.51496113512671],
                    [+6.54881843238363, -1.06760660462911, -7.71597456720663],
                    [+7.56369260941896, -4.10015651865148, -6.82588105651977],
                    [+2.64916867837331, -4.60764575400925, -7.35167957128511],
                    [+0.77231592220237, -0.92788783332000, +0.90692539619101],
                    [+2.18437036702702, -2.20200039553542, +0.92105755612696],
                    [+0.01367202674183, +0.22095199845428, +3.27728206652909],
                    [+1.67849497305706, +0.53855308534857, +4.43416031916610],
                    [-0.89254709011762, +2.01704896333243, +2.87780123699499],
                    [-1.32658751691561, -0.95404596601807, +4.30967630773603],
                ]
            ),
            molecular_multiplicity=multiplicity,
        )

    raise ValueError(f"Unknown molecule: {request.param}")


@pytest.fixture(params=["energy", "gradient"])
def driver(request) -> str:
    """Driver fixture."""
    return request.param


@pytest.fixture(params=["GFN1-xTB", "GFN2-xTB", "g-xTB"])
def method(request) -> str:
    """Method fixture."""
    return request.param


def get_atomic_input(
    version: int,
    molecule: Dict[str, Any],
    driver: str,
    model: str,
    keywords: Optional[Dict[str, Any]] = None,
    qcel_object: bool = False,
):
    keywords = {} if keywords is None else keywords
    spec = {
        "driver": driver,
        "model": model,
        "keywords": keywords,
    }

    if version == 1:
        input_data = {
            "molecule": molecule,
            **spec,
        }
        if qcel_object:
            return qcel_v1.AtomicInput(**input_data)
        return input_data

    if version == 2:
        input_data = {
            "molecule": molecule,
            "specification": spec,
        }
        if qcel_object:
            return qcel_v2.AtomicInput(**input_data)
        return input_data

    raise ValueError(f"Unsupported version: {version}")


@pytest.fixture()
def atomic_input(
    molecule: "Molecule", driver: str, method: str, qcsk_version: int
) -> "AtomicInput":
    """AtomicInput fixture."""
    keywords = {"accuracy": 0.1}
    if method != "g-xTB":
        keywords["spin-polarization"] = 1.0

    return get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver=driver,
        model={"method": method},
        keywords=keywords,
        qcel_object=True,
    )


@pytest.fixture()
def return_result(molecule: "Molecule", driver: str, method: str) -> Any:
    """Return result fixture."""
    if qcel_v1 is None and qcel_v2 is None:
        return None

    # fmt: off
    return {
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "energy",
            "GFN1-xTB",
        ): -34.98079481679544,
        (
            "65a3bab7309579268e383249bad8d33095c32db5", 
            "energy",
            "GFN1-xTB",
        ): -34.79969349790634,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "energy",
            "GFN2-xTB",
        ): -32.96247200751682,
        (
            "65a3bab7309579268e383249bad8d33095c32db5", 
            "energy",
            "GFN2-xTB",
        ): -32.79550096446094,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "energy",
            "g-xTB",
        ): -495.8579022593431,
        (
            "65a3bab7309579268e383249bad8d33095c32db5", 
            "energy",
            "g-xTB",
        ): -495.6736130844879,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gradient",
            "GFN1-xTB",
        ): np.array(
            [
                [-7.8127777299385366e-3,  1.1934774340964032e-3,  4.5413549468695715e-3],
                [ 4.6421440319946899e-4, -1.1892810399826684e-3, -2.0197504595902806e-3],
                [ 1.4659961155836284e-3, -2.1099175886436523e-3, -1.9380621940267644e-3],
                [ 1.1711999573687244e-3, -6.2698436104895140e-4,  6.1052027398387524e-3],
                [-1.1271639376239739e-3,  9.4427525267712874e-4, -2.0019585134705992e-3],
                [ 1.1640876767910299e-2, -7.8823220835429701e-3, -9.4125633395990733e-3],
                [ 4.1896730815446024e-4, -2.0574323137171208e-4,  4.0631607896189040e-4],
                [-1.8048538805765497e-4,  1.1681635318943040e-3,  1.6828711379747209e-3],
                [-5.9899392396715173e-4,  3.4776868895249226e-4, -3.7494532030300391e-4],
                [-1.4518064669687398e-2,  6.0120380907811057e-3,  7.5697719242506301e-4],
                [ 1.5602805624457282e-2,  7.9452664165569446e-3,  8.0585766178318287e-3],
                [-3.2470331456338491e-4, -2.1631045054270229e-4, -8.8664225213429422e-4],
                [ 7.5170216237246327e-4, -1.9138187086605488e-4, -1.0176351391240873e-3],
                [ 7.4127249818842255e-4, -6.3834646906023480e-4,  5.1866042666237741e-4],
                [-7.5666688119764970e-4,  1.5491359769989898e-3,  6.5412040449222086e-4],
                [-9.0631313796708662e-3, -8.8376560100310482e-3, -1.2122319259721901e-2],
                [ 3.1568787505233888e-3,  2.7241474638972614e-3,  1.0130176175270530e-2],
                [-1.4265722433612997e-3,  1.2129756294349283e-3, -2.7114624925623915e-3],
                [ 2.0257875375948752e-4, -1.3136773691499999e-3, -7.9301582944408611e-4],
                [-2.3316383554384955e-3, -2.1231898934156074e-4, -1.1562664997784465e-3],
                [ 1.6004454685795786e-3, -3.2444655089116136e-3,  1.5999862016850414e-3],
                [ 9.2326001340935541e-4,  3.5711564872036713e-3, -1.9620622257010681e-5],
            ]
        ),
        (
            "65a3bab7309579268e383249bad8d33095c32db5",
            "gradient",
            "GFN1-xTB",
        ): np.array(
            [
                [ 5.8487269515684224e-3, -2.8245672585479826e-3, -2.5042430530308614e-2],
                [ 1.1344889132147045e-3, -3.8048649053920992e-3,  4.6309500611981392e-4],
                [ 6.1216323343001196e-4,  4.2676484588337130e-3,  1.4552888548437623e-3],
                [ 3.8588229246757483e-3, -2.5178565491337751e-3,  4.5511880433815660e-3],
                [-2.8923719124373808e-3,  2.8465058801533582e-3, -5.9570645954536378e-4],
                [-3.1715139828682140e-2,  2.4090615844928661e-2,  2.7390014356763005e-2],
                [-5.1712170949331170e-4, -2.5661458383148457e-4,  1.2580628004714538e-3],
                [-1.2467767466959817e-3,  2.5617693315107479e-3,  4.3054683334716043e-3],
                [-6.6838026225981726e-4,  2.8078463003508353e-4,  7.8808974088909179e-4],
                [ 6.2720776627663219e-2, -3.4011401149717554e-2,  8.0545615351564125e-4],
                [-9.3989246842249748e-3, -3.4425388135942946e-3, -1.6925577827956606e-4],
                [-9.2109632138980240e-4, -3.5418960597806120e-3,  9.5658598265697514e-4],
                [ 1.3079168939410081e-3,  4.1232430028422682e-5, -1.3501487342840930e-3],
                [-9.0137395638324887e-4, -2.0508159365818014e-3,  1.5332917382040285e-3],
                [-6.9167012937465327e-4,  2.1987784743179345e-3,  4.6570983344436070e-4],
                [ 9.1667115209820224e-3,  1.5832662610454556e-2,  1.4504602450193358e-2],
                [-3.8910405026297563e-2, -1.1230332864371443e-2, -3.0197951677765990e-2],
                [ 3.2212752154187405e-4,  5.0275546973501985e-3, -4.7479746909097151e-3],
                [ 1.6317352468016837e-3,  5.0025279836452535e-3,  3.8013836733475090e-3],
                [-2.8337247366421047e-3,  1.1958521066958239e-3, -6.8942076127640373e-4],
                [ 2.3970574148217184e-3, -3.0497563611265829e-3,  2.4298578344490768e-3],
                [ 1.6964580652405288e-3,  3.3847120341239513e-3, -1.9152061693815255e-3],
            ]
        ),
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gradient",
            "GFN2-xTB",
        ): np.array(
            [
                [-2.8762246399611042e-3,  3.6434205644851132e-3,  1.0751330278473286e-2],
                [ 4.4690151686084263e-4, -4.1425730180271993e-4, -1.6582751321076691e-3],
                [-5.2507963003684951e-3, -3.5785071225551126e-3, -3.7692782515841741e-3],
                [ 1.6244267484167173e-3,  3.3350155392344676e-4,  5.2521699773571953e-3],
                [ 2.8011493575014521e-4,  1.4315176539019092e-3, -2.4857483081864745e-3],
                [ 1.3089971616131603e-2, -6.5714661053384695e-3, -9.0186942662787532e-3],
                [-1.1475028764752096e-3,  5.7799470046335669e-5,  5.9841227764817853e-4],
                [-1.2267324951379516e-4, -3.2001741974115548e-4,  5.0141069357078738e-4],
                [ 1.4368264597997178e-4,  3.3046647242038153e-4,  7.6590830018770351e-4],
                [-1.5799622788754800e-2,  5.5362480566652781e-3,  1.7670984466559698e-4],
                [ 1.2225397448205381e-2,  6.4413658510880578e-3,  7.2888934614409907e-3],
                [-9.0926793097224814e-4,  2.3230158191772002e-5, -1.5348409753338055e-3],
                [ 1.0468942023139740e-3,  3.9873356516090144e-4, -1.2501047491568449e-4],
                [ 2.8772291313564752e-4,  8.3576888868536569e-5,  2.8655269149291930e-5],
                [-6.5388962017767641e-4,  1.9360701902827970e-4,  6.3082807611417188e-4],
                [-8.1416388491649082e-3, -8.7681803538462548e-3, -1.2733782870136941e-2],
                [ 1.0137500879852976e-2, -1.1855538880604891e-3,  5.2073132439886469e-3],
                [-9.1242693518911477e-4,  5.8372929415780408e-4, -2.0427867879296165e-3],
                [-4.4224205171213950e-3,  1.5003178682228330e-3,  1.5448692220259462e-3],
                [-1.1434817961773187e-3, -2.1397148289234208e-4, -6.6257997651398442e-4],
                [ 1.3140455205116626e-3, -1.3942902697520964e-3,  1.6665791732631181e-3],
                [ 7.8328707671722819e-4,  1.8887295278280981e-3, -3.8208277489780787e-4],
            ],
        ),
        (
            "65a3bab7309579268e383249bad8d33095c32db5", 
            "gradient",
            "GFN2-xTB",
        ): np.array(
            [
                [ 8.9087601185166808e-3,  9.5363453287207001e-4, -2.0217225243652690e-2],
                [ 1.2420480077156421e-3, -4.1925627409221313e-3,  5.7288026463729624e-4],
                [-2.2578220663791808e-3,  1.6556308819111641e-3,  8.0374966090571967e-4],
                [ 5.2249449647073795e-3, -1.1939321404074743e-3,  4.8044722908595159e-3],
                [-1.9777758444093634e-3,  1.3437308828518099e-3, -2.2009747012802536e-3],
                [-3.9729021900133624e-2,  2.1190626222113772e-2,  1.5240354443282480e-2],
                [-1.2242142118499061e-3,  2.2711858245941648e-4,  1.5636366744160792e-3],
                [-1.5358038675805687e-3,  1.1770653872909239e-3,  3.9240792163564350e-3],
                [-2.5691543256986055e-4,  6.5681113508186668e-4,  1.4059963071801399e-3],
                [ 5.7168977360613327e-2, -2.9809160393756647e-2,  3.5464357588270460e-3],
                [-1.6895979347189279e-2, -1.2561898203752394e-2, -1.2843165460644224e-2],
                [-1.2320667530668229e-3, -3.0613275129607073e-3,  1.5890070859230624e-3],
                [ 2.3017949751481560e-3,  9.7169822009879358e-4, -4.5113896228507857e-4],
                [-1.5511757265657465e-3, -1.9372970300090251e-3,  1.7874808539965813e-3],
                [-5.8828704446251922e-4,  1.1369696115268628e-3,  3.9545345237311264e-4],
                [ 1.4843909138453697e-2,  2.3181930928845174e-2,  2.4028304438698852e-2],
                [-2.3683497717830210e-2, -1.1166141090864414e-2, -2.4164705867834490e-2],
                [ 1.7130370485654159e-3,  3.5313220570316792e-3, -3.7551561735977884e-3],
                [-2.4671309078609449e-3,  6.9131578745930105e-3,  4.8209522926247776e-3],
                [-1.4686172859893572e-3,  7.8990095654243506e-4, -1.8314334686837284e-4],
                [ 1.5859857068613150e-3, -1.6803924218287694e-3,  2.2717172240252349e-3],
                [ 1.8788507853056502e-3,  1.8731142612825951e-3, -2.9390102079434907e-3],
            ],
        ),
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gradient",
            "g-xTB",
        ): np.array(
            [
                [-3.5864520371694090e-3,  3.1373735570812728e-3,  8.0350323153502764e-3],
                [ 3.9929379631889099e-3,  1.7915160516023059e-3,  4.0861599970210899e-4],
                [-4.3823482420333173e-3, -1.7950154397671288e-3, -4.8293792027291685e-3],
                [ 1.8936858650744036e-5,  1.6874314653329704e-3,  8.4012681538184219e-4],
                [-1.3411498330171306e-3, -4.7282355453882293e-3,  7.5227110648641354e-4],
                [ 8.0978938025116250e-3, -4.7653762489181231e-3, -5.6273645927501573e-3],
                [-1.0831930043939738e-5, -4.4696372998250645e-4,  1.8423439164144407e-4],
                [ 2.3528273865167017e-4, -1.5264766979588666e-3, -1.0336643017593234e-3],
                [ 4.0671130032791221e-7,  1.0530595654817149e-3, -2.3212642363496660e-4],
                [-1.3958185198231561e-2,  7.0840320670212103e-3,  1.4318061173870492e-3],
                [ 6.6534295982969456e-3,  2.7282116021445637e-3,  1.6617971821950739e-3],
                [ 6.6560664952507809e-3,  2.2842857552288136e-3, -2.0934317689957956e-3],
                [-5.5565398229533690e-4, -1.3069673196754151e-4,  1.8272049435977500e-4],
                [ 1.2560748052970643e-4,  4.0372198673599625e-4,  8.2749354700279907e-5],
                [-2.2927702899434697e-4, -3.7157518393735500e-4,  6.7517490764051229e-4],
                [-7.2792165503702769e-3, -7.7941382647907891e-3, -8.0448019946815601e-3],
                [ 4.5123403807245457e-3,  1.7595403817141533e-3,  8.4362608149934938e-3],
                [ 2.2169587346188295e-3, -1.7525821065106301e-3, -1.3951781870651546e-3],
                [-1.6563304597692018e-3,  2.0562339492979998e-3,  2.2460300870546001e-3],
                [-1.8274587478666585e-3, -3.9139196693720993e-4, -1.7915180601909188e-3],
                [ 1.3467133962164904e-3, -1.3980711539060063e-3,  1.0209012784049660e-3],
                [ 9.7032984985077290e-4,  1.1151166884230837e-3, -9.1025633349054813e-4],
            ],
        ),
        (
            "65a3bab7309579268e383249bad8d33095c32db5", 
            "gradient",
            "g-xTB",
        ): np.array(
            [
                [-6.6735422210277605e-3,  3.8630319183304690e-4,  7.1756896776512839e-3],
                [ 4.0274489921472631e-3,  7.8856264149844684e-4, -1.8997711487224560e-3],
                [ 1.2722430684339987e-2, -3.5125972790429442e-3, -1.3733223660592552e-2],
                [ 2.5546023603263460e-3,  1.3876520039553342e-4,  6.2827084247825734e-3],
                [-2.9691203214666528e-3,  8.4790994331380889e-4,  1.6000278379012967e-3],
                [-9.7965338629244822e-2,  6.2594296121840587e-2,  4.0473771785204768e-2],
                [-8.5480015021708122e-5, -7.1698930804223293e-5,  5.1253088965600747e-4],
                [ 1.0846572327833135e-4,  3.7020998070964146e-4, -2.2332507784261416e-4],
                [ 2.1941504378843716e-4,  7.7206833362509087e-4,  1.2446562960411272e-4],
                [ 1.0671089519311056e-1, -5.1904038959525466e-2,  2.4173467187188323e-4],
                [ 7.2996211883041969e-3,  2.0705380475159337e-3,  1.0016993668360804e-3],
                [ 6.4814906099037242e-3,  2.2654479162012558e-3, -2.0925704161516255e-3],
                [-4.5288978067141737e-4, -9.8480152380851690e-5,  1.6539913856847098e-4],
                [ 1.3416698286797517e-4,  2.9893221234434807e-4,  1.7489951176060677e-4],
                [-2.7725864623737894e-4, -2.4950398238467500e-4,  6.8522675644067414e-4],
                [-7.1121713071339654e-3, -6.7556548130414925e-3, -6.6190840960097357e-3],
                [-3.4742743119786708e-2, -2.3815525905675414e-2, -3.1748249589461909e-2],
                [ 7.2738899336237048e-3,  6.7375724484021347e-3, -3.2427009408782254e-3],
                [ 2.3024848841603435e-4,  1.1971850698282556e-2,  7.2380046240145190e-3],
                [-3.0429575962145437e-3,  3.1274581007102069e-4, -2.1432414481385399e-3],
                [ 2.6128365921573404e-3, -4.3128647852538815e-3,  1.4304116281236507e-3],
                [ 2.9459898445407910e-3,  1.1651622620756806e-3, -5.4044035646186907e-3],
            ],
        ),
    }[(molecule.get_hash(), driver, method)]
    # fmt: on


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
@pytest.mark.parametrize("multiplicity", [1, 3], indirect=True)
def test_qcschema(atomic_input: "AtomicInput", return_result: Any) -> None:
    """Test qcschema interface."""
    atomic_result = run_schema(atomic_input)

    assert atomic_result.success
    assert pytest.approx(atomic_result.return_result) == return_result


@pytest.fixture(params=[
      {"cosmo-solvation": "methanol"},
      {"cosmo-solvation": 7.0},
      {"cpcm-solvation": 7.0}, 
      {"pcm-solvation": 7.0},
      {"alpb-solvation": ["water", "bar1mol"]},
      {"gbsa-solvation": ["methanol", "reference"]},
      {"gbe-solvation": [7.0, "p16"]},
      {"gb-solvation": [7.0, "still"]},
   ])
def solvation(request) -> dict:
    """Solvation fixture."""
    return request.param


@pytest.fixture()
def atomic_input_solvation(
    molecule: "Molecule", method: str, solvation: dict, qcsk_version: int
) -> "AtomicInput":
    """AtomicInput fixture."""
    return get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver="energy",
        model={"method": method},
        keywords=solvation,
        qcel_object=False,
    )


@pytest.fixture()
def return_result_solvation(molecule: "Molecule", method: str, solvation: dict) -> Any:
    """Return result fixture."""
    if qcel_v1 is None and qcel_v2 is None:
        return None

    # fmt: off
    return {
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cosmo-solvation",
            "methanol",
            "GFN1-xTB",
        ): -35.00299773110,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cosmo-solvation",
            "methanol",
            "GFN2-xTB",
        ): -32.98092347037,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cosmo-solvation",
            "methanol",
            "g-xTB",
        ): -495.8853032546,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cosmo-solvation",
            7.0,
            "GFN1-xTB",
        ): -34.99874684566,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cosmo-solvation",
            7.0,
            "GFN2-xTB",
        ): -32.97707940097,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cosmo-solvation",
            7.0,
            "g-xTB",
        ): -495.8796081798,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cpcm-solvation",
            7.0,
            "GFN1-xTB",
        ): -35.00027992606,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cpcm-solvation",
            7.0,
            "GFN2-xTB",
        ): -32.97844540897,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "cpcm-solvation",
            7.0,
            "g-xTB",
        ): -495.8816329335,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "pcm-solvation",
            7.0,
            "GFN1-xTB",
        ): -34.99779118525,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "pcm-solvation",
            7.0,
            "GFN2-xTB",
        ): -32.97608151401,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "pcm-solvation",
            7.0,
            "g-xTB",
        ): -495.878279930017,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "alpb-solvation",
            ("water", "bar1mol"),
            "GFN1-xTB",
        ): -34.9966872968042,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "alpb-solvation",
            ("water", "bar1mol"),
            "GFN2-xTB",
        ): -32.9777888674693,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "alpb-solvation",
            ("water", "bar1mol"),
            "g-xTB",
        ): -495.876281944169,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gbsa-solvation",
            ("methanol", "reference"),
            "GFN1-xTB",
        ): -34.9989058302890,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gbsa-solvation",
            ("methanol", "reference"),
            "GFN2-xTB",
        ): -32.9763255038126,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gbsa-solvation",
            ("methanol", "reference"),
            "g-xTB",
        ): ValueError("not supported"),
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gbe-solvation",
            (7.0, "p16"),
            "GFN1-xTB",
        ): -34.9859026499920,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gbe-solvation",
            (7.0, "p16"),
            "GFN2-xTB",
        ): -32.9667327170214,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gbe-solvation",
            (7.0, "p16"),
            "g-xTB",
        ): -495.86530015434,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gb-solvation",
            (7.0, "still"),
            "GFN1-xTB",
        ): -34.9859968024425,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gb-solvation",
            (7.0, "still"),
            "GFN2-xTB",
        ): -32.9668850575386,
        (
            "142dbe2f7f02c899c660c08ba85c086a366fbdec",
            "gb-solvation",
            (7.0, "still"),
            "g-xTB",
        ): -495.86577759346,
    }[
        (
            molecule.get_hash(),
            list(solvation.keys())[0],
            tuple(list(solvation.values())[0])
            if isinstance(list(solvation.values())[0], list)
            else list(solvation.values())[0],
            method,
        )
    ]
    # fmt: on


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
def test_qcschema_solvation(
    atomic_input_solvation: "AtomicInput", return_result_solvation: Any
) -> None:
    """Test qcschema interface."""
    atomic_result = run_schema(atomic_input_solvation)

    if isinstance(return_result_solvation, ValueError):
        assert not atomic_result.success
        assert str(return_result_solvation) in atomic_result.error.error_message
        return

    print(atomic_result.return_result)

    assert atomic_result.success
    assert pytest.approx(atomic_result.return_result) == return_result_solvation


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
def test_unsupported_driver(molecule: "Molecule", qcsk_version: int):
    """Test unsupported driver name."""
    atomic_inp = get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver="hessian",
        model={"method": "GFN1-xTB"},
    )

    atomic_result = run_schema(atomic_inp)

    assert not atomic_result.success
    assert atomic_result.error.error_type == "input_error"
    assert (
        "Driver 'hessian' is not supported by tblite."
        in atomic_result.error.error_message
    )


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
def test_unsupported_method(molecule: "Molecule", qcsk_version: int):
    """Test unsupported method name."""
    atomic_inp = get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver="energy",
        model={"method": "GFN-xTB"},
    )

    atomic_result = run_schema(atomic_inp)

    assert not atomic_result.success
    assert atomic_result.error.error_type == "input_error"
    assert (
        "Model 'GFN-xTB' is not supported by tblite."
        in atomic_result.error.error_message
    )


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
def test_unsupported_basis(molecule: "Molecule", qcsk_version: int):
    """Test unsupported basis set."""
    atomic_inp = get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver="energy",
        model={"method": "GFN1-xTB", "basis": "def2-SVP"},
    )

    atomic_result = run_schema(atomic_inp)

    assert not atomic_result.success
    assert atomic_result.error.error_type == "input_error"
    assert (
        "Basis sets are not supported by tblite." in atomic_result.error.error_message
    )


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
def test_unsupported_keywords(molecule: "Molecule", qcsk_version: int):
    """Test unsupported keywords."""
    atomic_inp = get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver="gradient",
        model={"method": "GFN1-xTB"},
        keywords={"unsupported": True},
    )

    atomic_result = run_schema(atomic_inp)

    assert not atomic_result.success
    assert atomic_result.error.error_type == "input_error"
    assert "Unknown keywords: unsupported" in atomic_result.error.error_message


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
def test_unsupported_gxtb_and_spin_polarization(molecule: "Molecule", qcsk_version: int):
    """Test unsupported combination of g-xTB and spin polarization."""
    atomic_inp = get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver="energy",
        model={"method": "g-xTB"},
        keywords={"spin-polarization": 1.0},
    )

    atomic_result = run_schema(atomic_inp)

    assert not atomic_result.success
    assert atomic_result.error.error_type == "input_error"
    assert "Spin polarization is already part of the g-xTB Hamiltonian" in (
        atomic_result.error.error_message
    )


@pytest.mark.skipif(qcel_v1 is None and qcel_v2 is None, reason="requires qcelemental")
def test_scf_not_converged(molecule: "Molecule", qcsk_version: int):
    """Test unconverged SCF."""
    atomic_inp = get_atomic_input(
        qcsk_version,
        molecule=molecule,
        driver="gradient",
        model={"method": "GFN1-xTB"},
        keywords={"max-iter": 3},
    )

    atomic_result = run_schema(atomic_inp)

    assert not atomic_result.success
    assert atomic_result.error.error_type == "execution_error"
    assert "SCF not converged in 3 cycles" in atomic_result.error.error_message
