#!/usr/bin/env bash
set -u

root=/home/kuehne88/work/cp2k-gxtb-accel-integration-0a1f7e3329
envdir=/home/kuehne88/work/codex-gxtb-pbc-20260714T1038Z-18d37c-1449feb/env
provider=/home/kuehne88/work/codex-gxtb-streamed-reverse-frozen-20260716/install-linux
base="$root/evidence/release_mpi_reference/fullgrid_timing_repeats"
input="$root/evidence/release_mpi_reference/Si_prim_gxtb_kp_fullgrid_pgroups.inp"
runner="$root/evidence/release_mpi_reference/run_with_rss.py"
binary="$root/build-release/bin/cp2k.psmp"

mkdir -p "$base"

run_one() {
  local ranks=$1
  local repeat=$2
  local position=$3
  local name=$4
  local stream_mode=$5
  local gradient_mode=$6
  local transform_mode=$7
  local run="$base/p${ranks}_r${repeat}_${position}_${name}"
  local last_cpu=$((ranks - 1))
  local rc

  mkdir -p "$run"
  cd "$run" || return 90
  printf '%s\n' "$ranks" > mpi_ranks.txt
  printf '%s\n' "$repeat" > repeat.txt
  printf '%s\n' "$position" > sequence_position.txt
  printf '0-%s\n' "$last_cpu" > cpu_set.txt
  printf '%s\n' "$stream_mode" > stream_mode.txt
  printf '%s\n' "$gradient_mode" > gradient_mode.txt
  printf '%s\n' "$transform_mode" > transform_mode.txt
  sha256sum "$input" > input.sha256
  sha256sum "$binary" "$root/build-release/src/libcp2k.so" > binary.sha256
  date --iso-8601=seconds > started.txt
  : > RUNNING

  set +e
  /usr/bin/env \
    PATH="$envdir/bin:/usr/local/bin:/usr/bin:/bin" \
    LD_LIBRARY_PATH="$root/build-release/src:$provider/lib:$envdir/lib" \
    CP2K_DATA_DIR="$root/data" \
    CP2K_GXTB_EXCHANGE_STREAM_MODE="$stream_mode" \
    CP2K_GXTB_EXCHANGE_GRADIENT_MODE="$gradient_mode" \
    CP2K_GXTB_EXCHANGE_TRANSFORM_MODE="$transform_mode" \
    CP2K_GXTB_EXCHANGE_IMAGE_BATCH_SIZE=2 \
    OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    OMPI_MCA_hwloc_base_binding_policy=none \
    OMPI_MCA_rmaps_base_oversubscribe=1 \
    "$envdir/bin/python3" "$runner" rusage.json \
    /usr/bin/timeout 900 /usr/bin/taskset -c "0-$last_cpu" \
    "$envdir/bin/mpiexec" --bind-to none -n "$ranks" \
    "$binary" -i "$input" -o run.out > launcher.log 2>&1
  rc=$?
  set -e

  printf '%s\n' "$rc" > returncode.txt
  date --iso-8601=seconds > finished.txt
  grep -E "KPOINTS\\| Number of kpoint groups|KPOINTS\\| Number of kpoints per group|GXTB-KGROUP-OWNER|GXTB STREAMED-REVERSE|ENERGY\\| Total FORCE_EVAL|PROGRAM ENDED" \
    run.out > selected_evidence.txt 2>/dev/null || true
  sha256sum mpi_ranks.txt repeat.txt sequence_position.txt cpu_set.txt stream_mode.txt \
    gradient_mode.txt transform_mode.txt input.sha256 binary.sha256 started.txt \
    finished.txt launcher.log rusage.json returncode.txt run.out selected_evidence.txt \
    > SHA256SUMS 2>/dev/null || true
  rm -f RUNNING
  if [[ $rc -eq 0 ]] && grep -q "PROGRAM ENDED" run.out 2>/dev/null; then
    : > PASS
  else
    : > FAIL
  fi
}

run_mode() {
  local ranks=$1 repeat=$2 position=$3 mode=$4
  case "$mode" in
    dense) run_one "$ranks" "$repeat" "$position" dense LEGACY DENSE DENSE ;;
    batched) run_one "$ranks" "$repeat" "$position" batched_streamed BATCHED STREAMED DENSE ;;
    kgroup) run_one "$ranks" "$repeat" "$position" kgroup_streamed KGROUP_OWNER STREAMED DENSE ;;
    separable) run_one "$ranks" "$repeat" "$position" separable_densegrad LEGACY DENSE SEPARABLE ;;
  esac
}

for ranks in 1 2 4; do
  position=0
  for mode in dense batched kgroup separable; do
    position=$((position + 1)); run_mode "$ranks" 1 "$position" "$mode"
  done
  position=0
  for mode in separable kgroup batched dense; do
    position=$((position + 1)); run_mode "$ranks" 2 "$position" "$mode"
  done
  position=0
  for mode in kgroup dense separable batched; do
    position=$((position + 1)); run_mode "$ranks" 3 "$position" "$mode"
  done
done

find "$base" -mindepth 2 -maxdepth 2 -type f \( -name PASS -o -name FAIL \) -print | sort \
  > "$base/status.txt"
date --iso-8601=seconds > "$base/finished.txt"
