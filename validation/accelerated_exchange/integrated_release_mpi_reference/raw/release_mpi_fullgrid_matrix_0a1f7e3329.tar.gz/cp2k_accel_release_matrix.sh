#!/usr/bin/env bash
set -u

root=/home/kuehne88/work/cp2k-gxtb-accel-integration-0a1f7e3329
envdir=/home/kuehne88/work/codex-gxtb-pbc-20260714T1038Z-18d37c-1449feb/env
provider=/home/kuehne88/work/codex-gxtb-streamed-reverse-frozen-20260716/install-linux
base="$root/evidence/release_mpi_reference/fullgrid_matrix"
input="$root/evidence/release_mpi_reference/Si_prim_gxtb_kp_fullgrid_pgroups.inp"
runner="$root/evidence/release_mpi_reference/run_with_rss.py"
binary="$root/build-release/bin/cp2k.psmp"

mkdir -p "$base"

run_one() {
  local ranks=$1
  local name=$2
  local stream_mode=$3
  local gradient_mode=$4
  local transform_mode=$5
  local oracle_iteration=$6
  local run="$base/${name}_p${ranks}"
  local last_cpu=$((ranks - 1))
  local rc
  local -a oracle_env=()

  mkdir -p "$run"
  cd "$run" || return 90
  printf '%s\n' "$ranks" > mpi_ranks.txt
  printf '0-%s\n' "$last_cpu" > cpu_set.txt
  printf '%s\n' "$stream_mode" > stream_mode.txt
  printf '%s\n' "$gradient_mode" > gradient_mode.txt
  printf '%s\n' "$transform_mode" > transform_mode.txt
  printf '%s\n' "$oracle_iteration" > oracle_iteration.txt
  sha256sum "$input" > input.sha256
  sha256sum "$binary" "$root/build-release/src/libcp2k.so" > binary.sha256
  date --iso-8601=seconds > started.txt
  : > RUNNING

  if [[ "$oracle_iteration" != "none" ]]; then
    oracle_env=("CP2K_GXTB_QUALIFICATION_FULLMESH_ORACLE_ITERATION=$oracle_iteration")
  fi

  set +e
  /usr/bin/env \
    PATH="$envdir/bin:/usr/local/bin:/usr/bin:/bin" \
    LD_LIBRARY_PATH="$root/build-release/src:$provider/lib:$envdir/lib" \
    CP2K_DATA_DIR="$root/data" \
    CP2K_GXTB_EXCHANGE_STREAM_MODE="$stream_mode" \
    CP2K_GXTB_EXCHANGE_GRADIENT_MODE="$gradient_mode" \
    CP2K_GXTB_EXCHANGE_TRANSFORM_MODE="$transform_mode" \
    CP2K_GXTB_EXCHANGE_IMAGE_BATCH_SIZE=2 \
    OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 \
    OMPI_MCA_hwloc_base_binding_policy=none \
    OMPI_MCA_rmaps_base_oversubscribe=1 \
    "${oracle_env[@]}" \
    "$envdir/bin/python3" "$runner" rusage.json \
    /usr/bin/timeout 900 /usr/bin/taskset -c "0-$last_cpu" \
    "$envdir/bin/mpiexec" --bind-to none -n "$ranks" \
    "$binary" -i "$input" -o run.out > launcher.log 2>&1
  rc=$?
  set -e

  printf '%s\n' "$rc" > returncode.txt
  date --iso-8601=seconds > finished.txt
  grep -E "KPOINTS\\| Number of kpoint groups|KPOINTS\\| Number of kpoints per group|GXTB-QUALIFICATION_ONLY|GXTB-KGROUP-OWNER|GXTB STREAMED-REVERSE|ENERGY\\| Total FORCE_EVAL|PROGRAM ENDED" \
    run.out > selected_evidence.txt 2>/dev/null || true
  sha256sum mpi_ranks.txt cpu_set.txt stream_mode.txt gradient_mode.txt \
    transform_mode.txt oracle_iteration.txt input.sha256 binary.sha256 started.txt \
    finished.txt launcher.log rusage.json returncode.txt run.out selected_evidence.txt \
    > SHA256SUMS 2>/dev/null || true
  rm -f RUNNING
  if [[ $rc -eq 0 ]] && grep -q "PROGRAM ENDED" run.out 2>/dev/null; then
    if [[ "$oracle_iteration" == "none" ]] || \
       { grep -q "GXTB-QUALIFICATION_ONLY KGROUP-ORACLE" run.out && \
         grep -q "GXTB-QUALIFICATION_ONLY STREAMED-REVERSE" run.out; }; then
      : > PASS
    else
      : > FAIL
    fi
  else
    : > FAIL
  fi
}

overall=0
for ranks in 1 2 4; do
  run_one "$ranks" dense LEGACY DENSE DENSE none || overall=1
  run_one "$ranks" batched_streamed BATCHED STREAMED DENSE none || overall=1
  run_one "$ranks" kgroup_streamed KGROUP_OWNER STREAMED DENSE none || overall=1
  run_one "$ranks" separable_densegrad LEGACY DENSE SEPARABLE none || overall=1
  run_one "$ranks" kgroup_qualify KGROUP_OWNER QUALIFY DENSE 1 || overall=1
done

find "$base" -mindepth 2 -maxdepth 2 -type f \( -name PASS -o -name FAIL \) -print | sort \
  > "$base/status.txt"
date --iso-8601=seconds > "$base/finished.txt"
exit "$overall"
