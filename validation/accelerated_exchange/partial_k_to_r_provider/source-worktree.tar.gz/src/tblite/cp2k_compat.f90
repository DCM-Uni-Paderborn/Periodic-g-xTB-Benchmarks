! This file is part of tblite.
! SPDX-Identifier: LGPL-3.0-or-later

!> Compatibility helpers for CP2K's low-level tblite integration.
module tblite_cp2k_compat
   use, intrinsic :: ieee_arithmetic, only : ieee_is_finite
   use, intrinsic :: iso_fortran_env, only : int64
   use mctc_env, only : wp, error_type, fatal_error
   use mctc_io, only : structure_type
   use mctc_io_constants, only : pi
   use multicharge, only : get_charges
   use tblite_acp_cache, only : acp_cache
   use tblite_acp_type, only : acp_image_type, get_acp, get_acp_images, &
      & get_acp_kmesh, get_acp_gradient, get_acp_image_gradient, &
      & get_acp_kmesh_gradient
   use tblite_adjlist, only : adjacency_list, new_adjacency_list
   use tblite_basis_cache, only : basis_cache
   use tblite_basis_type, only : basis_type, get_cutoff, get_pair_cutoff
   use tblite_blas, only : gemv
   use tblite_container_cache, only : container_cache
   use tblite_cutoff, only : get_lattice_points
   use tblite_exchange_cache, only : exchange_cache
   use tblite_exchange_fock, only : exchange_fock
   use tblite_exchange_transform, only : bvk_transform_dense, &
      & bvk_transform_separable_dft
   use tblite_integral_multipole, only : multipole_cgto, multipole_grad_cgto
   use tblite_integral_type, only : integral_type, new_integral
   use tblite_scf_potential, only : potential_type, add_pot_to_h1
   use tblite_scf_info, only : scf_info, atom_resolved, shell_resolved
   use tblite_scf_mixer_cache, only : mixer_cache_container
   use tblite_scf_mixer_diis, only : diis_input, diis_mixer, new_diis
   use tblite_scf_mixer_input, only : mixer_mode
   use tblite_scf_mixer_simple, only : new_simple, simple_input, simple_mixer
   use tblite_wavefunction_spin, only : magnet_to_updown, updown_to_magnet
   use tblite_wavefunction_type, only : wavefunction_type, new_wavefunction
   use tblite_xtb_calculator, only : xtb_calculator
   use tblite_xtb_h0, only : get_anisotropy, get_anisotropy_gradient, &
      & get_hamiltonian, get_hamiltonian_gradient, hamiltonian_image_type
   implicit none
   private

   public :: cp2k_get_mixer_dimension, cp2k_get_scc_mixer_dimension
   public :: cp2k_get_acp_cutoff
   public :: cp2k_potential_mixer_type, new_cp2k_potential_mixer
   public :: cp2k_set_scf_options
   public :: cp2k_update_basis, cp2k_get_cgto
   public :: cp2k_multipole_cgto, cp2k_multipole_grad_cgto
   public :: cp2k_build_gamma_h0, cp2k_build_image_h0, cp2k_build_image_acp, &
      & cp2k_build_acp_projectors
   public :: cp2k_prepare_exchange, cp2k_exchange_kpoint, cp2k_exchange_kmesh, &
      & cp2k_exchange_kmesh_gradient, cp2k_exchange_kpoint_gradient, &
      & cp2k_gamma_gradient
   public :: cp2k_exchange_stream_type, cp2k_exchange_stream_begin, &
      & cp2k_exchange_stream_push, cp2k_exchange_stream_apply, &
      & cp2k_exchange_stream_get, cp2k_exchange_stream_reverse_apply, &
      & cp2k_exchange_stream_reverse_get, cp2k_exchange_stream_end, &
      & cp2k_exchange_stream_reverse_begin, &
      & cp2k_exchange_stream_reverse_push, &
      & cp2k_exchange_stream_reverse_batch_apply, &
      & cp2k_exchange_stream_reverse_batch_pull, &
      & cp2k_exchange_stream_reverse_batch_advance, &
      & cp2k_exchange_stream_reverse_result, &
      & cp2k_exchange_stream_has_full_mesh_storage, &
      & cp2k_exchange_stream_batch_bounds, &
      & cp2k_exchange_stream_batch_apply, &
      & cp2k_exchange_stream_batch_pull, &
      & cp2k_exchange_stream_batch_advance, &
      & cp2k_exchange_stream_batch_result, &
      & cp2k_exchange_stream_peak_complex_elements
   public :: cp2k_exchange_partial_descriptor_type, &
      & cp2k_exchange_partial_forward_type, &
      & cp2k_exchange_partial_reverse_type, &
      & cp2k_exchange_partial_begin, cp2k_exchange_partial_push, &
      & cp2k_exchange_partial_export_forward, &
      & cp2k_exchange_partial_import_forward, &
      & cp2k_exchange_partial_forward_size, &
      & cp2k_exchange_partial_forward_pack, &
      & cp2k_exchange_partial_forward_unpack, &
      & cp2k_exchange_partial_descriptor_size, &
      & cp2k_exchange_partial_descriptor_pack, &
      & cp2k_exchange_partial_descriptor_unpack, &
      & cp2k_exchange_partial_reverse_push, &
      & cp2k_exchange_partial_export_reverse, &
      & cp2k_exchange_partial_import_reverse, &
      & cp2k_exchange_partial_reverse_size, &
      & cp2k_exchange_partial_reverse_pack, &
      & cp2k_exchange_partial_reverse_unpack, &
      & cp2k_exchange_partial_descriptors_match, &
      & cp2k_exchange_partial_set_pull_ownership, &
      & cp2k_exchange_partial_contributor_advance, &
      & cp2k_exchange_partial_discard
   public :: cp2k_image_h0_gradient
   public :: cp2k_acp_image_gradient, cp2k_acp_kmesh, &
      & cp2k_acp_kmesh_gradient, cp2k_apply_basis_gradient
   public :: acp_image_type, hamiltonian_image_type

   integer, parameter, public :: cp2k_exchange_stream_reduced = 1
   integer, parameter, public :: cp2k_exchange_stream_oracle = 2
   integer, parameter, public :: cp2k_exchange_stream_batched = 3
   !> Dense Nk-by-Nk Fourier phase-table oracle.
   integer, parameter, public :: cp2k_exchange_transform_dense = &
      & bvk_transform_dense
   !> Factorized direct DFT (not an FFT): O(Nk*sum(nmesh)) characters.
   integer, parameter, public :: cp2k_exchange_transform_separable_dft = &
      & bvk_transform_separable_dft
   integer, parameter, public :: cp2k_exchange_partial_abi_version = 1
   integer, parameter, public :: cp2k_exchange_partial_descriptor_words = 30

   !> CP2K-facing wrapper for g-xTB's native potential mixer.
   !>
   !> CP2K owns the packing of all real Fock degrees of freedom into one flat
   !> vector.  This wrapper deliberately owns only the mixer state and mirrors
   !> g-xTB's iterator schedule: simple mixing with damping 0.2 for the first
   !> three Fock builds, DIIS precollection on the third build, and DIIS from
   !> the fourth build onward.
   type, public :: cp2k_potential_mixer_type
      private
      type(simple_mixer) :: simple
      type(diis_mixer) :: diis
      type(mixer_cache_container) :: simple_cache
      type(mixer_cache_container) :: diis_cache
      integer :: ndim = 0
      integer :: iteration = 0
      real(wp) :: residual = 0.0_wp
      logical :: initialized = .false.
   contains
      procedure, public :: reset => cp2k_potential_mixer_reset
      procedure, public :: advance => cp2k_potential_mixer_advance
      procedure, public :: get_error => cp2k_potential_mixer_get_error
   end type cp2k_potential_mixer_type

   !> Stateful collector for Brillouin-zone-coupled exchange.
   !>
   !> The default reduced mode retains three complete weighted k-to-R image
   !> meshes per spin.  The explicitly selected batched mode instead bounds AO
   !> image storage and requires sequential k-block resubmission and Fock pulls
   !> for each batch; it also drops the dense Nk-by-Nk phase tables.  Oracle
   !> mode retains all Bloch blocks and dispatches the unchanged complete-mesh
   !> evaluator, including reverse mode.
   type, public :: cp2k_exchange_stream_type
      private
      logical :: active = .false.
      logical :: applied = .false.
      logical :: reverse_applied = .false.
      logical :: reverse_transaction = .false.
      logical :: reverse_batch_applied = .false.
      logical :: reverse_result_pulled = .false.
      logical :: reverse_only = .false.
      logical :: batch_applied = .false.
      logical :: batch_result_pulled = .false.
      logical :: partial_active = .false.
      logical :: partial_forward_exported = .false.
      logical :: partial_forward_imported = .false.
      logical :: partial_reverse_exported = .false.
      logical :: partial_reverse_imported = .false.
      logical :: partial_pull_distribution_set = .false.
      logical :: partial_result_owner = .false.
      integer :: nk = 0
      integer :: nao = 0
      integer :: nspin = 0
      integer :: nsh = 0
      integer :: mode = 0
      integer :: batch_size = 0
      integer :: batch_first = 0
      integer :: batch_count = 0
      integer :: batch_last = 0
      integer :: image_first = 0
      integer :: plan_builds = 0
      integer :: partial_generation = 0
      integer(int64) :: partial_transaction_id(2) = 0_int64
      integer :: nmesh(3) = 0
      integer(int64) :: peak_complex_elements = 0_int64
      integer, allocatable :: reps(:, :), inverse_image(:), input_to_grid(:)
      integer(int64), allocatable :: density_signature(:), &
         & overlap_signature(:)
      logical, allocatable :: seen(:), forward_pulled(:), reverse_pulled(:), &
         & batch_pulled(:), block_signature_set(:), partial_pull_mask(:)
      complex(wp), allocatable :: inverse_coeff(:), phase_roots(:, :), &
         & twist_phase(:)
      real(wp), allocatable :: kfrac(:, :), weights(:), vsh(:)
      real(wp), allocatable :: reverse_gradient(:, :), reverse_sigma(:, :)
      real(wp), allocatable :: g_onsfx(:, :, :), g_onsri(:, :), &
         & dgdq_onsfx(:, :, :), dgdq_onsri(:, :)
      complex(wp), allocatable :: density(:, :, :, :), overlap(:, :, :), &
         & fock(:, :, :, :), overlap_adjoint(:, :, :)
      complex(wp), allocatable :: amat_r(:, :, :, :), cmat_r(:, :, :, :), &
         & vmat_r(:, :, :, :), amat_partner_r(:, :, :, :), &
         & reverse_amat_r(:, :, :, :), reverse_vmat_r(:, :, :, :), &
         & gdiagP(:, :), gdiagSP(:, :), gdiagSPS(:, :)
      complex(wp), allocatable :: reverse_bdiagSP(:, :), &
         & reverse_bdiagSPS(:, :)
      integer(int64) :: kernel_signature(2) = 0_int64
      integer(int64) :: phase_signature(2) = 0_int64
      integer(int64) :: compact_phase_signature(2) = 0_int64
      integer(int64) :: partial_state_signature(12) = 0_int64
      real(wp) :: twist(3) = 0.0_wp
      real(wp) :: energy = 0.0_wp
   end type cp2k_exchange_stream_type

   !> Immutable identity of one pre-kernel partial-accumulation generation.
   !>
   !> Components are private so a host can copy and compare descriptors but
   !> cannot manufacture a compatible descriptor by changing individual
   !> fields.  Every import also rebuilds the descriptor from the live stream
   !> and validates the geometry/model/cache state before accepting payloads.
   type, public :: cp2k_exchange_partial_descriptor_type
      private
      integer :: abi_version = 0
      integer :: scalar_bits = 0
      integer :: phase = 0
      integer :: generation = 0
      integer(int64) :: transaction_id(2) = 0_int64
      integer :: nk = 0
      integer :: nao = 0
      integer :: nspin = 0
      integer :: nsh = 0
      integer :: nmesh(3) = 0
      integer :: batch_first = 0
      integer :: batch_count = 0
      integer :: batch_capacity = 0
      integer :: image_first = 0
      integer :: image_last = 0
      integer(int64) :: state_signature(12) = 0_int64
   end type cp2k_exchange_partial_descriptor_type

   !> Opaque contiguous complex payload for the additive forward k-to-R map.
   type, public :: cp2k_exchange_partial_forward_type
      private
      integer :: abi_version = 0
      integer(int64) :: descriptor_signature(2) = 0_int64
      complex(wp), allocatable :: values(:)
   end type cp2k_exchange_partial_forward_type

   !> Opaque contiguous complex payload for the additive reverse source map.
   type, public :: cp2k_exchange_partial_reverse_type
      private
      integer :: abi_version = 0
      integer(int64) :: descriptor_signature(2) = 0_int64
      complex(wp), allocatable :: values(:)
   end type cp2k_exchange_partial_reverse_type

contains

!> Return a real-space cutoff that covers both the valence basis and the
!> auxiliary ACP projectors used by g-xTB.
pure function cp2k_get_acp_cutoff(calc, accuracy) result(cutoff)
   type(xtb_calculator), intent(in) :: calc
   real(wp), intent(in) :: accuracy
   real(wp) :: cutoff

   cutoff = get_cutoff(calc%bas, accuracy)
   if (allocated(calc%acp)) then
      cutoff = max(cutoff, get_pair_cutoff(calc%bas, calc%acp%auxbas, accuracy))
   end if
end function cp2k_get_acp_cutoff

!> Construct a CP2K-facing g-xTB potential mixer.
subroutine new_cp2k_potential_mixer(self, ndim, error)
   type(cp2k_potential_mixer_type), intent(out) :: self
   integer, intent(in) :: ndim
   type(error_type), allocatable, intent(out) :: error

   call self%reset(ndim, error)
end subroutine new_cp2k_potential_mixer

!> Reset a CP2K-facing g-xTB potential mixer for a flat Fock vector.
subroutine cp2k_potential_mixer_reset(self, ndim, error)
   class(cp2k_potential_mixer_type), intent(inout) :: self
   integer, intent(in) :: ndim
   type(error_type), allocatable, intent(out) :: error

   if (allocated(self%simple_cache%raw)) then
      call self%simple%cleanup(self%simple_cache)
      deallocate(self%simple_cache%raw)
   end if
   if (allocated(self%diis_cache%raw)) then
      call self%diis%cleanup(self%diis_cache)
      deallocate(self%diis_cache%raw)
   end if

   self%ndim = 0
   self%iteration = 0
   self%residual = 0.0_wp
   self%initialized = .false.

   if (ndim <= 0) then
      call fatal_error(error, "CP2K potential mixer dimension must be positive")
      return
   end if

   call new_simple(self%simple, simple_input(mode=mixer_mode%potential, &
      & start=1, damp=0.2_wp))
   call new_diis(self%diis, diis_input(mode=mixer_mode%potential, start=4, &
      & precollect=1, memory=7, damp=1.0_wp, output_fraction=1.0_wp))

   self%ndim = ndim
   self%initialized = .true.
end subroutine cp2k_potential_mixer_reset

!> Advance g-xTB's native potential mixer from a raw to a mixed Fock vector.
subroutine cp2k_potential_mixer_advance(self, raw_fock, mixed_fock, error)
   class(cp2k_potential_mixer_type), intent(inout) :: self
   real(wp), intent(in) :: raw_fock(:)
   real(wp), intent(out) :: mixed_fock(:)
   type(error_type), allocatable, intent(out) :: error

   integer :: next_iteration

   mixed_fock = 0.0_wp
   if (.not. self%initialized) then
      call fatal_error(error, "CP2K potential mixer must be reset before use")
      return
   end if
   if (size(raw_fock) /= self%ndim .or. size(mixed_fock) /= self%ndim) then
      call fatal_error(error, "CP2K potential mixer Fock vector dimension mismatch")
      return
   end if
   if (.not. all(ieee_is_finite(raw_fock))) then
      call fatal_error(error, "CP2K potential mixer received a non-finite Fock vector")
      return
   end if

   next_iteration = self%iteration + 1
   select case(next_iteration)
   case(1)
      call self%simple%update(self%simple_cache, self%ndim)
      self%simple_cache%raw%iset = 0
      call self%simple%set(self%simple_cache, raw_fock)
      self%simple_cache%raw%initialized = .true.
      mixed_fock = raw_fock
      self%residual = 0.0_wp

   case(2)
      ! The DIIS cache is prepared one step before its first precollection.
      call self%diis%update(self%diis_cache, self%ndim)

      self%simple_cache%raw%idif = 0
      call self%simple%diff(self%simple_cache, raw_fock)
      self%residual = self%simple%get_error(self%simple_cache)
      call self%simple%collect(self%simple_cache)
      call self%simple%next(self%simple_cache, error)
      if (allocated(error)) return
      self%simple_cache%raw%iget = 0
      call self%simple%get(self%simple_cache, mixed_fock)

      call set_simple_input(self, mixed_fock)
      call set_diis_input(self, mixed_fock)

   case(3)
      self%simple_cache%raw%idif = 0
      call self%simple%diff(self%simple_cache, raw_fock)
      self%diis_cache%raw%idif = 0
      call self%diis%diff(self%diis_cache, raw_fock)
      self%residual = self%simple%get_error(self%simple_cache)

      call self%simple%collect(self%simple_cache)
      call self%diis%collect(self%diis_cache)
      call self%simple%next(self%simple_cache, error)
      if (allocated(error)) return
      self%simple_cache%raw%iget = 0
      call self%simple%get(self%simple_cache, mixed_fock)

      call set_simple_input(self, mixed_fock)
      call set_diis_input(self, mixed_fock)

   case default
      if (next_iteration == 4) then
         ! This is the iterator's simple-to-DIIS transition point.
         call self%simple%cleanup(self%simple_cache)
         deallocate(self%simple_cache%raw)
         call self%diis%update(self%diis_cache, self%ndim)
      end if

      self%diis_cache%raw%idif = 0
      call self%diis%diff(self%diis_cache, raw_fock)
      self%residual = self%diis%get_error(self%diis_cache)
      call self%diis%collect(self%diis_cache)
      call self%diis%next(self%diis_cache, error)
      if (allocated(error)) return
      self%diis_cache%raw%iget = 0
      call self%diis%get(self%diis_cache, mixed_fock)
      call set_diis_input(self, mixed_fock)
   end select

   if (.not. ieee_is_finite(self%residual)) then
      call fatal_error(error, "CP2K potential mixer produced a non-finite residual")
      return
   end if
   if (.not. all(ieee_is_finite(mixed_fock))) then
      call fatal_error(error, "CP2K potential mixer produced a non-finite Fock vector")
      return
   end if
   self%iteration = next_iteration
end subroutine cp2k_potential_mixer_advance

!> Return the RMS residual from the most recent raw Fock vector.
pure function cp2k_potential_mixer_get_error(self) result(residual)
   class(cp2k_potential_mixer_type), intent(in) :: self
   real(wp) :: residual

   residual = self%residual
end function cp2k_potential_mixer_get_error

!> Store the current extrapolated vector in the simple mixer cache.
subroutine set_simple_input(self, fock)
   class(cp2k_potential_mixer_type), intent(inout) :: self
   real(wp), intent(in) :: fock(:)

   self%simple_cache%raw%iset = 0
   call self%simple%set(self%simple_cache, fock)
   self%simple_cache%raw%initialized = .true.
end subroutine set_simple_input

!> Store the current extrapolated vector in the DIIS mixer cache.
subroutine set_diis_input(self, fock)
   class(cp2k_potential_mixer_type), intent(inout) :: self
   real(wp), intent(in) :: fock(:)

   self%diis_cache%raw%iset = 0
   call self%diis%set(self%diis_cache, fock)
   self%diis_cache%raw%initialized = .true.
end subroutine set_diis_input

!> Return the CP2K-owned SCC mixer dimension without the spin multiplicity.
!>
!> The orbital density is deliberately not included here, even when a
!> contribution advertises an orbital-resolved density potential.  CP2K
!> diagonalizes and stores that density itself; only charges and multipoles
!> are exchanged with its SCC mixer through the compatibility interface.
pure function cp2k_get_scc_mixer_dimension(mol, bas, info) result(ndim)
   type(structure_type), intent(in) :: mol
   class(basis_type), intent(in) :: bas
   type(scf_info), intent(in) :: info
   integer :: ndim

   ndim = 0
   select case(info%charge)
   case(atom_resolved)
      ndim = ndim + mol%nat
   case(shell_resolved)
      ndim = ndim + bas%nsh
   end select
   if (info%dipole == atom_resolved) ndim = ndim + 3*mol%nat
   if (info%quadrupole == atom_resolved) ndim = ndim + 6*mol%nat
end function cp2k_get_scc_mixer_dimension

!> Backward-compatible name for the CP2K SCC mixer dimension.
pure function cp2k_get_mixer_dimension(mol, bas, info) result(ndim)
   type(structure_type), intent(in) :: mol
   class(basis_type), intent(in) :: bas
   type(scf_info), intent(in) :: info
   integer :: ndim

   ndim = cp2k_get_scc_mixer_dimension(mol, bas, info)
end function cp2k_get_mixer_dimension

!> Apply SCC settings using the iterator API used by save_tblite.
subroutine cp2k_set_scf_options(calc, max_iter, damping)
   type(xtb_calculator), intent(inout) :: calc
   integer, intent(in) :: max_iter
   real(wp), intent(in) :: damping

   calc%iterator%max_iter = max_iter
   call calc%iterator%set_mixer_damping(simple_damping=damping, &
      & broyden_damping=damping)
end subroutine cp2k_set_scf_options

!> Construct the immutable auxiliary charges and cache the effective basis.
subroutine cp2k_update_basis(calc, mol, cache, error, grad, wfn_aux)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(inout) :: cache
   type(error_type), allocatable, intent(out) :: error
   logical, intent(in), optional :: grad
   type(wavefunction_type), intent(inout), optional :: wfn_aux
   type(wavefunction_type) :: local_wfn_aux
   logical :: do_grad

   do_grad = .false.
   if (present(grad)) do_grad = grad

   if (allocated(calc%charge_model)) then
      if (present(wfn_aux)) then
         call new_wavefunction(wfn_aux, mol%nat, calc%bas%nsh, 0, 1, 0.0_wp, do_grad)
         if (do_grad) then
            call get_charges(calc%charge_model, mol, error, wfn_aux%qat(:, 1), &
               & dqdr=wfn_aux%dqatdr(:, :, :, 1), dqdL=wfn_aux%dqatdL(:, :, :, 1))
         else
            call get_charges(calc%charge_model, mol, error, wfn_aux%qat(:, 1))
         end if
         if (allocated(error)) return
         call calc%bas%update(mol, cache, do_grad, wfn_aux)
      else
         call new_wavefunction(local_wfn_aux, mol%nat, calc%bas%nsh, 0, 1, 0.0_wp, do_grad)
         if (do_grad) then
            call get_charges(calc%charge_model, mol, error, local_wfn_aux%qat(:, 1), &
               & dqdr=local_wfn_aux%dqatdr(:, :, :, 1), &
               & dqdL=local_wfn_aux%dqatdL(:, :, :, 1))
         else
            call get_charges(calc%charge_model, mol, error, local_wfn_aux%qat(:, 1))
         end if
         if (allocated(error)) return
         call calc%bas%update(mol, cache, do_grad, local_wfn_aux)
      end if
   else
      call calc%bas%update(mol, cache, do_grad)
   end if
end subroutine cp2k_update_basis

!> Build the complete Gamma-point overlap and one-electron g-xTB Hamiltonian.
!>
!> The dense matrices are deliberately returned in tblite's atom/AO ordering.
!> CP2K can scatter them into its block-sparse matrices while retaining the
!> element-wise basis metadata used for block dimensions and cutoffs.
subroutine cp2k_build_gamma_h0(calc, mol, bcache, acache, accuracy, selfenergy, &
   & overlap, dipole, quadrupole, hamiltonian)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   type(acp_cache), intent(inout) :: acache
   real(wp), intent(in) :: accuracy
   real(wp), intent(in) :: selfenergy(:)
   real(wp), intent(out) :: overlap(:, :), dipole(:, :, :), quadrupole(:, :, :)
   real(wp), intent(out) :: hamiltonian(:, :)

   real(wp) :: cutoff
   real(wp), allocatable :: aniso_dip(:, :), lattr(:, :)
   type(adjacency_list) :: list

   allocate(aniso_dip(3, mol%nat))
   cutoff = cp2k_get_acp_cutoff(calc, accuracy)
   call get_lattice_points(mol%periodic, mol%lattice, cutoff, lattr)
   call new_adjacency_list(list, mol, lattr, cutoff)
   if (any(mol%periodic)) then
      call get_anisotropy(calc%h0, mol, lattr, list, aniso_dip)
   else
      call get_anisotropy(calc%h0, mol, aniso_dip)
   end if
   call get_hamiltonian(mol, lattr, list, calc%bas, bcache, calc%h0, &
      & selfenergy, aniso_dip, overlap, dipole, quadrupole, hamiltonian)

   if (allocated(calc%acp)) then
      call calc%acp%update(mol, acache)
      call get_acp(mol, lattr, list, calc%bas, bcache, calc%acp, acache, hamiltonian)
   end if
end subroutine cp2k_build_gamma_h0

!> Build image-resolved q-vSZP overlap, multipoles, and H0 matrices.
!>
!> This routine deliberately covers the one-electron H0 only.  The atomic
!> correction potential is a projector convolution and therefore requires a
!> separate image-resolved implementation before a complete k-point
!> Hamiltonian can be assembled.
subroutine cp2k_build_image_h0(calc, mol, bcache, accuracy, selfenergy, &
   & translations, images, overlap_gamma, dipole_gamma, quadrupole_gamma, &
   & hamiltonian_gamma)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   real(wp), intent(in) :: accuracy
   real(wp), intent(in) :: selfenergy(:)
   real(wp), intent(in) :: translations(:, :)
   type(hamiltonian_image_type), intent(out) :: images
   real(wp), intent(out), optional :: overlap_gamma(:, :)
   real(wp), intent(out), optional :: dipole_gamma(:, :, :)
   real(wp), intent(out), optional :: quadrupole_gamma(:, :, :)
   real(wp), intent(out), optional :: hamiltonian_gamma(:, :)

   real(wp) :: cutoff
   real(wp), allocatable :: aniso_dip(:, :), dipole(:, :, :), &
      & hamiltonian(:, :), overlap(:, :), quadrupole(:, :, :)
   type(adjacency_list) :: list

   allocate(aniso_dip(3, mol%nat), overlap(calc%bas%nao, calc%bas%nao), &
      & dipole(3, calc%bas%nao, calc%bas%nao), &
      & quadrupole(6, calc%bas%nao, calc%bas%nao), &
      & hamiltonian(calc%bas%nao, calc%bas%nao))
   cutoff = get_cutoff(calc%bas, accuracy)
   call new_adjacency_list(list, mol, translations, cutoff)
   if (any(mol%periodic)) then
      call get_anisotropy(calc%h0, mol, translations, list, aniso_dip)
   else
      call get_anisotropy(calc%h0, mol, aniso_dip)
   end if
   call get_hamiltonian(mol, translations, list, calc%bas, bcache, calc%h0, &
      & selfenergy, aniso_dip, overlap, dipole, quadrupole, hamiltonian, images)

   if (present(overlap_gamma)) overlap_gamma = overlap
   if (present(dipole_gamma)) dipole_gamma = dipole
   if (present(quadrupole_gamma)) quadrupole_gamma = quadrupole
   if (present(hamiltonian_gamma)) hamiltonian_gamma = hamiltonian
end subroutine cp2k_build_image_h0

!> Build the image-resolved separable ACP contribution.
!>
!> The returned Hamiltonian translations are generally a larger difference
!> set than the translations supplied for the projector integrals.  External
!> drivers must therefore scatter this set independently of the pair-local H0
!> image set.
subroutine cp2k_build_image_acp(calc, mol, bcache, acache, translations, &
   & images, hamiltonian_gamma)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   type(acp_cache), intent(inout) :: acache
   real(wp), intent(in) :: translations(:, :)
   type(acp_image_type), intent(out) :: images
   real(wp), intent(out), optional :: hamiltonian_gamma(:, :)

   call get_acp_images(mol, translations, calc%bas, bcache, calc%acp, acache, &
      & images)
   if (present(hamiltonian_gamma)) then
      hamiltonian_gamma = sum(images%hamiltonian, dim=3)
   end if
end subroutine cp2k_build_image_acp

!> Build only the compact projector-overlap images required by the direct
!> Bloch-space ACP forward and reverse sweeps.  Unlike
!> `cp2k_build_image_acp`, this deliberately does not materialize the
!> quadratic translation-difference set or H(R).
subroutine cp2k_build_acp_projectors(calc, mol, bcache, acache, translations, &
   & images)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   type(acp_cache), intent(inout) :: acache
   real(wp), intent(in) :: translations(:, :)
   type(acp_image_type), intent(out) :: images

   call get_acp_images(mol, translations, calc%bas, bcache, calc%acp, acache, &
      & images, build_hamiltonian=.false.)
end subroutine cp2k_build_acp_projectors

!> Image-resolved ACP response for CP2K k-point density matrices.
!>
!> `density(:, :, R, spin)` must be in save_tblite's AO image orientation and
!> dual to the Hamiltonian returned by `cp2k_build_image_acp`, so that its
!> energy contribution is the element-wise contraction over equal images.
!> CP2K's irreducible-star weights must already be included in these real-space
!> densities.
subroutine cp2k_acp_image_gradient(calc, mol, bcache, acache, images, &
   & density_translation, density, dEdcnbas, dEdqbas, gradient, sigma, error)
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   type(acp_cache), intent(in) :: acache
   type(acp_image_type), intent(in) :: images
   real(wp), intent(in) :: density_translation(:, :)
   real(wp), intent(in) :: density(:, :, :, :)
   real(wp), intent(inout) :: dEdcnbas(:), dEdqbas(:)
   real(wp), intent(inout) :: gradient(:, :), sigma(:, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not. allocated(calc%acp)) then
      call fatal_error(error, "g-xTB ACP image gradient requires an ACP model")
      return
   end if
   call get_acp_image_gradient(mol, calc%bas, bcache, calc%acp, acache, &
      & images, density_translation, density, dEdcnbas, dEdqbas, gradient, &
      & sigma, error)
end subroutine cp2k_acp_image_gradient

!> Evaluate the separable ACP directly on CP2K Bloch points.
subroutine cp2k_acp_kmesh(calc, mol, images, kfrac, hamiltonian, error)
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(acp_image_type), intent(in) :: images
   real(wp), intent(in) :: kfrac(:, :)
   complex(wp), intent(out) :: hamiltonian(:, :, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not.allocated(calc%acp)) then
      call fatal_error(error, "g-xTB ACP container is not allocated")
      return
   end if
   call get_acp_kmesh(mol, images, kfrac, hamiltonian, error)
end subroutine cp2k_acp_kmesh

!> Differentiate the complete weighted Bloch contraction of the ACP.
subroutine cp2k_acp_kmesh_gradient(calc, mol, bcache, acache, images, &
   & kfrac, weights, density, dEdcnbas, dEdqbas, gradient, sigma, error)
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   type(acp_cache), intent(in) :: acache
   type(acp_image_type), intent(in) :: images
   real(wp), intent(in) :: kfrac(:, :), weights(:)
   complex(wp), intent(in) :: density(:, :, :, :)
   real(wp), intent(inout) :: dEdcnbas(:), dEdqbas(:)
   real(wp), intent(inout) :: gradient(:, :), sigma(:, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not.allocated(calc%acp)) then
      call fatal_error(error, "g-xTB ACP container is not allocated")
      return
   end if
   call get_acp_kmesh_gradient(mol, calc%bas, bcache, calc%acp, acache, &
      & images, kfrac, weights, density, dEdcnbas, dEdqbas, gradient, &
      & sigma, error)
end subroutine cp2k_acp_kmesh_gradient

!> Apply a component's q-vSZP basis response and external-charge chain rule.
!>
!> Image-resolved one-electron components return their own additive
!> `dE/dCN_basis` and `dE/dq_basis`.  This helper maps exactly that component
!> onto Cartesian and strain derivatives.  Calling it separately for H0 and
!> ACP therefore remains additive and avoids applying either response twice.
subroutine cp2k_apply_basis_gradient(calc, mol, wfn_aux, dEdcnbas, dEdqbas, &
   & gradient, sigma)
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(wavefunction_type), intent(in) :: wfn_aux
   real(wp), intent(in) :: dEdcnbas(:), dEdqbas(:)
   real(wp), intent(inout) :: gradient(:, :), sigma(:, :)

   real(wp), allocatable :: dEdq(:)

   allocate(dEdq(mol%nat), source=0.0_wp)
   if (calc%bas%charge_dependent) then
      call calc%bas%get_basis_gradient(mol, dEdcnbas, dEdqbas, dEdq, &
         & gradient, sigma)
   end if
   if (allocated(wfn_aux%dqatdr)) then
      call gemv(wfn_aux%dqatdr(:, :, :, 1), dEdq, gradient, beta=1.0_wp)
   end if
   if (allocated(wfn_aux%dqatdL)) then
      call gemv(wfn_aux%dqatdL(:, :, :, 1), dEdq, sigma, beta=1.0_wp)
   end if
end subroutine cp2k_apply_basis_gradient

!> Prepare geometry- and charge-dependent exchange kernels.
!>
!> This routine must be called once, serially, before evaluating the k-point
!> blocks of every SCC iteration.  Rebuilding here also makes changes of the
!> geometry or lattice visible to the Wigner-Seitz and bond-order kernels.
subroutine cp2k_prepare_exchange(calc, mol, ecache, wfn, error)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   type(wavefunction_type), intent(in) :: wfn
   type(error_type), allocatable, intent(out) :: error

   if (.not. allocated(calc%exchange)) then
      call fatal_error(error, "g-xTB exchange container is not allocated")
      return
   end if

   call calc%exchange%update(mol, ecache)
   select type (cache => ecache%raw)
   type is (exchange_cache)
      call calc%exchange%get_onsite_Kmatrix(mol, wfn, cache)
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
   end select
end subroutine cp2k_prepare_exchange

!> Evaluate the g-xTB exchange operator for one complex k-point block.
!>
!> The input P(k) must not contain a k-point or star weight.  The caller owns
!> all Brillouin-zone weights and symmetry expansion.  This routine returns
!> an unweighted Hermitian F(k), an atom/shell-resolved potential, and an
!> unweighted exchange energy.  For a reduced k mesh the shell potential must
!> be permuted with every star operation before the weighted star sum is made.
!> Call cp2k_prepare_exchange serially before entering the k-point loop; this
!> evaluator then only reads the shared cache and can be called concurrently.
subroutine cp2k_exchange_kpoint(calc, mol, ecache, density, overlap, &
   & fock, vsh, energy, error)
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(in) :: ecache
   complex(wp), intent(in) :: density(:, :, :), overlap(:, :)
   complex(wp), intent(out) :: fock(:, :, :)
   real(wp), intent(out) :: vsh(:), energy
   type(error_type), allocatable, intent(out) :: error

   if (.not. allocated(calc%exchange)) then
      call fatal_error(error, "g-xTB exchange container is not allocated")
      return
   end if
   if (.not. allocated(ecache%raw)) then
      call fatal_error(error, &
         & "k-point exchange cache is not prepared; call cp2k_prepare_exchange")
      return
   end if

   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         call exchange%get_KFock_kpoint(mol, cache, density, overlap, fock, &
            & vsh, energy)
      class default
         call fatal_error(error, &
            & "k-point exchange requires the exchange_fock implementation")
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
   end select
end subroutine cp2k_exchange_kpoint

!> Evaluate one regular-grid Fourier character from a compact immutable plan.
!>
!> The supplied representative may be canonical or a difference of two
!> representatives.  Reducing each integer product modulo its mesh extent
!> makes the result independent of representative wrapping.  No transcendental
!> operation and no dense Nk-by-Nk phase storage is required here.
pure complex(wp) function regular_grid_phase_forward(nmesh, input_to_grid, &
   & representative, phase_roots, twist_phase, ik) result(phase)
   integer, intent(in) :: nmesh(3), input_to_grid(:), representative(3), ik
   complex(wp), intent(in) :: phase_roots(:, :), twist_phase

   integer :: grid(3), idim, igrid, root

   igrid = input_to_grid(ik)-1
   grid(1) = modulo(igrid, nmesh(1))
   grid(2) = modulo(igrid/nmesh(1), nmesh(2))
   grid(3) = igrid/(nmesh(1)*nmesh(2))
   phase = twist_phase
   do idim = 1, 3
      root = modulo(grid(idim)*modulo(representative(idim), nmesh(idim)), &
         & nmesh(idim))
      phase = phase*phase_roots(root+1, idim)
   end do
end function regular_grid_phase_forward

!> Verify the roundoff-exact finite-group grid required by factorized DFTs.
!> The dense oracle deliberately accepts the looser geometric plan tolerance;
!> a factorized transform must not silently project such perturbed points back
!> onto the nearest regular grid.
pure logical function machine_regular_bvk_plan(cache, nmesh, kfrac) &
   & result(regular)
   type(exchange_cache), intent(in) :: cache
   integer, intent(in) :: nmesh(3)
   real(wp), intent(in) :: kfrac(:, :)

   integer :: grid(3), idim, igrid, ik
   real(wp) :: canonical, periodic_delta

   regular = .false.
   if (.not.allocated(cache%bvk_input_to_grid)) return
   if (size(cache%bvk_input_to_grid) /= size(kfrac, 2)) return
   do ik = 1, size(kfrac, 2)
      igrid = cache%bvk_input_to_grid(ik)-1
      grid(1) = modulo(igrid, nmesh(1))
      grid(2) = modulo(igrid/nmesh(1), nmesh(2))
      grid(3) = igrid/(nmesh(1)*nmesh(2))
      do idim = 1, 3
         canonical = cache%bvk_twist(idim) &
            & +real(grid(idim), wp)/real(nmesh(idim), wp)
         periodic_delta = modulo(kfrac(idim, ik), 1.0_wp) &
            & -modulo(canonical, 1.0_wp)
         periodic_delta = periodic_delta-nint(periodic_delta)
         if (abs(periodic_delta) > 64.0_wp*epsilon(1.0_wp)) return
      end do
   end do
   regular = .true.
end function machine_regular_bvk_plan

!> Build or reuse the geometry- and mesh-static BvK kernel/Fourier plan.
subroutine prepare_bvk_plan(exchange, mol, cache, nmesh, kfrac, weights, &
   & error, retain_dense_phases)
   type(exchange_fock), intent(in) :: exchange
   type(structure_type), intent(in) :: mol
   type(exchange_cache), intent(inout) :: cache
   integer, intent(in) :: nmesh(3)
   real(wp), intent(in) :: kfrac(:, :), weights(:)
   type(error_type), allocatable, intent(out) :: error
   logical, intent(in), optional :: retain_dense_phases

   integer :: grid(3), icell, idim, igrid, ik, jcell, nearest, nk, root
   logical :: need_dense_phases, reuse_kernel
   logical, allocatable :: seen(:)
   real(wp) :: angle, scaled, target
   real(wp), allocatable :: kred(:, :)
   complex(wp) :: orthogonality, phase

   nk = size(weights)
   reuse_kernel = .false.
   need_dense_phases = .true.
   if (present(retain_dense_phases)) &
      & need_dense_phases = retain_dense_phases
   if (cache%bvk_matches(mol, nmesh, kfrac, weights, &
      & require_phases=.false.) &
      & .and. exchange%bvk_model_matches(cache)) then
      if (any(shape(cache%bvk_kernel%g_mulliken_r) /= &
         & [exchange%nsh, exchange%nsh, nk])) then
         cache%bvk_plan_valid = .false.
      else if (.not.need_dense_phases) then
         if (allocated(cache%bvk_phase_forward)) &
            & deallocate(cache%bvk_phase_forward)
         if (allocated(cache%bvk_phase_inverse)) &
            & deallocate(cache%bvk_phase_inverse)
         return
      else if (allocated(cache%bvk_phase_forward) &
         & .and. allocated(cache%bvk_phase_inverse)) then
         if (all(shape(cache%bvk_phase_forward) == [nk, nk]) &
            & .and. all(shape(cache%bvk_phase_inverse) == [nk, nk])) return
         reuse_kernel = .true.
      else
         reuse_kernel = .true.
      end if
   end if
   allocate(kred(3, nk))
   kred = modulo(kfrac, 1.0_wp)
   if (.not.reuse_kernel) then
      cache%bvk_plan_valid = .false.

      if (allocated(cache%bvk_input_to_grid)) &
         & deallocate(cache%bvk_input_to_grid)
      if (allocated(cache%bvk_grid_to_input)) &
         & deallocate(cache%bvk_grid_to_input)
      allocate(cache%bvk_input_to_grid(nk), cache%bvk_grid_to_input(nk), source=0)
      allocate(seen(nk), source=.false.)
      do idim = 1, 3
         cache%bvk_twist(idim) = kred(idim, 1) &
            & -real(floor(kred(idim, 1)*real(nmesh(idim), wp)), wp) &
            & /real(nmesh(idim), wp)
      end do
      do ik = 1, nk
         do idim = 1, 3
            scaled = (kred(idim, ik)-cache%bvk_twist(idim)) &
               & *real(nmesh(idim), wp)
            nearest = nint(scaled)
            if (abs(scaled-real(nearest, wp)) > 1.0e-10_wp) then
               call fatal_error(error, &
                  & "g-xTB k points do not share a regular-grid twist")
               return
            end if
            grid(idim) = modulo(nearest, nmesh(idim))
         end do
         igrid = 1 + grid(1) + nmesh(1)*(grid(2)+nmesh(2)*grid(3))
         if (seen(igrid)) then
            call fatal_error(error, &
               & "g-xTB k-point mesh contains a duplicate grid point")
            return
         end if
         seen(igrid) = .true.
         cache%bvk_input_to_grid(ik) = igrid
         cache%bvk_grid_to_input(igrid) = ik
      end do
      if (.not.all(seen)) then
         call fatal_error(error, "g-xTB k-point mesh is incomplete")
         return
      end if

      ! Construct the expensive image kernel only after the O(Nk) mesh proof.
      call exchange%get_bvk_Kmatrix(mol, nmesh, cache%bvk_kernel)
      if (any(shape(cache%bvk_kernel%reps) /= [3, nk]) &
         & .or. any(shape(cache%bvk_kernel%g_mulliken_r) /= &
         & [exchange%nsh, exchange%nsh, nk]) &
         & .or. any(shape(cache%bvk_kernel%g_bocorr_r) /= &
         & [mol%nat, mol%nat, nk])) then
         call fatal_error(error, "g-xTB BvK kernel has inconsistent dimensions")
         return
      end if

      ! A regular mesh needs only one roots-of-unity vector per direction and
      ! one twist character per image.  This O(Nk+3*max(nmesh)) plan is retained
      ! with the expensive BvK kernel and lets bounded batching evaluate every
      ! forward/inverse character without rebuilding dense Nk-by-Nk phases or
      ! calling EXP in its repeated push/pull loops.
      if (allocated(cache%bvk_phase_roots)) &
         & deallocate(cache%bvk_phase_roots)
      if (allocated(cache%bvk_twist_phase)) &
         & deallocate(cache%bvk_twist_phase)
      allocate(cache%bvk_phase_roots(maxval(nmesh), 3), &
         & source=(1.0_wp, 0.0_wp))
      do idim = 1, 3
         do root = 0, nmesh(idim)-1
            angle = 2.0_wp*pi*real(root, wp)/real(nmesh(idim), wp)
            cache%bvk_phase_roots(root+1, idim) = &
               & exp(cmplx(0.0_wp, angle, wp))
         end do
      end do
      allocate(cache%bvk_twist_phase(nk))
      do icell = 1, nk
         angle = 2.0_wp*pi*dot_product(cache%bvk_twist, &
            & real(cache%bvk_kernel%reps(:, icell), wp))
         cache%bvk_twist_phase(icell) = exp(cmplx(0.0_wp, angle, wp))
      end do
   end if

   if (allocated(cache%bvk_phase_forward)) &
      & deallocate(cache%bvk_phase_forward)
   if (allocated(cache%bvk_phase_inverse)) &
      & deallocate(cache%bvk_phase_inverse)
   if (need_dense_phases) then
      allocate(cache%bvk_phase_forward(size(cache%bvk_kernel%reps, 2), nk), &
         & cache%bvk_phase_inverse(nk, size(cache%bvk_kernel%reps, 2)))
      do ik = 1, nk
         do icell = 1, size(cache%bvk_kernel%reps, 2)
            angle = 2.0_wp*pi*dot_product(kred(:, ik), &
               & real(cache%bvk_kernel%reps(:, icell), wp))
            phase = exp(cmplx(0.0_wp, angle, wp))
            cache%bvk_phase_forward(icell, ik) = phase
            cache%bvk_phase_inverse(ik, icell) = weights(ik)*conjg(phase)
         end do
      end do
   end if

   ! Keep a dense phase-orthogonality oracle for small meshes.  The unique
   ! integer-grid map above is the O(Nk) production proof for larger meshes
   ! and is also the ordering descriptor required by a future FFT backend.
   if (nk <= 64) then
      do icell = 1, nk
         do jcell = 1, nk
            if (need_dense_phases) then
               orthogonality = sum(cache%bvk_phase_forward(icell, :) &
                  & *cache%bvk_phase_inverse(:, jcell))
            else
               orthogonality = (0.0_wp, 0.0_wp)
               do ik = 1, nk
                  orthogonality = orthogonality &
                     & +weights(ik)*regular_grid_phase_forward(nmesh, &
                     & cache%bvk_input_to_grid, &
                     & cache%bvk_kernel%reps(:, icell) &
                     & -cache%bvk_kernel%reps(:, jcell), &
                     & cache%bvk_phase_roots, &
                     & cache%bvk_twist_phase(icell) &
                     & *conjg(cache%bvk_twist_phase(jcell)), ik)
               end do
            end if
            target = merge(1.0_wp, 0.0_wp, icell == jcell)
            if (abs(orthogonality-target) > 1.0e-10_wp) then
               call fatal_error(error, &
                  & "g-xTB k points are not a complete Fourier mesh")
               return
            end if
         end do
      end do
   end if
   if (.not.reuse_kernel) then
      call exchange%set_bvk_model_signature(cache)
      call cache%set_bvk_signature(mol, nmesh, kfrac, weights)
   end if
end subroutine prepare_bvk_plan

!> Evaluate BvK-supercell-equivalent exchange on a complete regular k mesh.
!>
!> Density, overlap, and Fock contain unweighted Bloch blocks.  Energy and
!> shell potential are returned as complete Brillouin-zone contractions per
!> primitive cell and must not be weighted a second time by CP2K.
subroutine cp2k_exchange_kmesh(calc, mol, ecache, wfn, nmesh, kfrac, weights, &
   & density, overlap, fock, vsh, energy, error, transform_backend)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   type(wavefunction_type), intent(in) :: wfn
   integer, intent(in) :: nmesh(3)
   real(wp), intent(in) :: kfrac(:, :), weights(:)
   complex(wp), intent(in) :: density(:, :, :, :), overlap(:, :, :)
   complex(wp), intent(out) :: fock(:, :, :, :)
   real(wp), intent(out) :: vsh(:), energy
   type(error_type), allocatable, intent(out) :: error
   integer, intent(in), optional :: transform_backend

   integer :: backend, idim, nk

   backend = bvk_transform_dense
   if (present(transform_backend)) backend = transform_backend
   if (backend /= bvk_transform_dense .and. &
      & backend /= bvk_transform_separable_dft) then
      call fatal_error(error, "unknown g-xTB k-to-R transform backend")
      return
   end if
   nk = size(weights)
   if (any(nmesh < 1) .or. product(nmesh) /= nk) then
      call fatal_error(error, "g-xTB exchange requires a complete regular k mesh")
      return
   end if
   do idim = 1, 3
      if (.not.mol%periodic(idim) .and. nmesh(idim) /= 1) then
         call fatal_error(error, &
            & "nonperiodic directions cannot be replicated by the g-xTB k mesh")
         return
      end if
   end do
   if (size(kfrac, 1) /= 3 .or. size(kfrac, 2) /= nk &
      & .or. size(overlap, 3) /= nk .or. size(density, 4) /= nk &
      & .or. size(fock, 4) /= nk) then
      call fatal_error(error, "inconsistent g-xTB whole-mesh array dimensions")
      return
   end if
   if (.not.all(ieee_is_finite(kfrac))) then
      call fatal_error(error, "g-xTB whole-mesh k points must be finite")
      return
   end if
   if (.not.all(ieee_is_finite(weights)) .or. &
      & abs(sum(weights)-1.0_wp) > 1.0e-12_wp &
      & .or. maxval(abs(weights-1.0_wp/real(nk, wp))) > 1.0e-12_wp) then
      call fatal_error(error, "g-xTB whole-mesh exchange requires uniform weights")
      return
   end if
   if (backend == bvk_transform_separable_dft .and. &
      & maxval(abs(weights-1.0_wp/real(nk, wp))) > &
      & 64.0_wp*epsilon(1.0_wp)) then
      call fatal_error(error, &
         & "separable-DFT g-xTB exchange requires machine-uniform weights")
      return
   end if

   call cp2k_prepare_exchange(calc, mol, ecache, wfn, error)
   if (allocated(error)) return
   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         if (size(overlap, 1) /= exchange%nao &
            & .or. size(overlap, 2) /= exchange%nao &
            & .or. size(density, 1) /= exchange%nao &
            & .or. size(density, 2) /= exchange%nao &
            & .or. size(fock, 1) /= exchange%nao &
            & .or. size(fock, 2) /= exchange%nao &
            & .or. (size(density, 3) /= 1 .and. size(density, 3) /= 2) &
            & .or. size(density, 3) /= wfn%nspin &
            & .or. size(fock, 3) /= size(density, 3) &
            & .or. size(vsh) /= exchange%nsh) then
            call fatal_error(error, &
               & "inconsistent g-xTB whole-mesh AO, spin, or shell dimensions")
            return
         end if
         call prepare_bvk_plan(exchange, mol, cache, nmesh, kfrac, weights, &
            & error, retain_dense_phases=backend == bvk_transform_dense)
         if (allocated(error)) return
         if (backend == bvk_transform_separable_dft .and. &
            & .not.machine_regular_bvk_plan(cache, nmesh, kfrac)) then
            call fatal_error(error, &
               & "separable-DFT g-xTB exchange requires a machine-regular grid")
            return
         end if
         call exchange%get_KFock_kmesh(mol, cache, cache%bvk_kernel, &
            & kfrac, weights, density, overlap, fock, vsh, energy, backend)
      class default
         call fatal_error(error, &
            & "whole-mesh exchange requires the exchange_fock implementation")
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
   end select

end subroutine cp2k_exchange_kmesh


!> Release all storage owned by a Brillouin-zone exchange stream.
subroutine clear_exchange_stream(stream)
   type(cp2k_exchange_stream_type), intent(inout) :: stream

   if (allocated(stream%seen)) deallocate(stream%seen)
   if (allocated(stream%forward_pulled)) deallocate(stream%forward_pulled)
   if (allocated(stream%reverse_pulled)) deallocate(stream%reverse_pulled)
   if (allocated(stream%batch_pulled)) deallocate(stream%batch_pulled)
   if (allocated(stream%partial_pull_mask)) &
      & deallocate(stream%partial_pull_mask)
   if (allocated(stream%block_signature_set)) &
      & deallocate(stream%block_signature_set)
   if (allocated(stream%reps)) deallocate(stream%reps)
   if (allocated(stream%inverse_image)) deallocate(stream%inverse_image)
   if (allocated(stream%input_to_grid)) deallocate(stream%input_to_grid)
   if (allocated(stream%density_signature)) &
      & deallocate(stream%density_signature)
   if (allocated(stream%overlap_signature)) &
      & deallocate(stream%overlap_signature)
   if (allocated(stream%inverse_coeff)) deallocate(stream%inverse_coeff)
   if (allocated(stream%phase_roots)) deallocate(stream%phase_roots)
   if (allocated(stream%twist_phase)) deallocate(stream%twist_phase)
   if (allocated(stream%kfrac)) deallocate(stream%kfrac)
   if (allocated(stream%weights)) deallocate(stream%weights)
   if (allocated(stream%vsh)) deallocate(stream%vsh)
   if (allocated(stream%reverse_gradient)) deallocate(stream%reverse_gradient)
   if (allocated(stream%reverse_sigma)) deallocate(stream%reverse_sigma)
   if (allocated(stream%g_onsfx)) deallocate(stream%g_onsfx)
   if (allocated(stream%g_onsri)) deallocate(stream%g_onsri)
   if (allocated(stream%dgdq_onsfx)) deallocate(stream%dgdq_onsfx)
   if (allocated(stream%dgdq_onsri)) deallocate(stream%dgdq_onsri)
   if (allocated(stream%density)) deallocate(stream%density)
   if (allocated(stream%overlap)) deallocate(stream%overlap)
   if (allocated(stream%fock)) deallocate(stream%fock)
   if (allocated(stream%overlap_adjoint)) deallocate(stream%overlap_adjoint)
   if (allocated(stream%amat_r)) deallocate(stream%amat_r)
   if (allocated(stream%cmat_r)) deallocate(stream%cmat_r)
   if (allocated(stream%vmat_r)) deallocate(stream%vmat_r)
   if (allocated(stream%amat_partner_r)) deallocate(stream%amat_partner_r)
   if (allocated(stream%reverse_amat_r)) deallocate(stream%reverse_amat_r)
   if (allocated(stream%reverse_vmat_r)) deallocate(stream%reverse_vmat_r)
   if (allocated(stream%gdiagP)) deallocate(stream%gdiagP)
   if (allocated(stream%gdiagSP)) deallocate(stream%gdiagSP)
   if (allocated(stream%gdiagSPS)) deallocate(stream%gdiagSPS)
   if (allocated(stream%reverse_bdiagSP)) &
      & deallocate(stream%reverse_bdiagSP)
   if (allocated(stream%reverse_bdiagSPS)) &
      & deallocate(stream%reverse_bdiagSPS)
   stream%active = .false.
   stream%applied = .false.
   stream%reverse_applied = .false.
   stream%reverse_transaction = .false.
   stream%reverse_batch_applied = .false.
   stream%reverse_result_pulled = .false.
   stream%reverse_only = .false.
   stream%batch_applied = .false.
   stream%batch_result_pulled = .false.
   stream%partial_active = .false.
   stream%partial_forward_exported = .false.
   stream%partial_forward_imported = .false.
   stream%partial_reverse_exported = .false.
   stream%partial_reverse_imported = .false.
   stream%partial_pull_distribution_set = .false.
   stream%partial_result_owner = .false.
   stream%nk = 0
   stream%nao = 0
   stream%nspin = 0
   stream%nsh = 0
   stream%mode = 0
   stream%batch_size = 0
   stream%batch_first = 0
   stream%batch_count = 0
   stream%batch_last = 0
   stream%image_first = 0
   stream%plan_builds = 0
   stream%partial_generation = 0
   stream%partial_transaction_id = 0_int64
   stream%nmesh = 0
   stream%peak_complex_elements = 0_int64
   stream%kernel_signature = 0_int64
   stream%phase_signature = 0_int64
   stream%compact_phase_signature = 0_int64
   stream%partial_state_signature = 0_int64
   stream%twist = 0.0_wp
   stream%energy = 0.0_wp
end subroutine clear_exchange_stream


!> Report whether a stream owns any complete AO-matrix Bloch or image mesh.
logical function cp2k_exchange_stream_has_full_mesh_storage(stream) &
   & result(has_storage)
   type(cp2k_exchange_stream_type), intent(in) :: stream

   has_storage = allocated(stream%density) .or. allocated(stream%overlap) &
      & .or. allocated(stream%fock) .or. allocated(stream%overlap_adjoint)
   if (allocated(stream%amat_r)) has_storage = has_storage &
      & .or. size(stream%amat_r, 3) >= stream%nk
   if (allocated(stream%amat_partner_r)) has_storage = has_storage &
      & .or. size(stream%amat_partner_r, 3) >= stream%nk
   if (allocated(stream%cmat_r)) has_storage = has_storage &
      & .or. size(stream%cmat_r, 3) >= stream%nk
   if (allocated(stream%vmat_r)) has_storage = has_storage &
      & .or. size(stream%vmat_r, 3) >= stream%nk
end function cp2k_exchange_stream_has_full_mesh_storage


!> Exact batched-mode peak number of explicitly allocated complex scalars.
!>
!> This includes both transaction-owned arrays and the largest explicit
!> push/apply/pull workspace.  It deliberately excludes immutable
!> geometry/model caches shared with other calls and compiler-created
!> expression temporaries, neither of which is owned by this transaction.
!> The query returns -1 outside an active batched transaction rather than
!> under-reporting another mode.
integer(int64) function cp2k_exchange_stream_peak_complex_elements(stream) &
   & result(nelements)
   type(cp2k_exchange_stream_type), intent(in) :: stream

   if (stream%active .and. stream%mode == cp2k_exchange_stream_batched) then
      nelements = stream%peak_complex_elements
   else
      nelements = -1_int64
   end if
end function cp2k_exchange_stream_peak_complex_elements


!> Count complex scalars currently owned by a stream object.
integer(int64) function exchange_stream_complex_elements(stream) &
   & result(nelements)
   type(cp2k_exchange_stream_type), intent(in) :: stream

   nelements = 0_int64
   if (allocated(stream%density)) &
      & nelements = nelements + size(stream%density, kind=int64)
   if (allocated(stream%overlap)) &
      & nelements = nelements + size(stream%overlap, kind=int64)
   if (allocated(stream%fock)) &
      & nelements = nelements + size(stream%fock, kind=int64)
   if (allocated(stream%overlap_adjoint)) &
      & nelements = nelements + size(stream%overlap_adjoint, kind=int64)
   if (allocated(stream%amat_r)) &
      & nelements = nelements + size(stream%amat_r, kind=int64)
   if (allocated(stream%amat_partner_r)) &
      & nelements = nelements + size(stream%amat_partner_r, kind=int64)
   if (allocated(stream%reverse_amat_r)) &
      & nelements = nelements + size(stream%reverse_amat_r, kind=int64)
   if (allocated(stream%reverse_vmat_r)) &
      & nelements = nelements + size(stream%reverse_vmat_r, kind=int64)
   if (allocated(stream%cmat_r)) &
      & nelements = nelements + size(stream%cmat_r, kind=int64)
   if (allocated(stream%vmat_r)) &
      & nelements = nelements + size(stream%vmat_r, kind=int64)
   if (allocated(stream%gdiagP)) &
      & nelements = nelements + size(stream%gdiagP, kind=int64)
   if (allocated(stream%gdiagSP)) &
      & nelements = nelements + size(stream%gdiagSP, kind=int64)
   if (allocated(stream%gdiagSPS)) &
      & nelements = nelements + size(stream%gdiagSPS, kind=int64)
   if (allocated(stream%reverse_bdiagSP)) &
      & nelements = nelements + size(stream%reverse_bdiagSP, kind=int64)
   if (allocated(stream%reverse_bdiagSPS)) &
      & nelements = nelements + size(stream%reverse_bdiagSPS, kind=int64)
   if (allocated(stream%inverse_coeff)) &
      & nelements = nelements + size(stream%inverse_coeff, kind=int64)
   if (allocated(stream%phase_roots)) &
      & nelements = nelements + size(stream%phase_roots, kind=int64)
   if (allocated(stream%twist_phase)) &
      & nelements = nelements + size(stream%twist_phase, kind=int64)
end function exchange_stream_complex_elements


!> Mix one exact storage bit pattern into a deterministic transaction hash.
pure integer(int64) function exchange_hash_mix(hash, bits) result(mixed)
   integer(int64), intent(in) :: hash, bits

   mixed = ieor(ishftc(hash, 19), bits)
   mixed = ieor(mixed, ishftc(bits, 41))
end function exchange_hash_mix


!> Fingerprint one complex AO matrix exactly at the storage-bit level.
pure integer(int64) function exchange_hash_complex2(matrix) result(hash)
   complex(wp), intent(in) :: matrix(:, :)

   integer :: ii, jj
   integer(int64) :: bits

   hash = ieor(int(size(matrix, 1), int64), &
      & ishft(int(size(matrix, 2), int64), 32))
   do jj = 1, size(matrix, 2)
      do ii = 1, size(matrix, 1)
         bits = transfer(real(matrix(ii, jj), wp), bits)
         hash = exchange_hash_mix(hash, bits)
         bits = transfer(aimag(matrix(ii, jj)), bits)
         hash = exchange_hash_mix(hash, bits)
      end do
   end do
end function exchange_hash_complex2


!> Fingerprint one complex vector exactly at the storage-bit level.
pure integer(int64) function exchange_hash_complex1(vector) result(hash)
   complex(wp), intent(in) :: vector(:)

   integer :: ii
   integer(int64) :: bits

   hash = int(size(vector), int64)
   do ii = 1, size(vector)
      bits = transfer(real(vector(ii), wp), bits)
      hash = exchange_hash_mix(hash, bits)
      bits = transfer(aimag(vector(ii)), bits)
      hash = exchange_hash_mix(hash, bits)
   end do
end function exchange_hash_complex1


!> Fingerprint one spin-resolved complex AO block.
pure integer(int64) function exchange_hash_complex3(matrix) result(hash)
   complex(wp), intent(in) :: matrix(:, :, :)

   integer :: spin

   hash = int(size(matrix, 3), int64)
   do spin = 1, size(matrix, 3)
      hash = exchange_hash_mix(hash, &
         & exchange_hash_complex2(matrix(:, :, spin)))
   end do
end function exchange_hash_complex3


!> Fingerprint one real rank-three kernel array.
pure integer(int64) function exchange_hash_real3(matrix) result(hash)
   real(wp), intent(in) :: matrix(:, :, :)

   integer :: ii, jj, kk
   integer(int64) :: bits

   hash = ieor(int(size(matrix, 1), int64), &
      & ieor(ishft(int(size(matrix, 2), int64), 21), &
      & ishft(int(size(matrix, 3), int64), 42)))
   do kk = 1, size(matrix, 3)
      do jj = 1, size(matrix, 2)
         do ii = 1, size(matrix, 1)
            bits = transfer(matrix(ii, jj, kk), bits)
            hash = exchange_hash_mix(hash, bits)
         end do
      end do
   end do
end function exchange_hash_real3


!> Fingerprint the exact representative ordering of a BvK plan.
pure integer(int64) function exchange_hash_integer2(matrix) result(hash)
   integer, intent(in) :: matrix(:, :)

   integer :: ii, jj

   hash = ieor(int(size(matrix, 1), int64), &
      & ishft(int(size(matrix, 2), int64), 32))
   do jj = 1, size(matrix, 2)
      do ii = 1, size(matrix, 1)
         hash = exchange_hash_mix(hash, int(matrix(ii, jj), int64))
      end do
   end do
end function exchange_hash_integer2


!> Fingerprint one real vector exactly at the storage-bit level.
pure integer(int64) function exchange_hash_real1(vector) result(hash)
   real(wp), intent(in) :: vector(:)

   integer :: ii
   integer(int64) :: bits

   hash = int(size(vector), int64)
   do ii = 1, size(vector)
      bits = transfer(vector(ii), bits)
      hash = exchange_hash_mix(hash, bits)
   end do
end function exchange_hash_real1


!> Fingerprint one real matrix exactly at the storage-bit level.
pure integer(int64) function exchange_hash_real2(matrix) result(hash)
   real(wp), intent(in) :: matrix(:, :)

   integer :: ii, jj
   integer(int64) :: bits

   hash = ieor(int(size(matrix, 1), int64), &
      & ishft(int(size(matrix, 2), int64), 32))
   do jj = 1, size(matrix, 2)
      do ii = 1, size(matrix, 1)
         bits = transfer(matrix(ii, jj), bits)
         hash = exchange_hash_mix(hash, bits)
      end do
   end do
end function exchange_hash_real2


!> Fingerprint one integer vector including its exact ordering.
pure integer(int64) function exchange_hash_integer1(vector) result(hash)
   integer, intent(in) :: vector(:)

   integer :: ii

   hash = int(size(vector), int64)
   do ii = 1, size(vector)
      hash = exchange_hash_mix(hash, int(vector(ii), int64))
   end do
end function exchange_hash_integer1


!> Capture all immutable state that defines a partial k-to-R transaction.
subroutine initialize_partial_state_signature(stream, mol)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(structure_type), intent(in) :: mol

   integer :: periodic_integer(3)

   periodic_integer = merge(1, 0, mol%periodic)
   stream%partial_state_signature = 0_int64
   stream%partial_state_signature(1) = exchange_hash_real2(stream%kfrac)
   stream%partial_state_signature(2) = exchange_hash_real1(stream%weights)
   stream%partial_state_signature(3) = exchange_hash_integer2(stream%reps)
   stream%partial_state_signature(4) = &
      & exchange_hash_integer1(stream%input_to_grid)
   stream%partial_state_signature(5) = &
      & exchange_hash_complex2(stream%phase_roots)
   stream%partial_state_signature(6) = &
      & exchange_hash_complex1(stream%twist_phase)
   stream%partial_state_signature(7:8) = stream%kernel_signature
   stream%partial_state_signature(9) = exchange_hash_real3(stream%g_onsfx)
   stream%partial_state_signature(9) = exchange_hash_mix( &
      & stream%partial_state_signature(9), &
      & exchange_hash_real2(stream%g_onsri))
   stream%partial_state_signature(9) = exchange_hash_mix( &
      & stream%partial_state_signature(9), &
      & exchange_hash_real3(stream%dgdq_onsfx))
   stream%partial_state_signature(9) = exchange_hash_mix( &
      & stream%partial_state_signature(9), &
      & exchange_hash_real2(stream%dgdq_onsri))
   stream%partial_state_signature(10) = exchange_hash_real2(mol%xyz)
   stream%partial_state_signature(11) = exchange_hash_real2(mol%lattice)
   stream%partial_state_signature(12) = exchange_hash_integer1(mol%num)
   stream%partial_state_signature(12) = exchange_hash_mix( &
      & stream%partial_state_signature(12), &
      & exchange_hash_integer1(mol%id))
   stream%partial_state_signature(12) = exchange_hash_mix( &
      & stream%partial_state_signature(12), &
      & exchange_hash_integer1(periodic_integer))
   stream%partial_state_signature(12) = exchange_hash_mix( &
      & stream%partial_state_signature(12), &
      & exchange_hash_real1(stream%twist))
end subroutine initialize_partial_state_signature


!> Build the immutable public descriptor for the current stream generation.
subroutine get_partial_descriptor(stream, phase, descriptor)
   type(cp2k_exchange_stream_type), intent(in) :: stream
   integer, intent(in) :: phase
   type(cp2k_exchange_partial_descriptor_type), intent(out) :: descriptor

   descriptor%abi_version = cp2k_exchange_partial_abi_version
   descriptor%scalar_bits = storage_size(0.0_wp)
   descriptor%phase = phase
   descriptor%generation = stream%partial_generation
   descriptor%transaction_id = stream%partial_transaction_id
   descriptor%nk = stream%nk
   descriptor%nao = stream%nao
   descriptor%nspin = stream%nspin
   descriptor%nsh = stream%nsh
   descriptor%nmesh = stream%nmesh
   descriptor%batch_first = stream%batch_first
   descriptor%batch_count = stream%batch_count
   descriptor%batch_capacity = stream%batch_size
   descriptor%image_first = stream%image_first
   descriptor%image_last = stream%batch_last
   descriptor%state_signature = stream%partial_state_signature
end subroutine get_partial_descriptor


!> Return two independent storage-bit digests for buffer/descriptor binding.
pure function partial_descriptor_signature(descriptor) result(signature)
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: descriptor
   integer(int64) :: signature(2)
   integer :: ii

   signature(1) = int(descriptor%abi_version, int64)
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%scalar_bits, int64))
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%phase, int64))
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%generation, int64))
   do ii = 1, size(descriptor%transaction_id)
      signature(1) = exchange_hash_mix(signature(1), &
         & descriptor%transaction_id(ii))
   end do
   signature(1) = exchange_hash_mix(signature(1), int(descriptor%nk, int64))
   signature(1) = exchange_hash_mix(signature(1), int(descriptor%nao, int64))
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%nspin, int64))
   signature(1) = exchange_hash_mix(signature(1), int(descriptor%nsh, int64))
   do ii = 1, 3
      signature(1) = exchange_hash_mix(signature(1), &
         & int(descriptor%nmesh(ii), int64))
   end do
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%batch_first, int64))
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%batch_count, int64))
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%batch_capacity, int64))
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%image_first, int64))
   signature(1) = exchange_hash_mix(signature(1), &
      & int(descriptor%image_last, int64))
   signature(2) = not(signature(1))
   do ii = 1, size(descriptor%state_signature)
      signature(1) = exchange_hash_mix(signature(1), &
         & descriptor%state_signature(ii))
      signature(2) = exchange_hash_mix(signature(2), &
         & ishftc(descriptor%state_signature(ii), 17))
   end do
end function partial_descriptor_signature


!> Compare every descriptor field rather than relying only on its digest.
pure logical function cp2k_exchange_partial_descriptors_match(left, right) &
   & result(matches)
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: left, right

   matches = left%abi_version == right%abi_version &
      & .and. left%scalar_bits == right%scalar_bits &
      & .and. left%phase == right%phase &
      & .and. left%generation == right%generation &
      & .and. all(left%transaction_id == right%transaction_id) &
      & .and. left%nk == right%nk &
      & .and. left%nao == right%nao &
      & .and. left%nspin == right%nspin &
      & .and. left%nsh == right%nsh &
      & .and. all(left%nmesh == right%nmesh) &
      & .and. left%batch_first == right%batch_first &
      & .and. left%batch_count == right%batch_count &
      & .and. left%batch_capacity == right%batch_capacity &
      & .and. left%image_first == right%image_first &
      & .and. left%image_last == right%image_last &
      & .and. all(left%state_signature == right%state_signature)
end function cp2k_exchange_partial_descriptors_match


!> Multiply nonnegative factors without exceeding a caller-supplied limit.
pure subroutine checked_partial_product(factors, limit, value, ok)
   integer(int64), intent(in) :: factors(:), limit
   integer(int64), intent(out) :: value
   logical, intent(out) :: ok

   integer :: ii

   ok = .false.
   value = 0_int64
   if (limit < 0_int64 .or. any(factors < 0_int64)) return
   value = 1_int64
   do ii = 1, size(factors)
      if (factors(ii) == 0_int64) then
         value = 0_int64
         ok = .true.
         return
      end if
      if (value > limit/factors(ii)) then
         value = 0_int64
         return
      end if
      value = value*factors(ii)
   end do
   ok = .true.
end subroutine checked_partial_product


!> Return forward block/total extents that fit default-integer indexing.
pure subroutine partial_forward_extents(nao, batch_count, nspin, nblock, total, &
   & ok)
   integer, intent(in) :: nao, batch_count, nspin
   integer(int64), intent(out) :: nblock, total
   logical, intent(out) :: ok

   integer(int64), parameter :: index_limit = int(huge(0), int64)

   call checked_partial_product([int(nao, int64), int(nao, int64), &
      & int(batch_count, int64), int(nspin, int64)], index_limit, nblock, ok)
   total = 0_int64
   if (.not.ok) return
   if (nblock > index_limit/4_int64) then
      ok = .false.
      return
   end if
   total = 4_int64*nblock
end subroutine partial_forward_extents


!> Return reverse block/onsite/total extents within default-integer indexing.
pure subroutine partial_reverse_extents(nao, batch_count, nspin, nblock, &
   & nonsite, total, ok)
   integer, intent(in) :: nao, batch_count, nspin
   integer(int64), intent(out) :: nblock, nonsite, total
   logical, intent(out) :: ok

   integer(int64), parameter :: index_limit = int(huge(0), int64)
   integer(int64) :: block_total, onsite_total

   call checked_partial_product([int(nao, int64), int(nao, int64), &
      & int(batch_count, int64), int(nspin, int64)], index_limit, nblock, ok)
   nonsite = 0_int64
   total = 0_int64
   if (.not.ok) return
   call checked_partial_product([int(nao, int64), int(nspin, int64)], &
      & index_limit, nonsite, ok)
   if (.not.ok) return
   if (nblock > index_limit/6_int64 &
      & .or. nonsite > index_limit/5_int64) then
      ok = .false.
      return
   end if
   block_total = 6_int64*nblock
   onsite_total = 5_int64*nonsite
   if (block_total > index_limit-onsite_total) then
      ok = .false.
      return
   end if
   total = block_total+onsite_total
end subroutine partial_reverse_extents


!> Validate all structural invariants of a canonical partial descriptor.
pure logical function partial_descriptor_is_valid(descriptor) result(valid)
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: descriptor

   integer(int64) :: mesh_size
   logical :: product_ok

   valid = .false.
   if (descriptor%abi_version /= cp2k_exchange_partial_abi_version) return
   if (descriptor%scalar_bits /= storage_size(0.0_wp)) return
   if (descriptor%phase /= 1 .and. descriptor%phase /= 2) return
   if (descriptor%generation < 1) return
   if (all(descriptor%transaction_id == 0_int64)) return
   if (descriptor%nk < 1 .or. descriptor%nao < 1 &
      & .or. descriptor%nspin < 1 .or. descriptor%nsh < 1) return
   if (any(descriptor%nmesh < 1)) return
   call checked_partial_product(int(descriptor%nmesh, int64), &
      & int(descriptor%nk, int64), mesh_size, product_ok)
   if (.not.product_ok) return
   if (mesh_size /= int(descriptor%nk, int64)) return
   if (descriptor%image_first < 1 &
      & .or. descriptor%image_last > descriptor%nk &
      & .or. descriptor%image_first > descriptor%image_last) return
   if (descriptor%batch_capacity < 1 &
      & .or. descriptor%batch_first < descriptor%image_first &
      & .or. descriptor%batch_first > descriptor%image_last) return
   if (descriptor%batch_count /= min(descriptor%batch_capacity, &
      & descriptor%image_last-descriptor%batch_first+1)) return
   valid = .true.
end function partial_descriptor_is_valid


!> Number of int64 words in the portable canonical descriptor encoding.
integer(int64) function cp2k_exchange_partial_descriptor_size() &
   & result(nwords)
   nwords = int(cp2k_exchange_partial_descriptor_words, int64)
end function cp2k_exchange_partial_descriptor_size


!> Pack a descriptor into a portable, padding-free int64 representation.
!>
!> CP2K can allgather these words, unpack every rank's descriptor, and compare
!> every field with `cp2k_exchange_partial_descriptors_match`.  The internal
!> two-word payload digest is never sufficient for accepting a collective.
subroutine cp2k_exchange_partial_descriptor_pack(descriptor, values, error)
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: descriptor
   integer(int64), allocatable, intent(out) :: values(:)
   type(error_type), allocatable, intent(out) :: error

   if (.not.partial_descriptor_is_valid(descriptor)) then
      call fatal_error(error, "invalid g-xTB exchange partial descriptor")
      return
   end if
   allocate(values(cp2k_exchange_partial_descriptor_words), source=0_int64)
   values(1) = int(descriptor%abi_version, int64)
   values(2) = int(descriptor%scalar_bits, int64)
   values(3) = int(descriptor%phase, int64)
   values(4) = int(descriptor%generation, int64)
   values(5:6) = descriptor%transaction_id
   values(7) = int(descriptor%nk, int64)
   values(8) = int(descriptor%nao, int64)
   values(9) = int(descriptor%nspin, int64)
   values(10) = int(descriptor%nsh, int64)
   values(11:13) = int(descriptor%nmesh, int64)
   values(14) = int(descriptor%batch_first, int64)
   values(15) = int(descriptor%batch_count, int64)
   values(16) = int(descriptor%batch_capacity, int64)
   values(17) = int(descriptor%image_first, int64)
   values(18) = int(descriptor%image_last, int64)
   values(19:30) = descriptor%state_signature
end subroutine cp2k_exchange_partial_descriptor_pack


!> Unpack and structurally validate a portable canonical descriptor.
subroutine cp2k_exchange_partial_descriptor_unpack(descriptor, values, error)
   type(cp2k_exchange_partial_descriptor_type), intent(out) :: descriptor
   integer(int64), intent(in) :: values(:)
   type(error_type), allocatable, intent(out) :: error

   integer :: ii
   integer(int64), parameter :: default_max = int(huge(0), int64)

   if (size(values) /= cp2k_exchange_partial_descriptor_words) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange partial descriptor size")
      return
   end if
   do ii = 1, 18
      if (ii == 5 .or. ii == 6) cycle
      if (values(ii) > default_max .or. values(ii) < -default_max) then
         call fatal_error(error, &
            & "out-of-range g-xTB exchange partial descriptor field")
         return
      end if
   end do
   descriptor%abi_version = int(values(1))
   descriptor%scalar_bits = int(values(2))
   descriptor%phase = int(values(3))
   descriptor%generation = int(values(4))
   descriptor%transaction_id = values(5:6)
   descriptor%nk = int(values(7))
   descriptor%nao = int(values(8))
   descriptor%nspin = int(values(9))
   descriptor%nsh = int(values(10))
   descriptor%nmesh = int(values(11:13))
   descriptor%batch_first = int(values(14))
   descriptor%batch_count = int(values(15))
   descriptor%batch_capacity = int(values(16))
   descriptor%image_first = int(values(17))
   descriptor%image_last = int(values(18))
   descriptor%state_signature = values(19:30)
   if (.not.partial_descriptor_is_valid(descriptor)) then
      call fatal_error(error, "invalid g-xTB exchange partial descriptor")
      return
   end if
end subroutine cp2k_exchange_partial_descriptor_unpack


!> Reconstruct and Hermitize one Fock contribution from response images.
!>
!> The same projection/scaling kernel serves both a complete reduced image
!> mesh and one additive bounded batch.  `add_onsite` is true exactly for the
!> complete mesh or for the unique batch containing the origin image.
subroutine reconstruct_stream_fock_block(overlap, phase_forward, add_onsite, &
   & amat_r, cmat_r, vmat_r, gdiagP, gdiagSP, gdiagSPS, fock)
   complex(wp), intent(in) :: overlap(:, :), phase_forward(:)
   logical, intent(in) :: add_onsite
   complex(wp), intent(in) :: amat_r(:, :, :, :), cmat_r(:, :, :, :), &
      & vmat_r(:, :, :, :), gdiagP(:, :), gdiagSP(:, :), gdiagSPS(:, :)
   complex(wp), intent(out) :: fock(:, :, :)

   integer :: iao, icell, ii, jj, spin
   real(wp) :: spin_factor
   complex(wp) :: tmp
   complex(wp), allocatable :: amat(:, :), cmat(:, :), vmat(:, :), work(:, :)

   allocate(amat(size(overlap, 1), size(overlap, 2)), &
      & cmat(size(overlap, 1), size(overlap, 2)), &
      & vmat(size(overlap, 1), size(overlap, 2)), &
      & work(size(overlap, 1), size(overlap, 2)))
   spin_factor = 0.5_wp
   if (size(fock, 3) > 1) spin_factor = 1.0_wp
   do spin = 1, size(fock, 3)
      amat = (0.0_wp, 0.0_wp)
      cmat = (0.0_wp, 0.0_wp)
      vmat = (0.0_wp, 0.0_wp)
      do icell = 1, size(phase_forward)
         amat = amat + phase_forward(icell)*amat_r(:, :, icell, spin)
         cmat = cmat + phase_forward(icell)*cmat_r(:, :, icell, spin)
         vmat = vmat + phase_forward(icell)*vmat_r(:, :, icell, spin)
      end do
      work = amat + 0.5_wp*matmul(overlap, vmat)
      if (add_onsite) then
         do iao = 1, size(overlap, 1)
            work(:, iao) = work(:, iao) &
               & +0.25_wp*gdiagP(iao, spin)*overlap(:, iao)
         end do
      end if
      fock(:, :, spin) = cmat + matmul(work, overlap)
      if (add_onsite) then
         do iao = 1, size(overlap, 1)
            fock(:, iao, spin) = fock(:, iao, spin) &
               & +0.5_wp*gdiagSP(iao, spin)*overlap(:, iao)
            fock(iao, iao, spin) = fock(iao, iao, spin) &
               & +0.25_wp*gdiagSPS(iao, spin)
         end do
      end if
      do ii = 1, size(overlap, 1)
         fock(ii, ii, spin) = cmplx(-0.5_wp*spin_factor &
            & *real(fock(ii, ii, spin), wp), 0.0_wp, wp)
         do jj = 1, ii-1
            tmp = -0.25_wp*spin_factor*(fock(jj, ii, spin) &
               & +conjg(fock(ii, jj, spin)))
            fock(jj, ii, spin) = tmp
            fock(ii, jj, spin) = conjg(tmp)
         end do
      end do
   end do
end subroutine reconstruct_stream_fock_block


!> Check the exact charge-dependent onsite state captured by `begin`.
logical function exchange_stream_onsite_matches(stream, cache) result(matches)
   type(cp2k_exchange_stream_type), intent(in) :: stream
   type(exchange_cache), intent(in) :: cache

   matches = .false.
   if (.not.allocated(stream%g_onsfx) &
      & .or. .not.allocated(stream%g_onsri) &
      & .or. .not.allocated(stream%dgdq_onsfx) &
      & .or. .not.allocated(stream%dgdq_onsri) &
      & .or. .not.allocated(cache%g_onsfx) &
      & .or. .not.allocated(cache%g_onsri) &
      & .or. .not.allocated(cache%dgdq_onsfx) &
      & .or. .not.allocated(cache%dgdq_onsri)) return
   if (any(shape(stream%g_onsfx) /= shape(cache%g_onsfx)) &
      & .or. any(shape(stream%g_onsri) /= shape(cache%g_onsri)) &
      & .or. any(shape(stream%dgdq_onsfx) /= shape(cache%dgdq_onsfx)) &
      & .or. any(shape(stream%dgdq_onsri) /= shape(cache%dgdq_onsri))) return
   if (any(stream%g_onsfx /= cache%g_onsfx) &
      & .or. any(stream%g_onsri /= cache%g_onsri) &
      & .or. any(stream%dgdq_onsfx /= cache%dgdq_onsfx) &
      & .or. any(stream%dgdq_onsri /= cache%dgdq_onsri)) return
   matches = .true.
end function exchange_stream_onsite_matches


!> Validate the exact geometry, plan generation, model, and onsite snapshot.
logical function exchange_stream_state_matches(stream, calc, mol, ecache) &
   & result(matches)
   type(cp2k_exchange_stream_type), intent(in) :: stream
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(in) :: ecache

   matches = .false.
   if (.not.allocated(calc%exchange) .or. .not.allocated(ecache%raw)) return
   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         if (exchange%nao /= stream%nao .or. exchange%nsh /= stream%nsh) return
         if (cache%bvk_plan_builds /= stream%plan_builds) return
         if (.not.cache%bvk_matches(mol, stream%nmesh, stream%kfrac, &
            & stream%weights, require_phases= &
            & stream%mode /= cp2k_exchange_stream_batched)) return
         if (.not.exchange%bvk_model_matches(cache)) return
         if (.not.exchange_stream_onsite_matches(stream, cache)) return
         if (.not.allocated(stream%input_to_grid) &
            & .or. .not.allocated(cache%bvk_input_to_grid)) return
         if (size(stream%input_to_grid) /= &
            & size(cache%bvk_input_to_grid)) return
         if (any(stream%input_to_grid /= cache%bvk_input_to_grid)) return
         if (any(stream%twist /= cache%bvk_twist)) return
         if (any(shape(stream%reps) /= shape(cache%bvk_kernel%reps))) return
         if (any(stream%reps /= cache%bvk_kernel%reps)) return
         if (stream%kernel_signature(1) /= &
            & exchange_hash_real3(cache%bvk_kernel%g_mulliken_r)) return
         if (stream%kernel_signature(2) /= ieor( &
            & exchange_hash_real3(cache%bvk_kernel%g_bocorr_r), &
            & exchange_hash_integer2(cache%bvk_kernel%reps))) return
         if (stream%mode /= cp2k_exchange_stream_batched) then
            if (stream%phase_signature(1) /= &
               & exchange_hash_complex2(cache%bvk_phase_forward)) return
            if (stream%phase_signature(2) /= &
               & exchange_hash_complex2(cache%bvk_phase_inverse)) return
         else
            if (.not.allocated(cache%bvk_phase_roots) &
               & .or. .not.allocated(cache%bvk_twist_phase)) return
            if (stream%compact_phase_signature(1) /= &
               & exchange_hash_complex2(cache%bvk_phase_roots)) return
            if (stream%compact_phase_signature(2) /= &
               & exchange_hash_complex1(cache%bvk_twist_phase)) return
         end if
         matches = .true.
      end select
   end select
end function exchange_stream_state_matches


!> Begin collecting the unweighted Bloch blocks of one complete regular mesh.
!>
!> Only one transaction may be active in a stream object.  The expensive BvK
!> plan is prepared here, before blocks are accepted, so that `apply` can also
!> detect an intervening geometry, mesh, or model change.  The optional mode
!> selects the image-mesh reduced path, the full-mesh oracle, or the strictly
!> sequential bounded image-batch path; reduced mode is the default.  Batched
!> mode additionally requires a positive `batch_size`.  Its mandatory caller
!> sequence is `batch_bounds`, one `push` for every k point, `batch_apply`, one
!> `batch_pull` for every k point, and `batch_advance`; repeat until `done`,
!> then obtain exactly one `batch_result` and call `end`.  The caller owns and
!> zeroes the final Fock accumulators before the first batch.  The optional
!> `image_first,image_count` pair restricts a batched transaction to one
!> additive, contiguous image range.  Disjoint ranges may therefore be
!> evaluated concurrently by independent stream objects or MPI ranks and their
!> energy, shell potential, and Fock contributions summed by the caller.  A
!> complete result requires an exact, nonoverlapping cover of images 1..Nk.
!> Choosing `batch_size >= image_count` gives one K-block submission per
!> independent range.  A serial range larger than its bounded batch must still
!> resubmit K blocks: without retaining a full Bloch/image AO mesh, released
!> input information cannot contribute to a later image sum.
!> `reverse_only=.true.` starts a derivative-only transaction in reduced or
!> batched mode.  It deliberately skips the forward Fock/result protocol; the
!> caller immediately enters `reverse_push`/`reverse_batch_apply`/blockwise
!> `reverse_batch_pull`.  This is the preferred force/stress path when the SCF
!> Fock matrix has already been built elsewhere.  No concurrent use of one
!> stream object is supported.
subroutine cp2k_exchange_stream_begin(stream, calc, mol, ecache, wfn, nmesh, &
   & kfrac, weights, error, mode, batch_size, image_first, image_count, &
   & reverse_only)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   type(wavefunction_type), intent(in) :: wfn
   integer, intent(in) :: nmesh(3)
   real(wp), intent(in) :: kfrac(:, :), weights(:)
   type(error_type), allocatable, intent(out) :: error
   integer, intent(in), optional :: mode
   integer, intent(in), optional :: batch_size
   integer, intent(in), optional :: image_first, image_count
   logical, intent(in), optional :: reverse_only

   integer :: grid(3), inverse_grid(3), icell, idim, igrid, ik_oracle, &
      & inverse_cell, nk, selected_batch_size, selected_image_count, &
      & selected_image_first, selected_image_last, selected_mode
   integer, allocatable :: rep_to_cell(:)
   real(wp) :: canonical, periodic_delta
   logical :: selected_reverse_only

   if (stream%active) then
      call fatal_error(error, "g-xTB exchange stream is already active")
      return
   end if

   selected_mode = cp2k_exchange_stream_reduced
   if (present(mode)) selected_mode = mode
   selected_reverse_only = .false.
   if (present(reverse_only)) selected_reverse_only = reverse_only
   if (selected_mode /= cp2k_exchange_stream_reduced &
      & .and. selected_mode /= cp2k_exchange_stream_oracle &
      & .and. selected_mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, "unknown g-xTB exchange stream mode")
      return
   end if
   if (selected_reverse_only .and. &
      & selected_mode == cp2k_exchange_stream_oracle) then
      call fatal_error(error, &
         & "reverse-only g-xTB exchange requires reduced or batched mode")
      return
   end if
   selected_batch_size = 0
   if (selected_mode == cp2k_exchange_stream_batched) then
      if (.not.present(batch_size)) then
         call fatal_error(error, &
            & "batched g-xTB exchange stream requires a batch size")
         return
      end if
      if (batch_size < 1) then
         call fatal_error(error, &
            & "g-xTB exchange stream batch size must be positive")
         return
      end if
      selected_batch_size = batch_size
   else if (present(batch_size)) then
      call fatal_error(error, &
         & "g-xTB exchange stream batch size requires batched mode")
      return
   end if

   nk = size(weights)
   selected_image_first = 1
   selected_image_count = nk
   selected_image_last = nk
   if (selected_mode == cp2k_exchange_stream_batched) then
      if (present(image_first) .neqv. present(image_count)) then
         call fatal_error(error, &
            & "g-xTB exchange image range requires first and count")
         return
      end if
      if (present(image_first)) then
         if (image_first < 1 .or. image_count < 1 &
            & .or. image_first > nk &
            & .or. image_count > nk-image_first+1) then
            call fatal_error(error, "g-xTB exchange image range is invalid")
            return
         end if
         selected_image_first = image_first
         selected_image_count = image_count
         selected_image_last = image_first+image_count-1
      end if
   else if (present(image_first) .or. present(image_count)) then
      call fatal_error(error, &
         & "g-xTB exchange image range requires batched mode")
      return
   end if
   if (any(nmesh < 1) .or. product(nmesh) /= nk) then
      call fatal_error(error, &
         & "g-xTB exchange stream requires a complete regular k mesh")
      return
   end if
   do idim = 1, 3
      if (.not.mol%periodic(idim) .and. nmesh(idim) /= 1) then
         call fatal_error(error, &
            & "nonperiodic directions cannot be replicated by the g-xTB k mesh")
         return
      end if
   end do
   if (size(kfrac, 1) /= 3 .or. size(kfrac, 2) /= nk) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream mesh dimensions")
      return
   end if
   if (.not.all(ieee_is_finite(kfrac))) then
      call fatal_error(error, "g-xTB exchange stream k points must be finite")
      return
   end if
   if (.not.all(ieee_is_finite(weights)) .or. &
      & abs(sum(weights)-1.0_wp) > 1.0e-12_wp &
      & .or. maxval(abs(weights-1.0_wp/real(nk, wp))) > 1.0e-12_wp) then
      call fatal_error(error, &
         & "g-xTB exchange stream requires uniform k-point weights")
      return
   end if

   call cp2k_prepare_exchange(calc, mol, ecache, wfn, error)
   if (allocated(error)) return
   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         if (wfn%nspin /= 1 .and. wfn%nspin /= 2) then
            call fatal_error(error, &
               & "g-xTB exchange stream requires one or two spin channels")
            return
         end if
         call prepare_bvk_plan(exchange, mol, cache, nmesh, kfrac, weights, &
            & error, retain_dense_phases= &
            & selected_mode /= cp2k_exchange_stream_batched)
         if (allocated(error)) return
         if (selected_mode == cp2k_exchange_stream_batched) then
            ! The inverse-image energy collapse is exact only for characters
            ! of a uniform finite Fourier group.  The general plan accepts a
            ! looser geometric tolerance, but bounded batching deliberately
            ! rejects anything beyond roundoff instead of silently dropping
            ! small off-pair Gram coefficients.
            if (maxval(abs(weights-1.0_wp/real(nk, wp))) > &
               & 64.0_wp*epsilon(1.0_wp)) then
               call fatal_error(error, &
                  & "batched g-xTB exchange requires machine-uniform weights")
               return
            end if
            do ik_oracle = 1, nk
               igrid = cache%bvk_input_to_grid(ik_oracle)-1
               grid(1) = modulo(igrid, nmesh(1))
               grid(2) = modulo(igrid/nmesh(1), nmesh(2))
               grid(3) = igrid/(nmesh(1)*nmesh(2))
               do idim = 1, 3
                  canonical = cache%bvk_twist(idim) &
                     & +real(grid(idim), wp)/real(nmesh(idim), wp)
                  periodic_delta = modulo(kfrac(idim, ik_oracle), 1.0_wp) &
                     & -modulo(canonical, 1.0_wp)
                  periodic_delta = periodic_delta-nint(periodic_delta)
                  if (abs(periodic_delta) > &
                     & 64.0_wp*epsilon(1.0_wp)) then
                     call fatal_error(error, &
                        & "batched g-xTB exchange requires a machine-regular grid")
                     return
                  end if
               end do
            end do
         end if
         if (.not.allocated(cache%g_onsfx) &
            & .or. .not.allocated(cache%g_onsri) &
            & .or. .not.allocated(cache%dgdq_onsfx) &
            & .or. .not.allocated(cache%dgdq_onsri)) then
            call fatal_error(error, &
               & "g-xTB exchange stream onsite state is not prepared")
            return
         end if

         call clear_exchange_stream(stream)
         stream%nk = nk
         stream%nao = exchange%nao
         stream%nspin = wfn%nspin
         stream%nsh = exchange%nsh
         stream%mode = selected_mode
         stream%reverse_only = selected_reverse_only
         stream%plan_builds = cache%bvk_plan_builds
         stream%nmesh = nmesh
         allocate(stream%seen(nk), source=.false.)
         allocate(stream%forward_pulled(nk), source=.false.)
         allocate(stream%reverse_pulled(nk), source=.false.)
         allocate(stream%batch_pulled(nk), source=.false.)
         allocate(stream%reps, source=cache%bvk_kernel%reps)
         allocate(stream%input_to_grid, source=cache%bvk_input_to_grid)
         allocate(stream%kfrac(3, nk), source=kfrac)
         allocate(stream%weights(nk), source=weights)
         stream%twist = cache%bvk_twist
         stream%kernel_signature(1) = &
            & exchange_hash_real3(cache%bvk_kernel%g_mulliken_r)
         stream%kernel_signature(2) = ieor( &
            & exchange_hash_real3(cache%bvk_kernel%g_bocorr_r), &
            & exchange_hash_integer2(cache%bvk_kernel%reps))
         if (selected_mode /= cp2k_exchange_stream_batched) then
            stream%phase_signature(1) = &
               & exchange_hash_complex2(cache%bvk_phase_forward)
            stream%phase_signature(2) = &
               & exchange_hash_complex2(cache%bvk_phase_inverse)
         else
            allocate(stream%phase_roots, source=cache%bvk_phase_roots)
            allocate(stream%twist_phase, source=cache%bvk_twist_phase)
            stream%compact_phase_signature(1) = &
               & exchange_hash_complex2(cache%bvk_phase_roots)
            stream%compact_phase_signature(2) = &
               & exchange_hash_complex1(cache%bvk_twist_phase)
         end if
         allocate(stream%g_onsfx, source=cache%g_onsfx)
         allocate(stream%g_onsri, source=cache%g_onsri)
         allocate(stream%dgdq_onsfx, source=cache%dgdq_onsfx)
         allocate(stream%dgdq_onsri, source=cache%dgdq_onsri)
         if (selected_mode == cp2k_exchange_stream_oracle) then
            allocate(stream%density(exchange%nao, exchange%nao, wfn%nspin, nk), &
               & stream%overlap(exchange%nao, exchange%nao, nk), &
               & stream%fock(exchange%nao, exchange%nao, wfn%nspin, nk), &
               & source=(0.0_wp, 0.0_wp))
            allocate(stream%overlap_adjoint(exchange%nao, exchange%nao, nk), &
               & source=(0.0_wp, 0.0_wp))
         else if (selected_mode == cp2k_exchange_stream_reduced) then
            allocate(stream%amat_r(exchange%nao, exchange%nao, nk, wfn%nspin), &
               & stream%cmat_r(exchange%nao, exchange%nao, nk, wfn%nspin), &
               & stream%vmat_r(exchange%nao, exchange%nao, nk, wfn%nspin), &
               & source=(0.0_wp, 0.0_wp))
            allocate(stream%gdiagP(exchange%nao, wfn%nspin), &
               & stream%gdiagSP(exchange%nao, wfn%nspin), &
               & stream%gdiagSPS(exchange%nao, wfn%nspin), &
               & source=(0.0_wp, 0.0_wp))
         else
            stream%batch_size = min(selected_batch_size, selected_image_count)
            stream%batch_first = selected_image_first
            stream%batch_count = min(stream%batch_size, selected_image_count)
            stream%batch_last = selected_image_last
            stream%image_first = selected_image_first
            allocate(stream%inverse_image(nk), source=0)
            allocate(stream%inverse_coeff(nk), &
               & source=(0.0_wp, 0.0_wp))
            allocate(stream%density_signature(nk), source=0_int64)
            allocate(stream%overlap_signature(nk), source=0_int64)
            allocate(stream%block_signature_set(nk), source=.false.)
            allocate(rep_to_cell(nk), source=0)
            do icell = 1, nk
               grid = modulo(stream%reps(:, icell), nmesh)
               if (any(grid /= stream%reps(:, icell))) then
                  call clear_exchange_stream(stream)
                  call fatal_error(error, &
                     & "g-xTB image batch has a noncanonical representative")
                  return
               end if
               igrid = 1 + grid(1) &
                  & +nmesh(1)*(grid(2)+nmesh(2)*grid(3))
               if (rep_to_cell(igrid) /= 0) then
                  call clear_exchange_stream(stream)
                  call fatal_error(error, &
                     & "g-xTB image batch has duplicate representatives")
                  return
               end if
               rep_to_cell(igrid) = icell
            end do
            if (any(rep_to_cell == 0)) then
               call clear_exchange_stream(stream)
               call fatal_error(error, &
                  & "g-xTB image batch has missing representatives")
               return
            end if
            do icell = 1, nk
               inverse_grid = modulo(-stream%reps(:, icell), nmesh)
               igrid = 1 + inverse_grid(1) &
                  & +nmesh(1)*(inverse_grid(2)+nmesh(2)*inverse_grid(3))
               inverse_cell = rep_to_cell(igrid)
               stream%inverse_image(icell) = inverse_cell
               ! The grid character of R+(-R mod n) is unity for every k.
               ! Only the supplied weight sum and cached twist character
               ! remain in this exact inverse-image contraction coefficient.
               stream%inverse_coeff(icell) = sum(weights)*conjg( &
                  & stream%twist_phase(icell) &
                  & *stream%twist_phase(inverse_cell))
            end do
            allocate(stream%amat_r(exchange%nao, exchange%nao, &
               & stream%batch_size, wfn%nspin), &
               & stream%amat_partner_r(exchange%nao, exchange%nao, &
               & stream%batch_size, wfn%nspin), &
               & stream%cmat_r(exchange%nao, exchange%nao, &
               & stream%batch_size, wfn%nspin), &
               & stream%vmat_r(exchange%nao, exchange%nao, &
               & stream%batch_size, wfn%nspin), &
               & source=(0.0_wp, 0.0_wp))
            allocate(stream%gdiagP(exchange%nao, wfn%nspin), &
               & stream%gdiagSP(exchange%nao, wfn%nspin), &
               & stream%gdiagSPS(exchange%nao, wfn%nspin), &
               & source=(0.0_wp, 0.0_wp))
         end if
         allocate(stream%vsh(exchange%nsh), source=0.0_wp)
         stream%energy = 0.0_wp
         stream%peak_complex_elements = &
            & exchange_stream_complex_elements(stream)
         if (selected_mode == cp2k_exchange_stream_batched) then
            stream%peak_complex_elements = max( &
               & stream%peak_complex_elements &
               & +2_int64*int(exchange%nao, int64)**2, &
               & stream%peak_complex_elements &
               & +5_int64*int(exchange%nao, int64)**2 &
               & +6_int64*int(exchange%nao, int64), &
               & stream%peak_complex_elements &
               & +int(exchange%nao, int64)**2*int(wfn%nspin, int64) &
               & +4_int64*int(exchange%nao, int64)**2 &
               & +int(stream%batch_size, int64))
         end if
         stream%active = .true.
         if (selected_reverse_only) then
            stream%applied = .true.
            stream%forward_pulled = .true.
            stream%batch_result_pulled = .true.
            call initialize_exchange_stream_reverse(stream, mol, error)
            if (allocated(error)) then
               call clear_exchange_stream(stream)
               return
            end if
         end if
      class default
         call fatal_error(error, &
            & "exchange stream requires the exchange_fock implementation")
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
   end select
end subroutine cp2k_exchange_stream_begin


!> Start one MPI-free partial k-to-R accumulator transaction.
!>
!> The object is an ordinary bounded exchange stream and can therefore enter
!> the unchanged batch apply/pull protocol after a successful import.  Partial
!> contributors may be empty; global ownership is proved only at import.
!> `transaction_id` is a mandatory host-generated 128-bit identity.  CP2K
!> must create a fresh nonzero value for every logical exchange transaction
!> and broadcast the same value to all contributors; reuse would void stale-
!> payload protection and is therefore forbidden by the public host contract.
subroutine cp2k_exchange_partial_begin(stream, calc, mol, ecache, wfn, nmesh, &
   & kfrac, weights, batch_size, transaction_id, error, image_first, &
   & image_count, reverse_only)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   type(wavefunction_type), intent(in) :: wfn
   integer, intent(in) :: nmesh(3), batch_size
   integer(int64), intent(in) :: transaction_id(2)
   real(wp), intent(in) :: kfrac(:, :), weights(:)
   type(error_type), allocatable, intent(out) :: error
   integer, intent(in), optional :: image_first, image_count
   logical, intent(in), optional :: reverse_only

   if (all(transaction_id == 0_int64)) then
      call fatal_error(error, &
         & "partial exchange requires a nonzero host transaction identity")
      return
   end if

   call cp2k_exchange_stream_begin(stream, calc, mol, ecache, wfn, nmesh, &
      & kfrac, weights, error, mode=cp2k_exchange_stream_batched, &
      & batch_size=batch_size, image_first=image_first, &
      & image_count=image_count, reverse_only=reverse_only)
   if (allocated(error)) return
   stream%partial_active = .true.
   stream%partial_generation = 1
   stream%partial_transaction_id = transaction_id
   call initialize_partial_state_signature(stream, mol)
end subroutine cp2k_exchange_partial_begin


!> Add one uniquely owned Bloch block to a forward partial accumulator.
subroutine cp2k_exchange_partial_push(stream, ik, density, overlap, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(in) :: density(:, :, :), overlap(:, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active .or. .not.stream%partial_active) then
      call fatal_error(error, "g-xTB exchange partial stream is not active")
      return
   end if
   if (stream%reverse_only) then
      call fatal_error(error, &
         & "forward partial push is invalid in a reverse-only transaction")
      return
   end if
   if (stream%partial_forward_imported) then
      call fatal_error(error, "g-xTB exchange partial push followed import")
      return
   end if
   if (stream%partial_forward_exported) then
      call fatal_error(error, "g-xTB exchange partial push followed export")
      return
   end if
   call cp2k_exchange_stream_push(stream, ik, density, overlap, error)
end subroutine cp2k_exchange_partial_push


!> Export one additive forward payload and its local ownership vector.
subroutine cp2k_exchange_partial_export_forward(stream, descriptor, &
   & owner_count, buffer, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(cp2k_exchange_partial_descriptor_type), intent(out) :: descriptor
   integer, allocatable, intent(out) :: owner_count(:)
   type(cp2k_exchange_partial_forward_type), intent(out) :: buffer
   type(error_type), allocatable, intent(out) :: error

   integer :: nblock_default, total_default
   integer(int64) :: first, last, nblock, total
   logical :: extents_ok

   if (.not.stream%active .or. .not.stream%partial_active) then
      call fatal_error(error, "g-xTB exchange partial stream is not active")
      return
   end if
   if (stream%reverse_only) then
      call fatal_error(error, &
         & "forward partial export is invalid in a reverse-only transaction")
      return
   end if
   if (stream%partial_forward_imported) then
      call fatal_error(error, "g-xTB exchange forward payload was imported")
      return
   end if
   if (stream%partial_forward_exported) then
      call fatal_error(error, "g-xTB exchange forward payload was exported")
      return
   end if
   if (stream%applied .or. stream%batch_applied) then
      call fatal_error(error, &
         & "g-xTB exchange forward payload export followed kernel apply")
      return
   end if

   call get_partial_descriptor(stream, 1, descriptor)
   allocate(owner_count(stream%nk), source=0)
   where (stream%seen)
      owner_count = 1
   end where
   call partial_forward_extents(stream%nao, stream%batch_count, stream%nspin, &
      & nblock, total, extents_ok)
   if (.not.extents_ok) then
      call fatal_error(error, &
         & "g-xTB exchange forward payload exceeds indexing limit")
      return
   end if
   nblock_default = int(nblock)
   total_default = int(total)
   allocate(buffer%values(total_default))
   first = 1_int64
   last = nblock
   buffer%values(first:last) = reshape( &
      & stream%amat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%amat_partner_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%cmat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%vmat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   if (.not.all(ieee_is_finite(real(buffer%values, wp))) &
      & .or. .not.all(ieee_is_finite(aimag(buffer%values)))) then
      call fatal_error(error, "non-finite g-xTB exchange forward payload")
      return
   end if
   buffer%abi_version = cp2k_exchange_partial_abi_version
   buffer%descriptor_signature = partial_descriptor_signature(descriptor)
   stream%partial_forward_exported = .true.
end subroutine cp2k_exchange_partial_export_forward


!> Number of complex scalars in an exported forward payload.
!>
!> Construction fails closed before allocation if the count exceeds
!> `huge(default integer)`; a host may still chunk MPI reductions below that
!> provider-side indexing limit.
integer(int64) function cp2k_exchange_partial_forward_size(buffer) &
   & result(nelements)
   type(cp2k_exchange_partial_forward_type), intent(in) :: buffer

   if (buffer%abi_version == cp2k_exchange_partial_abi_version &
      & .and. allocated(buffer%values)) then
      nelements = size(buffer%values, kind=int64)
   else
      nelements = -1_int64
   end if
end function cp2k_exchange_partial_forward_size


!> Copy an opaque forward payload into contiguous host/MPI storage.
subroutine cp2k_exchange_partial_forward_pack(buffer, values, error)
   type(cp2k_exchange_partial_forward_type), intent(in) :: buffer
   complex(wp), allocatable, intent(out) :: values(:)
   type(error_type), allocatable, intent(out) :: error

   if (buffer%abi_version /= cp2k_exchange_partial_abi_version &
      & .or. .not.allocated(buffer%values)) then
      call fatal_error(error, "invalid g-xTB exchange forward payload")
      return
   end if
   allocate(values, source=buffer%values)
end subroutine cp2k_exchange_partial_forward_pack


!> Recreate an opaque forward payload from a host-reduced contiguous buffer.
!>
!> `descriptor` must be the exact collectively validated companion descriptor
!> exported with `values`.  Rebinding saved raw values to a fresh descriptor is
!> forbidden by the host contract.
subroutine cp2k_exchange_partial_forward_unpack(buffer, descriptor, values, &
   & error)
   type(cp2k_exchange_partial_forward_type), intent(out) :: buffer
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: descriptor
   complex(wp), intent(in) :: values(:)
   type(error_type), allocatable, intent(out) :: error

   integer(int64) :: expected, nblock
   logical :: extents_ok

   if (.not.partial_descriptor_is_valid(descriptor) &
      & .or. descriptor%phase /= 1) then
      call fatal_error(error, "inconsistent g-xTB exchange forward descriptor")
      return
   end if
   call partial_forward_extents(descriptor%nao, descriptor%batch_count, &
      & descriptor%nspin, nblock, expected, extents_ok)
   if (.not.extents_ok) then
      call fatal_error(error, &
         & "g-xTB exchange forward payload exceeds indexing limit")
      return
   end if
   if (size(values, kind=int64) /= expected) then
      call fatal_error(error, "inconsistent g-xTB exchange forward payload")
      return
   end if
   if (.not.all(ieee_is_finite(real(values, wp))) &
      & .or. .not.all(ieee_is_finite(aimag(values)))) then
      call fatal_error(error, "non-finite g-xTB exchange forward payload")
      return
   end if
   allocate(buffer%values, source=values)
   buffer%abi_version = cp2k_exchange_partial_abi_version
   buffer%descriptor_signature = partial_descriptor_signature(descriptor)
end subroutine cp2k_exchange_partial_forward_unpack


!> Import the globally summed forward sources before one nonlinear apply.
subroutine cp2k_exchange_partial_import_forward(stream, descriptor, &
   & owner_count, buffer, calc, mol, ecache, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: descriptor
   integer, intent(in) :: owner_count(:)
   type(cp2k_exchange_partial_forward_type), intent(in) :: buffer
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(in) :: ecache
   type(error_type), allocatable, intent(out) :: error

   type(cp2k_exchange_partial_descriptor_type) :: current
   integer(int64) :: first, last, nblock, total
   logical :: extents_ok

   if (.not.stream%active .or. .not.stream%partial_active) then
      call fatal_error(error, "g-xTB exchange partial stream is not active")
      return
   end if
   if (stream%reverse_only) then
      call fatal_error(error, &
         & "forward partial import is invalid in a reverse-only transaction")
      return
   end if
   if (stream%partial_forward_imported) then
      call fatal_error(error, "g-xTB exchange forward payload was imported")
      return
   end if
   if (stream%applied .or. stream%batch_applied) then
      call fatal_error(error, &
         & "g-xTB exchange forward payload import followed kernel apply")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange partial state was invalidated before import")
      return
   end if
   call get_partial_descriptor(stream, 1, current)
   if (.not.cp2k_exchange_partial_descriptors_match(current, descriptor)) then
      call fatal_error(error, "g-xTB exchange partial descriptor mismatch")
      return
   end if
   if (size(owner_count) /= stream%nk) then
      call fatal_error(error, "inconsistent g-xTB exchange owner-count size")
      return
   end if
   if (any(owner_count < 0)) then
      call fatal_error(error, "negative g-xTB exchange owner count")
      return
   end if
   if (any(owner_count > 1)) then
      call fatal_error(error, "duplicate g-xTB exchange k-point ownership")
      return
   end if
   if (any(owner_count == 0)) then
      call fatal_error(error, "missing g-xTB exchange k-point ownership")
      return
   end if
   call partial_forward_extents(stream%nao, stream%batch_count, stream%nspin, &
      & nblock, total, extents_ok)
   if (.not.extents_ok) then
      call fatal_error(error, &
         & "g-xTB exchange forward payload exceeds indexing limit")
      return
   end if
   if (buffer%abi_version /= cp2k_exchange_partial_abi_version &
      & .or. .not.allocated(buffer%values)) then
      call fatal_error(error, "inconsistent g-xTB exchange forward payload")
      return
   end if
   if (size(buffer%values, kind=int64) /= total &
      & .or. any(buffer%descriptor_signature /= &
      & partial_descriptor_signature(descriptor))) then
      call fatal_error(error, "inconsistent g-xTB exchange forward payload")
      return
   end if
   if (.not.all(ieee_is_finite(real(buffer%values, wp))) &
      & .or. .not.all(ieee_is_finite(aimag(buffer%values)))) then
      call fatal_error(error, "non-finite g-xTB exchange forward payload")
      return
   end if

   first = 1_int64
   last = nblock
   stream%amat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%amat_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%amat_partner_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%amat_partner_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%cmat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%cmat_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%vmat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%vmat_r(:, :, 1:stream%batch_count, :)))
   stream%seen = .true.
   stream%partial_forward_imported = .true.
end subroutine cp2k_exchange_partial_import_forward


!> Add one uniquely owned Bloch block to a reverse partial accumulator.
subroutine cp2k_exchange_partial_reverse_push(stream, ik, density, overlap, &
   & error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(in) :: density(:, :, :), overlap(:, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active .or. .not.stream%partial_active &
      & .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange reverse partial stream is not active")
      return
   end if
   if (stream%partial_reverse_imported) then
      call fatal_error(error, &
         & "g-xTB exchange reverse partial push followed import")
      return
   end if
   if (stream%partial_reverse_exported) then
      call fatal_error(error, &
         & "g-xTB exchange reverse partial push followed export")
      return
   end if
   call cp2k_exchange_stream_reverse_push(stream, ik, density, overlap, error)
end subroutine cp2k_exchange_partial_reverse_push


!> Export one additive reverse-source payload and local ownership vector.
subroutine cp2k_exchange_partial_export_reverse(stream, descriptor, &
   & owner_count, buffer, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(cp2k_exchange_partial_descriptor_type), intent(out) :: descriptor
   integer, allocatable, intent(out) :: owner_count(:)
   type(cp2k_exchange_partial_reverse_type), intent(out) :: buffer
   type(error_type), allocatable, intent(out) :: error

   integer :: nblock_default, nonsite_default, total_default
   integer(int64) :: first, last, nblock, nonsite, total
   logical :: extents_ok

   if (.not.stream%active .or. .not.stream%partial_active &
      & .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange reverse partial stream is not active")
      return
   end if
   if (stream%partial_reverse_imported) then
      call fatal_error(error, "g-xTB exchange reverse payload was imported")
      return
   end if
   if (stream%partial_reverse_exported) then
      call fatal_error(error, "g-xTB exchange reverse payload was exported")
      return
   end if
   if (stream%reverse_batch_applied .or. stream%reverse_applied) then
      call fatal_error(error, &
         & "g-xTB exchange reverse payload export followed kernel apply")
      return
   end if

   call get_partial_descriptor(stream, 2, descriptor)
   allocate(owner_count(stream%nk), source=0)
   where (stream%seen)
      owner_count = 1
   end where
   call partial_reverse_extents(stream%nao, stream%batch_count, stream%nspin, &
      & nblock, nonsite, total, extents_ok)
   if (.not.extents_ok) then
      call fatal_error(error, &
         & "g-xTB exchange reverse payload exceeds indexing limit")
      return
   end if
   nblock_default = int(nblock)
   nonsite_default = int(nonsite)
   total_default = int(total)
   allocate(buffer%values(total_default))
   first = 1_int64
   last = nblock
   buffer%values(first:last) = reshape( &
      & stream%amat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%cmat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%vmat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%amat_partner_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%reverse_amat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nblock
   buffer%values(first:last) = reshape( &
      & stream%reverse_vmat_r(:, :, 1:stream%batch_count, :), [nblock_default])
   first = last+1_int64
   last = last+nonsite
   buffer%values(first:last) = reshape(stream%gdiagP, [nonsite_default])
   first = last+1_int64
   last = last+nonsite
   buffer%values(first:last) = reshape(stream%gdiagSP, [nonsite_default])
   first = last+1_int64
   last = last+nonsite
   buffer%values(first:last) = reshape(stream%gdiagSPS, [nonsite_default])
   first = last+1_int64
   last = last+nonsite
   buffer%values(first:last) = reshape(stream%reverse_bdiagSP, [nonsite_default])
   first = last+1_int64
   last = last+nonsite
   buffer%values(first:last) = reshape(stream%reverse_bdiagSPS, &
      & [nonsite_default])
   if (.not.all(ieee_is_finite(real(buffer%values, wp))) &
      & .or. .not.all(ieee_is_finite(aimag(buffer%values)))) then
      call fatal_error(error, "non-finite g-xTB exchange reverse payload")
      return
   end if
   buffer%abi_version = cp2k_exchange_partial_abi_version
   buffer%descriptor_signature = partial_descriptor_signature(descriptor)
   stream%partial_reverse_exported = .true.
end subroutine cp2k_exchange_partial_export_reverse


!> Number of complex scalars in an exported reverse payload.
!>
!> Construction fails closed before allocation if the count exceeds
!> `huge(default integer)`; a host may still chunk MPI reductions below that
!> provider-side indexing limit.
integer(int64) function cp2k_exchange_partial_reverse_size(buffer) &
   & result(nelements)
   type(cp2k_exchange_partial_reverse_type), intent(in) :: buffer

   if (buffer%abi_version == cp2k_exchange_partial_abi_version &
      & .and. allocated(buffer%values)) then
      nelements = size(buffer%values, kind=int64)
   else
      nelements = -1_int64
   end if
end function cp2k_exchange_partial_reverse_size


!> Copy an opaque reverse payload into contiguous host/MPI storage.
subroutine cp2k_exchange_partial_reverse_pack(buffer, values, error)
   type(cp2k_exchange_partial_reverse_type), intent(in) :: buffer
   complex(wp), allocatable, intent(out) :: values(:)
   type(error_type), allocatable, intent(out) :: error

   if (buffer%abi_version /= cp2k_exchange_partial_abi_version &
      & .or. .not.allocated(buffer%values)) then
      call fatal_error(error, "invalid g-xTB exchange reverse payload")
      return
   end if
   allocate(values, source=buffer%values)
end subroutine cp2k_exchange_partial_reverse_pack


!> Recreate an opaque reverse payload from host-reduced contiguous storage.
!>
!> `descriptor` must be the exact collectively validated companion descriptor
!> exported with `values`.  Rebinding saved raw values to a fresh descriptor is
!> forbidden by the host contract.
subroutine cp2k_exchange_partial_reverse_unpack(buffer, descriptor, values, &
   & error)
   type(cp2k_exchange_partial_reverse_type), intent(out) :: buffer
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: descriptor
   complex(wp), intent(in) :: values(:)
   type(error_type), allocatable, intent(out) :: error

   integer(int64) :: expected, nblock, nonsite
   logical :: extents_ok

   if (.not.partial_descriptor_is_valid(descriptor) &
      & .or. descriptor%phase /= 2) then
      call fatal_error(error, "inconsistent g-xTB exchange reverse descriptor")
      return
   end if
   call partial_reverse_extents(descriptor%nao, descriptor%batch_count, &
      & descriptor%nspin, nblock, nonsite, expected, extents_ok)
   if (.not.extents_ok) then
      call fatal_error(error, &
         & "g-xTB exchange reverse payload exceeds indexing limit")
      return
   end if
   if (size(values, kind=int64) /= expected) then
      call fatal_error(error, "inconsistent g-xTB exchange reverse payload")
      return
   end if
   if (.not.all(ieee_is_finite(real(values, wp))) &
      & .or. .not.all(ieee_is_finite(aimag(values)))) then
      call fatal_error(error, "non-finite g-xTB exchange reverse payload")
      return
   end if
   allocate(buffer%values, source=values)
   buffer%abi_version = cp2k_exchange_partial_abi_version
   buffer%descriptor_signature = partial_descriptor_signature(descriptor)
end subroutine cp2k_exchange_partial_reverse_unpack


!> Import globally summed reverse sources before the coupled adjoint kernel.
subroutine cp2k_exchange_partial_import_reverse(stream, descriptor, &
   & owner_count, buffer, calc, mol, ecache, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(cp2k_exchange_partial_descriptor_type), intent(in) :: descriptor
   integer, intent(in) :: owner_count(:)
   type(cp2k_exchange_partial_reverse_type), intent(in) :: buffer
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(in) :: ecache
   type(error_type), allocatable, intent(out) :: error

   type(cp2k_exchange_partial_descriptor_type) :: current
   integer(int64) :: first, last, nblock, nonsite, total
   logical :: extents_ok

   if (.not.stream%active .or. .not.stream%partial_active &
      & .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange reverse partial stream is not active")
      return
   end if
   if (stream%partial_reverse_imported) then
      call fatal_error(error, "g-xTB exchange reverse payload was imported")
      return
   end if
   if (stream%reverse_batch_applied .or. stream%reverse_applied) then
      call fatal_error(error, &
         & "g-xTB exchange reverse payload import followed kernel apply")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange partial state was invalidated before import")
      return
   end if
   call get_partial_descriptor(stream, 2, current)
   if (.not.cp2k_exchange_partial_descriptors_match(current, descriptor)) then
      call fatal_error(error, "g-xTB exchange partial descriptor mismatch")
      return
   end if
   if (size(owner_count) /= stream%nk) then
      call fatal_error(error, "inconsistent g-xTB exchange owner-count size")
      return
   end if
   if (any(owner_count < 0)) then
      call fatal_error(error, "negative g-xTB exchange owner count")
      return
   end if
   if (any(owner_count > 1)) then
      call fatal_error(error, "duplicate g-xTB exchange k-point ownership")
      return
   end if
   if (any(owner_count == 0)) then
      call fatal_error(error, "missing g-xTB exchange k-point ownership")
      return
   end if
   call partial_reverse_extents(stream%nao, stream%batch_count, stream%nspin, &
      & nblock, nonsite, total, extents_ok)
   if (.not.extents_ok) then
      call fatal_error(error, &
         & "g-xTB exchange reverse payload exceeds indexing limit")
      return
   end if
   if (buffer%abi_version /= cp2k_exchange_partial_abi_version &
      & .or. .not.allocated(buffer%values)) then
      call fatal_error(error, "inconsistent g-xTB exchange reverse payload")
      return
   end if
   if (size(buffer%values, kind=int64) /= total &
      & .or. any(buffer%descriptor_signature /= &
      & partial_descriptor_signature(descriptor))) then
      call fatal_error(error, "inconsistent g-xTB exchange reverse payload")
      return
   end if
   if (.not.all(ieee_is_finite(real(buffer%values, wp))) &
      & .or. .not.all(ieee_is_finite(aimag(buffer%values)))) then
      call fatal_error(error, "non-finite g-xTB exchange reverse payload")
      return
   end if

   first = 1_int64
   last = nblock
   stream%amat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%amat_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%cmat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%cmat_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%vmat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%vmat_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%amat_partner_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%amat_partner_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%reverse_amat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%reverse_amat_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nblock
   stream%reverse_vmat_r(:, :, 1:stream%batch_count, :) = &
      & reshape(buffer%values(first:last), &
      & shape(stream%reverse_vmat_r(:, :, 1:stream%batch_count, :)))
   first = last+1_int64
   last = last+nonsite
   stream%gdiagP = reshape(buffer%values(first:last), shape(stream%gdiagP))
   first = last+1_int64
   last = last+nonsite
   stream%gdiagSP = reshape(buffer%values(first:last), shape(stream%gdiagSP))
   first = last+1_int64
   last = last+nonsite
   stream%gdiagSPS = reshape(buffer%values(first:last), shape(stream%gdiagSPS))
   first = last+1_int64
   last = last+nonsite
   stream%reverse_bdiagSP = reshape(buffer%values(first:last), &
      & shape(stream%reverse_bdiagSP))
   first = last+1
   last = last+nonsite
   stream%reverse_bdiagSPS = reshape(buffer%values(first:last), &
      & shape(stream%reverse_bdiagSPS))
   stream%seen = .true.
   stream%partial_reverse_imported = .true.
end subroutine cp2k_exchange_partial_import_reverse


!> Select a disjoint distributed pull partition for replicated importers.
!>
!> `owner_rank(ik)` is the one-based contributor that reconstructs Bloch block
!> `ik`; values must cover the complete mesh and lie in
!> `1:contributor_count`.  Every importer must receive the same host-broadcast
!> owner map, while `contributor_rank` identifies the local importer.  Exactly
!> `result_owner_rank` may retrieve the replicated scalar shell-potential/
!> energy or direct force/stress result.  This routine is MPI-free: CP2K owns
!> the broadcast and must first establish exact descriptor agreement.
!>
!> The operation is optional.  Without it, the legacy designated-root path
!> remains strict and requires every Bloch block plus the scalar result to be
!> pulled from the single importer.
subroutine cp2k_exchange_partial_set_pull_ownership(stream, owner_rank, &
   & contributor_rank, contributor_count, result_owner_rank, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: owner_rank(:)
   integer, intent(in) :: contributor_rank, contributor_count, result_owner_rank
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active .or. .not.stream%partial_active) then
      call fatal_error(error, "g-xTB exchange partial stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, &
         & "distributed partial pulls require batched exchange mode")
      return
   end if
   if (stream%partial_pull_distribution_set) then
      call fatal_error(error, &
         & "g-xTB exchange partial pull ownership was already set")
      return
   end if
   if (stream%reverse_transaction) then
      if (.not.stream%partial_reverse_imported) then
         call fatal_error(error, &
            & "reverse partial pull ownership requires an imported payload")
         return
      end if
      if (any(stream%reverse_pulled)) then
         call fatal_error(error, &
            & "reverse partial pull ownership followed a pull")
         return
      end if
   else
      if (.not.stream%partial_forward_imported) then
         call fatal_error(error, &
            & "forward partial pull ownership requires an imported payload")
         return
      end if
      if (any(stream%batch_pulled)) then
         call fatal_error(error, &
            & "forward partial pull ownership followed a pull")
         return
      end if
   end if
   if (size(owner_rank) /= stream%nk) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange partial pull-owner size")
      return
   end if
   if (contributor_count < 1 &
      & .or. contributor_rank < 1 &
      & .or. contributor_rank > contributor_count &
      & .or. result_owner_rank < 1 &
      & .or. result_owner_rank > contributor_count) then
      call fatal_error(error, &
         & "invalid g-xTB exchange partial contributor identity")
      return
   end if
   if (any(owner_rank < 1) .or. any(owner_rank > contributor_count)) then
      call fatal_error(error, &
         & "invalid g-xTB exchange partial pull-owner map")
      return
   end if

   allocate(stream%partial_pull_mask(stream%nk), &
      & source=owner_rank == contributor_rank)
   stream%partial_result_owner = contributor_rank == result_owner_rank
   stream%partial_pull_distribution_set = .true.
end subroutine cp2k_exchange_partial_set_pull_ownership


!> Reuse an exported contributor for the next sequential image batch.
!>
!> A contributor has no permission to run the nonlinear kernel.  This
!> operation therefore advances only its linear accumulation buffers after
!> the host has copied the exported payload.  The importing accumulator uses
!> the ordinary batch-advance operation after apply and pull; both paths then
!> arrive at the same next descriptor generation.
subroutine cp2k_exchange_partial_contributor_advance(stream, done, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   logical, intent(out) :: done
   type(error_type), allocatable, intent(out) :: error

   logical :: reverse_phase

   done = .false.
   if (.not.stream%active .or. .not.stream%partial_active) then
      call fatal_error(error, "g-xTB exchange partial stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, &
         & "g-xTB exchange partial stream is not in batched mode")
      return
   end if
   reverse_phase = stream%reverse_transaction
   if (reverse_phase) then
      if (.not.stream%partial_reverse_exported &
         & .or. stream%partial_reverse_imported) then
         call fatal_error(error, &
            & "reverse contributor advance requires an unimported export")
         return
      end if
   else
      if (.not.stream%partial_forward_exported &
         & .or. stream%partial_forward_imported) then
         call fatal_error(error, &
            & "forward contributor advance requires an unimported export")
         return
      end if
   end if
   if (stream%batch_first+stream%batch_count > stream%batch_last) then
      done = .true.
      return
   end if

   stream%batch_first = stream%batch_first+stream%batch_count
   stream%batch_count = min(stream%batch_size, &
      & stream%batch_last-stream%batch_first+1)
   stream%seen = .false.
   stream%partial_generation = stream%partial_generation+1
   stream%amat_r = (0.0_wp, 0.0_wp)
   stream%cmat_r = (0.0_wp, 0.0_wp)
   stream%vmat_r = (0.0_wp, 0.0_wp)
   stream%amat_partner_r = (0.0_wp, 0.0_wp)
   if (reverse_phase) then
      stream%partial_reverse_exported = .false.
      stream%reverse_amat_r = (0.0_wp, 0.0_wp)
      stream%reverse_vmat_r = (0.0_wp, 0.0_wp)
      stream%gdiagP = (0.0_wp, 0.0_wp)
      stream%gdiagSP = (0.0_wp, 0.0_wp)
      stream%gdiagSPS = (0.0_wp, 0.0_wp)
      stream%reverse_bdiagSP = (0.0_wp, 0.0_wp)
      stream%reverse_bdiagSPS = (0.0_wp, 0.0_wp)
   else
      stream%partial_forward_exported = .false.
   end if
end subroutine cp2k_exchange_partial_contributor_advance


!> Abandon an exported contributor after the host has copied its payload.
!>
!> This is the only early-close operation.  It is intentionally restricted to
!> partial streams so ordinary stream transactions retain their strict result
!> and pull completion requirements.
subroutine cp2k_exchange_partial_discard(stream, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active .or. .not.stream%partial_active) then
      call fatal_error(error, "g-xTB exchange partial stream is not active")
      return
   end if
   if (.not.stream%partial_forward_exported .and. &
      & .not.stream%partial_reverse_exported) then
      call fatal_error(error, &
         & "only an exported g-xTB exchange contributor can be discarded")
      return
   end if
   if (stream%partial_forward_imported .or. &
      & stream%partial_reverse_imported) then
      call fatal_error(error, &
         & "an imported g-xTB exchange accumulator cannot be discarded")
      return
   end if
   call clear_exchange_stream(stream)
end subroutine cp2k_exchange_partial_discard


!> Initialize the bounded reverse state after mesh/model validation.
subroutine initialize_exchange_stream_reverse(stream, mol, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(structure_type), intent(in) :: mol
   type(error_type), allocatable, intent(out) :: error

   integer :: capacity

   if (stream%reverse_transaction .or. stream%reverse_applied) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse transaction already started")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_reduced .and. &
      & stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, &
         & "streamed g-xTB exchange reverse requires reduced or batched mode")
      return
   end if
   if (allocated(stream%partial_pull_mask)) &
      & deallocate(stream%partial_pull_mask)
   stream%partial_pull_distribution_set = .false.
   stream%partial_result_owner = .false.

   if (stream%mode == cp2k_exchange_stream_reduced) then
      stream%batch_size = stream%nk
      stream%image_first = 1
      stream%batch_first = 1
      stream%batch_count = stream%nk
      stream%batch_last = stream%nk
   else
      stream%batch_first = stream%image_first
      stream%batch_count = min(stream%batch_size, &
         & stream%batch_last-stream%image_first+1)
   end if
   capacity = stream%batch_size

   if (.not.allocated(stream%amat_r)) &
      & allocate(stream%amat_r(stream%nao, stream%nao, capacity, &
      & stream%nspin))
   if (.not.allocated(stream%cmat_r)) &
      & allocate(stream%cmat_r(stream%nao, stream%nao, capacity, &
      & stream%nspin))
   if (.not.allocated(stream%vmat_r)) &
      & allocate(stream%vmat_r(stream%nao, stream%nao, capacity, &
      & stream%nspin))
   if (.not.allocated(stream%amat_partner_r)) &
      & allocate(stream%amat_partner_r(stream%nao, stream%nao, capacity, &
      & stream%nspin))
   allocate(stream%reverse_amat_r(stream%nao, stream%nao, capacity, &
      & stream%nspin), stream%reverse_vmat_r(stream%nao, stream%nao, &
      & capacity, stream%nspin), source=(0.0_wp, 0.0_wp))
   if (.not.allocated(stream%gdiagP)) &
      & allocate(stream%gdiagP(stream%nao, stream%nspin))
   if (.not.allocated(stream%gdiagSP)) &
      & allocate(stream%gdiagSP(stream%nao, stream%nspin))
   if (.not.allocated(stream%gdiagSPS)) &
      & allocate(stream%gdiagSPS(stream%nao, stream%nspin))
   allocate(stream%reverse_bdiagSP(stream%nao, stream%nspin), &
      & stream%reverse_bdiagSPS(stream%nao, stream%nspin), &
      & source=(0.0_wp, 0.0_wp))
   allocate(stream%reverse_gradient(3, mol%nat), &
      & stream%reverse_sigma(3, 3), source=0.0_wp)
   if (.not.allocated(stream%density_signature)) &
      & allocate(stream%density_signature(stream%nk), source=0_int64)
   if (.not.allocated(stream%overlap_signature)) &
      & allocate(stream%overlap_signature(stream%nk), source=0_int64)
   if (.not.allocated(stream%block_signature_set)) &
      & allocate(stream%block_signature_set(stream%nk), source=.false.)

   stream%amat_r = (0.0_wp, 0.0_wp)
   stream%cmat_r = (0.0_wp, 0.0_wp)
   stream%vmat_r = (0.0_wp, 0.0_wp)
   stream%amat_partner_r = (0.0_wp, 0.0_wp)
   stream%gdiagP = (0.0_wp, 0.0_wp)
   stream%gdiagSP = (0.0_wp, 0.0_wp)
   stream%gdiagSPS = (0.0_wp, 0.0_wp)
   stream%seen = .false.
   stream%reverse_pulled = .false.
   stream%forward_pulled = .true.
   stream%batch_result_pulled = .true.
   stream%reverse_batch_applied = .false.
   stream%reverse_result_pulled = .false.
   if (stream%partial_active) then
      stream%partial_generation = 1
      stream%partial_reverse_exported = .false.
      stream%partial_reverse_imported = .false.
   end if
   stream%reverse_transaction = .true.
   stream%reverse_applied = .false.
   stream%peak_complex_elements = max(stream%peak_complex_elements, &
      & exchange_stream_complex_elements(stream) &
      & +10_int64*int(stream%nao, int64)**2)
end subroutine initialize_exchange_stream_reverse


!> Enter a bounded reverse transaction after a reduced/batched forward apply.
!>
!> Forward Fock pulls are intentionally waived: the reverse sweep recomputes
!> only the image-local responses needed by the overlap adjoint and therefore
!> does not force a gradient-only caller to reconstruct unused Fock blocks.
subroutine cp2k_exchange_stream_reverse_begin(stream, mol, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(structure_type), intent(in) :: mol
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (.not.stream%applied) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse requires forward apply")
      return
   end if
   call initialize_exchange_stream_reverse(stream, mol, error)
end subroutine cp2k_exchange_stream_reverse_begin


!> Push one unweighted density/overlap Bloch block into an active stream.
subroutine cp2k_exchange_stream_push(stream, ik, density, overlap, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(in) :: density(:, :, :), overlap(:, :)
   type(error_type), allocatable, intent(out) :: error

   integer :: ibatch, icell, inverse_cell, spin
   integer(int64) :: density_signature, overlap_signature
   real(wp) :: angle
   complex(wp) :: phase
   complex(wp), allocatable :: amat(:, :), cmat(:, :)

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%partial_active .and. stream%partial_forward_imported) then
      call fatal_error(error, "g-xTB exchange partial push followed import")
      return
   end if
   if (stream%partial_active .and. stream%partial_forward_exported) then
      call fatal_error(error, "g-xTB exchange partial push followed export")
      return
   end if
   if (stream%applied) then
      call fatal_error(error, "g-xTB exchange stream was already applied")
      return
   end if
   if (stream%mode == cp2k_exchange_stream_batched &
      & .and. stream%batch_applied) then
      call fatal_error(error, &
         & "g-xTB exchange image batch was already applied")
      return
   end if
   if (ik < 1 .or. ik > stream%nk) then
      call fatal_error(error, "g-xTB exchange stream block index is out of range")
      return
   end if
   if (stream%seen(ik)) then
      call fatal_error(error, "duplicate g-xTB exchange stream block")
      return
   end if
   if (size(density, 1) /= stream%nao &
      & .or. size(density, 2) /= stream%nao &
      & .or. size(density, 3) /= stream%nspin &
      & .or. size(overlap, 1) /= stream%nao &
      & .or. size(overlap, 2) /= stream%nao) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream block dimensions")
      return
   end if

   if (stream%mode == cp2k_exchange_stream_batched) then
      density_signature = exchange_hash_complex3(density)
      overlap_signature = exchange_hash_complex2(overlap)
      if (stream%block_signature_set(ik)) then
         if (density_signature /= stream%density_signature(ik)) then
            call fatal_error(error, &
               & "changed g-xTB exchange image-batch density block")
            return
         end if
         if (overlap_signature /= stream%overlap_signature(ik)) then
            call fatal_error(error, &
               & "changed g-xTB exchange image-batch overlap block")
            return
         end if
      else
         stream%density_signature(ik) = density_signature
         stream%overlap_signature(ik) = overlap_signature
         stream%block_signature_set(ik) = .true.
      end if
   end if

   if (stream%mode == cp2k_exchange_stream_oracle) then
      stream%density(:, :, :, ik) = density
      stream%overlap(:, :, ik) = overlap
   else if (stream%mode == cp2k_exchange_stream_reduced) then
      allocate(amat(stream%nao, stream%nao), cmat(stream%nao, stream%nao))
      do spin = 1, stream%nspin
         amat = matmul(overlap, density(:, :, spin))
         cmat = 0.5_wp*matmul(amat, overlap)
         do icell = 1, stream%nk
            angle = 2.0_wp*pi*dot_product(stream%kfrac(:, ik), &
               & real(stream%reps(:, icell), wp))
            phase = stream%weights(ik)*exp(cmplx(0.0_wp, -angle, wp))
            stream%amat_r(:, :, icell, spin) = &
               & stream%amat_r(:, :, icell, spin) + phase*amat
            stream%cmat_r(:, :, icell, spin) = &
               & stream%cmat_r(:, :, icell, spin) + phase*cmat
            stream%vmat_r(:, :, icell, spin) = &
               & stream%vmat_r(:, :, icell, spin) + phase*density(:, :, spin)
         end do
      end do
   else
      allocate(amat(stream%nao, stream%nao), cmat(stream%nao, stream%nao))
      do spin = 1, stream%nspin
         amat = matmul(overlap, density(:, :, spin))
         cmat = 0.5_wp*matmul(amat, overlap)
         do ibatch = 1, stream%batch_count
            icell = stream%batch_first + ibatch - 1
            inverse_cell = stream%inverse_image(icell)
            phase = stream%weights(ik)*conjg( &
               & regular_grid_phase_forward(stream%nmesh, &
               & stream%input_to_grid, stream%reps(:, icell), &
               & stream%phase_roots, stream%twist_phase(icell), ik))
            stream%amat_r(:, :, ibatch, spin) = &
               & stream%amat_r(:, :, ibatch, spin) + phase*amat
            stream%cmat_r(:, :, ibatch, spin) = &
               & stream%cmat_r(:, :, ibatch, spin) + phase*cmat
            stream%vmat_r(:, :, ibatch, spin) = &
               & stream%vmat_r(:, :, ibatch, spin) &
               & +phase*density(:, :, spin)
            phase = stream%weights(ik)*conjg( &
               & regular_grid_phase_forward(stream%nmesh, &
               & stream%input_to_grid, stream%reps(:, inverse_cell), &
               & stream%phase_roots, stream%twist_phase(inverse_cell), ik))
            stream%amat_partner_r(:, :, ibatch, spin) = &
               & stream%amat_partner_r(:, :, ibatch, spin) + phase*amat
         end do
      end do
   end if
   stream%seen(ik) = .true.
end subroutine cp2k_exchange_stream_push


!> Apply exchange after all blocks have been collected.
!>
!> Reduced mode applies the kernels directly to the accumulated BvK images;
!> oracle mode dispatches the unchanged complete-mesh evaluator.
subroutine cp2k_exchange_stream_apply(stream, calc, mol, ecache, vsh, energy, &
   & error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   real(wp), intent(out) :: vsh(:), energy
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%applied) then
      call fatal_error(error, "g-xTB exchange stream was already applied")
      return
   end if
   if (stream%mode == cp2k_exchange_stream_batched) then
      call fatal_error(error, &
         & "batched g-xTB exchange requires batch apply")
      return
   end if
   if (.not.all(stream%seen)) then
      call fatal_error(error, "g-xTB exchange stream has missing blocks")
      return
   end if
   if (size(vsh) /= stream%nsh) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream shell-potential dimensions")
      return
   end if
   if (.not.allocated(calc%exchange) .or. .not.allocated(ecache%raw)) then
      call fatal_error(error, &
         & "g-xTB exchange stream state was invalidated before apply")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange stream state was invalidated before apply")
      return
   end if

   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         if (stream%mode == cp2k_exchange_stream_oracle) then
            call exchange%get_KFock_kmesh(mol, cache, cache%bvk_kernel, &
               & stream%kfrac, stream%weights, stream%density, stream%overlap, &
               & stream%fock, stream%vsh, stream%energy)
         else
            call exchange%get_KFock_stream_apply(mol, cache, &
               & cache%bvk_kernel, cache%bvk_phase_forward, stream%weights, &
               & stream%amat_r, stream%cmat_r, stream%vmat_r, &
               & stream%gdiagP, stream%gdiagSP, stream%gdiagSPS, &
               & stream%vsh, stream%energy)
         end if
         vsh = stream%vsh
         energy = stream%energy
         stream%applied = .true.
      class default
         call fatal_error(error, &
            & "exchange stream requires the exchange_fock implementation")
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
   end select
end subroutine cp2k_exchange_stream_apply


!> Retrieve one unweighted Fock block after a successful stream application.
!>
!> Reduced mode requires the corresponding overlap block again and
!> reconstructs only this requested k point.  Oracle mode reads the retained
!> complete-mesh result and does not require the optional overlap argument.
subroutine cp2k_exchange_stream_get(stream, ik, fock, error, overlap)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(out) :: fock(:, :, :)
   type(error_type), allocatable, intent(out) :: error
   complex(wp), intent(in), optional :: overlap(:, :)

   integer :: icell
   real(wp) :: angle
   complex(wp), allocatable :: phase_forward(:)

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (.not.stream%applied) then
      call fatal_error(error, "g-xTB exchange stream was not applied")
      return
   end if
   if (stream%mode == cp2k_exchange_stream_batched) then
      call fatal_error(error, &
         & "batched g-xTB exchange requires batch pulls")
      return
   end if
   if (ik < 1 .or. ik > stream%nk) then
      call fatal_error(error, "g-xTB exchange stream block index is out of range")
      return
   end if
   if (stream%forward_pulled(ik)) then
      call fatal_error(error, "duplicate g-xTB exchange stream forward pull")
      return
   end if
   if (size(fock, 1) /= stream%nao .or. size(fock, 2) /= stream%nao &
      & .or. size(fock, 3) /= stream%nspin) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream Fock dimensions")
      return
   end if

   if (stream%mode == cp2k_exchange_stream_oracle) then
      fock = stream%fock(:, :, :, ik)
      stream%forward_pulled(ik) = .true.
      return
   end if
   if (.not.present(overlap)) then
      call fatal_error(error, &
         & "memory-reduced g-xTB exchange stream get requires overlap block")
      return
   end if
   if (size(overlap, 1) /= stream%nao .or. size(overlap, 2) /= stream%nao) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream get overlap dimensions")
      return
   end if

   allocate(phase_forward(stream%nk))
   do icell = 1, stream%nk
      angle = 2.0_wp*pi*dot_product(stream%kfrac(:, ik), &
         & real(stream%reps(:, icell), wp))
      phase_forward(icell) = exp(cmplx(0.0_wp, angle, wp))
   end do
   call reconstruct_stream_fock_block(overlap, phase_forward, .true., &
      & stream%amat_r, stream%cmat_r, stream%vmat_r, stream%gdiagP, &
      & stream%gdiagSP, stream%gdiagSPS, fock)
   stream%forward_pulled(ik) = .true.
end subroutine cp2k_exchange_stream_get


!> Return the inclusive representative range of the current image batch.
!>
!> Batched exchange is a deliberately sequential caller-driven protocol:
!> every Bloch block is pushed once for this range, the range is applied, and
!> every Fock contribution is pulled once before `batch_advance` may reuse the
!> bounded image storage.
subroutine cp2k_exchange_stream_batch_bounds(stream, first_image, last_image, &
   & error)
   type(cp2k_exchange_stream_type), intent(in) :: stream
   integer, intent(out) :: first_image, last_image
   type(error_type), allocatable, intent(out) :: error

   first_image = 0
   last_image = 0
   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, "g-xTB exchange stream is not in batched mode")
      return
   end if
   if (stream%applied) then
      call fatal_error(error, "g-xTB exchange image batches are complete")
      return
   end if
   first_image = stream%batch_first
   last_image = stream%batch_first + stream%batch_count - 1
end subroutine cp2k_exchange_stream_batch_bounds


!> Apply the current bounded image batch after all k blocks were resubmitted.
subroutine cp2k_exchange_stream_batch_apply(stream, calc, mol, ecache, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   type(error_type), allocatable, intent(out) :: error

   integer :: ibatch
   integer, allocatable :: image_index(:)
   real(wp) :: energy_batch
   real(wp), allocatable :: vsh_batch(:)

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, "g-xTB exchange stream is not in batched mode")
      return
   end if
   if (stream%applied) then
      call fatal_error(error, "g-xTB exchange image batches are complete")
      return
   end if
   if (stream%batch_applied) then
      call fatal_error(error, "g-xTB exchange image batch was already applied")
      return
   end if
   if (stream%partial_active .and. &
      & .not.stream%partial_forward_imported) then
      call fatal_error(error, &
         & "g-xTB exchange partial forward payload was not imported")
      return
   end if
   if (.not.all(stream%seen)) then
      call fatal_error(error, "g-xTB exchange image batch has missing blocks")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange image batch state was invalidated before apply")
      return
   end if

   allocate(image_index(stream%batch_count))
   allocate(vsh_batch(stream%nsh), source=0.0_wp)
   image_index = [(stream%batch_first+ibatch-1, &
      & ibatch=1, stream%batch_count)]
   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         call exchange%get_KFock_batch_apply(mol, cache, &
            & cache%bvk_kernel, image_index, &
            & stream%inverse_coeff(stream%batch_first: &
            & stream%batch_first+stream%batch_count-1), &
            & stream%amat_r(:, :, 1:stream%batch_count, :), &
            & stream%amat_partner_r(:, :, 1:stream%batch_count, :), &
            & stream%cmat_r(:, :, 1:stream%batch_count, :), &
            & stream%vmat_r(:, :, 1:stream%batch_count, :), &
            & stream%gdiagP, stream%gdiagSP, stream%gdiagSPS, &
            & vsh_batch, energy_batch)
      class default
         call fatal_error(error, &
            & "exchange image batch requires the exchange_fock implementation")
         return
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
      return
   end select
   stream%vsh = stream%vsh + vsh_batch
   stream%energy = stream%energy + energy_batch
   stream%batch_applied = .true.
end subroutine cp2k_exchange_stream_batch_apply


!> Add one k-point Fock contribution from the current image batch.
!>
!> The caller owns the final Fock mesh and must initialize each accumulator
!> before the first batch.  This routine adds exactly one batch contribution;
!> every k point must be pulled exactly once per applied batch.
subroutine cp2k_exchange_stream_batch_pull(stream, ik, overlap, fock, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(in) :: overlap(:, :)
   complex(wp), intent(inout) :: fock(:, :, :)
   type(error_type), allocatable, intent(out) :: error

   integer :: ibatch, icell
   logical :: add_onsite
   complex(wp), allocatable :: fock_batch(:, :, :), phase_forward(:)

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, "g-xTB exchange stream is not in batched mode")
      return
   end if
   if (.not.stream%batch_applied) then
      call fatal_error(error, "g-xTB exchange image batch was not applied")
      return
   end if
   if (ik < 1 .or. ik > stream%nk) then
      call fatal_error(error, "g-xTB exchange stream block index is out of range")
      return
   end if
   if (stream%partial_pull_distribution_set) then
      if (.not.stream%partial_pull_mask(ik)) then
         call fatal_error(error, "unowned g-xTB exchange image-batch pull")
         return
      end if
   end if
   if (stream%batch_pulled(ik)) then
      call fatal_error(error, "duplicate g-xTB exchange image-batch pull")
      return
   end if
   if (size(overlap, 1) /= stream%nao &
      & .or. size(overlap, 2) /= stream%nao &
      & .or. size(fock, 1) /= stream%nao &
      & .or. size(fock, 2) /= stream%nao &
      & .or. size(fock, 3) /= stream%nspin) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange image-batch pull dimensions")
      return
   end if
   if (stream%partial_active .and. &
      & .not.stream%block_signature_set(ik)) then
      stream%overlap_signature(ik) = exchange_hash_complex2(overlap)
      stream%block_signature_set(ik) = .true.
   else if (exchange_hash_complex2(overlap) /= &
      & stream%overlap_signature(ik)) then
      call fatal_error(error, &
         & "changed g-xTB exchange image-batch pull overlap")
      return
   end if
   allocate(fock_batch(stream%nao, stream%nao, stream%nspin), &
      & phase_forward(stream%batch_count))
   add_onsite = .false.
   do ibatch = 1, stream%batch_count
      icell = stream%batch_first + ibatch - 1
      phase_forward(ibatch) = regular_grid_phase_forward(stream%nmesh, &
         & stream%input_to_grid, stream%reps(:, icell), &
         & stream%phase_roots, stream%twist_phase(icell), ik)
      if (all(stream%reps(:, icell) == 0)) add_onsite = .true.
   end do
   call reconstruct_stream_fock_block(overlap, phase_forward, add_onsite, &
      & stream%amat_r(:, :, 1:stream%batch_count, :), &
      & stream%cmat_r(:, :, 1:stream%batch_count, :), &
      & stream%vmat_r(:, :, 1:stream%batch_count, :), &
      & stream%gdiagP, stream%gdiagSP, stream%gdiagSPS, fock_batch)
   fock = fock + fock_batch
   stream%batch_pulled(ik) = .true.
end subroutine cp2k_exchange_stream_batch_pull


!> Reuse the bounded storage for the next sequential image batch.
subroutine cp2k_exchange_stream_batch_advance(stream, done, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   logical, intent(out) :: done
   type(error_type), allocatable, intent(out) :: error

   done = .false.
   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, "g-xTB exchange stream is not in batched mode")
      return
   end if
   if (stream%applied) then
      call fatal_error(error, "g-xTB exchange image batches are complete")
      return
   end if
   if (.not.stream%batch_applied) then
      call fatal_error(error, "g-xTB exchange image batch was not applied")
      return
   end if
   if (stream%partial_pull_distribution_set) then
      if (any(stream%batch_pulled .neqv. stream%partial_pull_mask)) then
         call fatal_error(error, &
            & "g-xTB exchange image batch violates pull ownership")
         return
      end if
   else
      if (.not.all(stream%batch_pulled)) then
         call fatal_error(error, "g-xTB exchange image batch has missing pulls")
         return
      end if
   end if

   if (stream%batch_first+stream%batch_count > stream%batch_last) then
      stream%applied = .true.
      if (stream%partial_pull_distribution_set &
         & .and. .not.stream%partial_result_owner) &
         & stream%batch_result_pulled = .true.
      done = .true.
      return
   end if

   stream%batch_first = stream%batch_first + stream%batch_count
   stream%batch_count = min(stream%batch_size, &
      & stream%batch_last-stream%batch_first+1)
   stream%seen = .false.
   stream%batch_pulled = .false.
   stream%batch_applied = .false.
   if (stream%partial_active) then
      stream%partial_generation = stream%partial_generation+1
      stream%partial_forward_exported = .false.
      stream%partial_forward_imported = .false.
   end if
   stream%amat_r = (0.0_wp, 0.0_wp)
   stream%amat_partner_r = (0.0_wp, 0.0_wp)
   stream%cmat_r = (0.0_wp, 0.0_wp)
   stream%vmat_r = (0.0_wp, 0.0_wp)
end subroutine cp2k_exchange_stream_batch_advance


!> Return the accumulated energy and shell potential exactly once after all
!> batches.  A successful result pull is mandatory before the stream can end.
subroutine cp2k_exchange_stream_batch_result(stream, calc, mol, ecache, vsh, &
   & energy, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(in) :: ecache
   real(wp), intent(out) :: vsh(:), energy
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched) then
      call fatal_error(error, "g-xTB exchange stream is not in batched mode")
      return
   end if
   if (.not.stream%applied) then
      call fatal_error(error, "g-xTB exchange image batches are incomplete")
      return
   end if
   if (stream%batch_result_pulled) then
      call fatal_error(error, &
         & "g-xTB exchange image-batch result was already pulled")
      return
   end if
   if (size(vsh) /= stream%nsh) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream shell-potential dimensions")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange image batch state was invalidated before result")
      return
   end if
   vsh = stream%vsh
   energy = stream%energy
   stream%batch_result_pulled = .true.
end subroutine cp2k_exchange_stream_batch_result


!> Resubmit one unweighted density/overlap block to the current reverse batch.
subroutine cp2k_exchange_stream_reverse_push(stream, ik, density, overlap, &
   & error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(in) :: density(:, :, :), overlap(:, :)
   type(error_type), allocatable, intent(out) :: error

   integer :: ibatch, icell, iao, spin
   integer(int64) :: density_signature, overlap_signature
   logical :: has_origin
   real(wp) :: angle, spin_factor
   complex(wp) :: phase_adjoint, phase_source
   complex(wp), allocatable :: amat(:, :), bmat(:, :), dmat(:, :), &
      & vseed(:, :), xmat(:, :)

   if (.not.stream%active .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse transaction is not active")
      return
   end if
   if (stream%partial_active .and. stream%partial_reverse_imported) then
      call fatal_error(error, &
         & "g-xTB exchange reverse partial push followed import")
      return
   end if
   if (stream%partial_active .and. stream%partial_reverse_exported) then
      call fatal_error(error, &
         & "g-xTB exchange reverse partial push followed export")
      return
   end if
   if (stream%reverse_applied) then
      call fatal_error(error, "g-xTB exchange stream reverse is complete")
      return
   end if
   if (stream%reverse_batch_applied) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse batch was already applied")
      return
   end if
   if (ik < 1 .or. ik > stream%nk) then
      call fatal_error(error, "g-xTB exchange stream block index is out of range")
      return
   end if
   if (stream%seen(ik)) then
      call fatal_error(error, "duplicate g-xTB exchange reverse block")
      return
   end if
   if (size(density, 1) /= stream%nao &
      & .or. size(density, 2) /= stream%nao &
      & .or. size(density, 3) /= stream%nspin &
      & .or. size(overlap, 1) /= stream%nao &
      & .or. size(overlap, 2) /= stream%nao) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange reverse block dimensions")
      return
   end if

   density_signature = exchange_hash_complex3(density)
   overlap_signature = exchange_hash_complex2(overlap)
   if (stream%block_signature_set(ik)) then
      if (density_signature /= stream%density_signature(ik) &
         & .or. overlap_signature /= stream%overlap_signature(ik)) then
         call fatal_error(error, "changed g-xTB exchange reverse block")
         return
      end if
   else
      stream%density_signature(ik) = density_signature
      stream%overlap_signature(ik) = overlap_signature
      stream%block_signature_set(ik) = .true.
   end if

   allocate(amat(stream%nao, stream%nao), bmat(stream%nao, stream%nao), &
      & dmat(stream%nao, stream%nao), vseed(stream%nao, stream%nao), &
      & xmat(stream%nao, stream%nao))
   spin_factor = 0.5_wp
   if (stream%nspin > 1) spin_factor = 1.0_wp
   has_origin = .false.
   do ibatch = 1, stream%batch_count
      icell = stream%batch_first+ibatch-1
      if (all(stream%reps(:, icell) == 0)) has_origin = .true.
   end do

   do spin = 1, stream%nspin
      xmat = matmul(overlap, density(:, :, spin))
      dmat = 0.5_wp*matmul(xmat, overlap)
      amat = -0.25_wp*spin_factor*stream%weights(ik) &
         & *density(:, :, spin)
      bmat = matmul(amat, conjg(transpose(overlap)))
      vseed = 0.5_wp*matmul(conjg(transpose(overlap)), bmat)

      if (has_origin) then
         do iao = 1, stream%nao
            stream%gdiagP(iao, spin) = stream%gdiagP(iao, spin) &
               & +stream%weights(ik)*density(iao, iao, spin)
            stream%gdiagSP(iao, spin) = stream%gdiagSP(iao, spin) &
               & +stream%weights(ik)*xmat(iao, iao)
            stream%gdiagSPS(iao, spin) = stream%gdiagSPS(iao, spin) &
               & +2.0_wp*stream%weights(ik)*dmat(iao, iao)
            stream%reverse_bdiagSP(iao, spin) = &
               & stream%reverse_bdiagSP(iao, spin) &
               & +0.5_wp*dot_product(overlap(:, iao), amat(:, iao))
            stream%reverse_bdiagSPS(iao, spin) = &
               & stream%reverse_bdiagSPS(iao, spin)+0.25_wp*amat(iao, iao)
         end do
      end if

      do ibatch = 1, stream%batch_count
         icell = stream%batch_first+ibatch-1
         angle = 2.0_wp*pi*dot_product(stream%kfrac(:, ik), &
            & real(stream%reps(:, icell), wp))
         phase_adjoint = exp(cmplx(0.0_wp, -angle, wp))
         phase_source = stream%weights(ik)*phase_adjoint
         stream%amat_r(:, :, ibatch, spin) = &
            & stream%amat_r(:, :, ibatch, spin)+phase_source*xmat
         stream%cmat_r(:, :, ibatch, spin) = &
            & stream%cmat_r(:, :, ibatch, spin)+phase_source*dmat
         stream%vmat_r(:, :, ibatch, spin) = &
            & stream%vmat_r(:, :, ibatch, spin) &
            & +phase_source*density(:, :, spin)
         stream%amat_partner_r(:, :, ibatch, spin) = &
            & stream%amat_partner_r(:, :, ibatch, spin)+phase_adjoint*bmat
         stream%reverse_amat_r(:, :, ibatch, spin) = &
            & stream%reverse_amat_r(:, :, ibatch, spin)+phase_adjoint*amat
         stream%reverse_vmat_r(:, :, ibatch, spin) = &
            & stream%reverse_vmat_r(:, :, ibatch, spin)+phase_adjoint*vseed
      end do
   end do
   stream%seen(ik) = .true.
end subroutine cp2k_exchange_stream_reverse_push


!> Apply the current bounded reverse batch after all k blocks were resubmitted.
subroutine cp2k_exchange_stream_reverse_batch_apply(stream, calc, mol, ecache, &
   & error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   type(error_type), allocatable, intent(out) :: error

   integer :: ibatch
   integer, allocatable :: image_index(:)

   if (.not.stream%active .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse transaction is not active")
      return
   end if
   if (stream%reverse_applied) then
      call fatal_error(error, "g-xTB exchange stream reverse is complete")
      return
   end if
   if (stream%reverse_batch_applied) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse batch was already applied")
      return
   end if
   if (stream%partial_active .and. &
      & .not.stream%partial_reverse_imported) then
      call fatal_error(error, &
         & "g-xTB exchange partial reverse payload was not imported")
      return
   end if
   if (.not.all(stream%seen)) then
      call fatal_error(error, "g-xTB exchange reverse batch has missing blocks")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange reverse state was invalidated before apply")
      return
   end if

   allocate(image_index(stream%batch_count))
   image_index = [(stream%batch_first+ibatch-1, &
      & ibatch=1, stream%batch_count)]
   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         call exchange%get_KGrad_batch_apply(mol, cache, cache%bvk_kernel, &
            & image_index, stream%amat_r(:, :, 1:stream%batch_count, :), &
            & stream%cmat_r(:, :, 1:stream%batch_count, :), &
            & stream%vmat_r(:, :, 1:stream%batch_count, :), &
            & stream%amat_partner_r(:, :, 1:stream%batch_count, :), &
            & stream%reverse_amat_r(:, :, 1:stream%batch_count, :), &
            & stream%reverse_vmat_r(:, :, 1:stream%batch_count, :), &
            & stream%gdiagP, stream%gdiagSP, stream%gdiagSPS, &
            & stream%reverse_bdiagSP, stream%reverse_bdiagSPS, &
            & stream%reverse_gradient, stream%reverse_sigma)
      class default
         call fatal_error(error, &
            & "exchange reverse batch requires the exchange_fock implementation")
         return
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
      return
   end select
   stream%reverse_pulled = .false.
   stream%reverse_batch_applied = .true.
end subroutine cp2k_exchange_stream_reverse_batch_apply


!> Add one bounded-batch contribution to an unweighted overlap adjoint.
subroutine cp2k_exchange_stream_reverse_batch_pull(stream, ik, density, &
   & overlap, overlap_adjoint, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(in) :: density(:, :, :), overlap(:, :)
   complex(wp), intent(inout) :: overlap_adjoint(:, :)
   type(error_type), allocatable, intent(out) :: error

   integer :: ibatch, icell, iao, spin
   logical :: has_origin
   real(wp) :: angle, spin_factor
   complex(wp) :: phase
   complex(wp), allocatable :: amat(:, :), bmat(:, :), dadj(:, :), &
      & raw(:, :), raw_spin(:, :), tmat(:, :), vmat(:, :), &
      & work(:, :), xadj(:, :), xmat(:, :)

   if (.not.stream%active .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse transaction is not active")
      return
   end if
   if (.not.stream%reverse_batch_applied) then
      call fatal_error(error, "g-xTB exchange reverse batch was not applied")
      return
   end if
   if (ik < 1 .or. ik > stream%nk) then
      call fatal_error(error, "g-xTB exchange stream block index is out of range")
      return
   end if
   if (stream%partial_pull_distribution_set) then
      if (.not.stream%partial_pull_mask(ik)) then
         call fatal_error(error, "unowned g-xTB exchange reverse-batch pull")
         return
      end if
   end if
   if (stream%reverse_pulled(ik)) then
      call fatal_error(error, "duplicate g-xTB exchange reverse-batch pull")
      return
   end if
   if (size(density, 1) /= stream%nao &
      & .or. size(density, 2) /= stream%nao &
      & .or. size(density, 3) /= stream%nspin &
      & .or. size(overlap, 1) /= stream%nao &
      & .or. size(overlap, 2) /= stream%nao &
      & .or. size(overlap_adjoint, 1) /= stream%nao &
      & .or. size(overlap_adjoint, 2) /= stream%nao) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange reverse pull dimensions")
      return
   end if
   if (stream%partial_active .and. &
      & .not.stream%block_signature_set(ik)) then
      stream%density_signature(ik) = exchange_hash_complex3(density)
      stream%overlap_signature(ik) = exchange_hash_complex2(overlap)
      stream%block_signature_set(ik) = .true.
   else if (exchange_hash_complex3(density) /= &
      & stream%density_signature(ik) &
      & .or. exchange_hash_complex2(overlap) /= &
      & stream%overlap_signature(ik)) then
      call fatal_error(error, "changed g-xTB exchange reverse pull block")
      return
   end if

   allocate(amat(stream%nao, stream%nao), bmat(stream%nao, stream%nao), &
      & dadj(stream%nao, stream%nao), raw(stream%nao, stream%nao), &
      & raw_spin(stream%nao, stream%nao), tmat(stream%nao, stream%nao), &
      & vmat(stream%nao, stream%nao), &
      & work(stream%nao, stream%nao), xadj(stream%nao, stream%nao), &
      & xmat(stream%nao, stream%nao), source=(0.0_wp, 0.0_wp))
   spin_factor = 0.5_wp
   if (stream%nspin > 1) spin_factor = 1.0_wp
   has_origin = .false.
   do ibatch = 1, stream%batch_count
      icell = stream%batch_first+ibatch-1
      if (all(stream%reps(:, icell) == 0)) has_origin = .true.
   end do

   raw = (0.0_wp, 0.0_wp)
   do spin = 1, stream%nspin
      tmat = (0.0_wp, 0.0_wp)
      vmat = (0.0_wp, 0.0_wp)
      dadj = (0.0_wp, 0.0_wp)
      xadj = (0.0_wp, 0.0_wp)
      do ibatch = 1, stream%batch_count
         icell = stream%batch_first+ibatch-1
         angle = 2.0_wp*pi*dot_product(stream%kfrac(:, ik), &
            & real(stream%reps(:, icell), wp))
         phase = exp(cmplx(0.0_wp, angle, wp))
         tmat = tmat+phase*stream%amat_r(:, :, ibatch, spin)
         vmat = vmat+phase*stream%vmat_r(:, :, ibatch, spin)
         dadj = dadj+stream%weights(ik)*phase &
            & *stream%cmat_r(:, :, ibatch, spin)
         xadj = xadj+stream%weights(ik)*phase &
            & *stream%amat_partner_r(:, :, ibatch, spin)
      end do

      xmat = matmul(overlap, density(:, :, spin))
      amat = -0.25_wp*spin_factor*stream%weights(ik) &
         & *density(:, :, spin)
      bmat = matmul(amat, conjg(transpose(overlap)))
      work = tmat+0.5_wp*matmul(overlap, vmat)
      raw_spin = (0.0_wp, 0.0_wp)

      if (has_origin) then
         do iao = 1, stream%nao
            work(:, iao) = work(:, iao) &
               & +0.25_wp*stream%gdiagP(iao, spin)*overlap(:, iao)
         end do
      end if
      raw_spin = raw_spin+matmul(conjg(transpose(work)), amat)
      if (has_origin) then
         do iao = 1, stream%nao
            raw_spin(:, iao) = raw_spin(:, iao) &
               & +0.5_wp*conjg(stream%gdiagSP(iao, spin))*amat(:, iao) &
               & +0.25_wp*conjg(stream%gdiagP(iao, spin))*bmat(:, iao)
         end do
      end if
      raw_spin = raw_spin+0.5_wp*matmul(bmat, conjg(transpose(vmat)))

      if (has_origin) then
         do iao = 1, stream%nao
            xadj(iao, iao) = xadj(iao, iao) &
               & +stream%weights(ik)*stream%reverse_bdiagSP(iao, spin)
            xadj(iao, :) = xadj(iao, :) &
               & +stream%weights(ik)*stream%reverse_bdiagSPS(iao, spin) &
               & *overlap(iao, :)
            raw_spin(:, iao) = raw_spin(:, iao) &
               & +stream%weights(ik)*stream%reverse_bdiagSPS(iao, spin) &
               & *conjg(xmat(iao, :))
         end do
      end if
      xadj = xadj+0.5_wp*matmul(dadj, conjg(transpose(overlap)))
      raw_spin = raw_spin &
         & +0.5_wp*matmul(conjg(transpose(xmat)), dadj) &
         & +matmul(xadj, conjg(transpose(density(:, :, spin))))
      raw = raw+raw_spin
   end do

   overlap_adjoint = overlap_adjoint &
      & +0.5_wp*(raw+conjg(transpose(raw)))/stream%weights(ik)
   stream%reverse_pulled(ik) = .true.
end subroutine cp2k_exchange_stream_reverse_batch_pull


!> Reuse bounded reverse storage for the next image batch.
subroutine cp2k_exchange_stream_reverse_batch_advance(stream, done, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   logical, intent(out) :: done
   type(error_type), allocatable, intent(out) :: error

   done = .false.
   if (.not.stream%active .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse transaction is not active")
      return
   end if
   if (.not.stream%reverse_batch_applied) then
      call fatal_error(error, "g-xTB exchange reverse batch was not applied")
      return
   end if
   if (stream%partial_pull_distribution_set) then
      if (any(stream%reverse_pulled .neqv. stream%partial_pull_mask)) then
         call fatal_error(error, &
            & "g-xTB exchange reverse batch violates pull ownership")
         return
      end if
   else
      if (.not.all(stream%reverse_pulled)) then
         call fatal_error(error, &
            & "g-xTB exchange reverse batch has missing pulls")
         return
      end if
   end if
   if (stream%batch_first+stream%batch_count > stream%batch_last) then
      stream%reverse_applied = .true.
      if (stream%partial_pull_distribution_set &
         & .and. .not.stream%partial_result_owner) &
         & stream%reverse_result_pulled = .true.
      done = .true.
      return
   end if

   stream%batch_first = stream%batch_first+stream%batch_count
   stream%batch_count = min(stream%batch_size, &
      & stream%batch_last-stream%batch_first+1)
   stream%seen = .false.
   stream%reverse_pulled = .false.
   stream%reverse_batch_applied = .false.
   if (stream%partial_active) then
      stream%partial_generation = stream%partial_generation+1
      stream%partial_reverse_exported = .false.
      stream%partial_reverse_imported = .false.
   end if
   stream%amat_r = (0.0_wp, 0.0_wp)
   stream%cmat_r = (0.0_wp, 0.0_wp)
   stream%vmat_r = (0.0_wp, 0.0_wp)
   stream%amat_partner_r = (0.0_wp, 0.0_wp)
   stream%reverse_amat_r = (0.0_wp, 0.0_wp)
   stream%reverse_vmat_r = (0.0_wp, 0.0_wp)
   stream%gdiagP = (0.0_wp, 0.0_wp)
   stream%gdiagSP = (0.0_wp, 0.0_wp)
   stream%gdiagSPS = (0.0_wp, 0.0_wp)
   stream%reverse_bdiagSP = (0.0_wp, 0.0_wp)
   stream%reverse_bdiagSPS = (0.0_wp, 0.0_wp)
end subroutine cp2k_exchange_stream_reverse_batch_advance


!> Return accumulated force and positive-strain responses exactly once.
subroutine cp2k_exchange_stream_reverse_result(stream, calc, mol, ecache, &
   & gradient, sigma, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(in) :: ecache
   real(wp), intent(out) :: gradient(:, :), sigma(:, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active .or. .not.stream%reverse_transaction) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse transaction is not active")
      return
   end if
   if (.not.stream%reverse_applied) then
      call fatal_error(error, "g-xTB exchange stream reverse is incomplete")
      return
   end if
   if (stream%reverse_result_pulled) then
      call fatal_error(error, "g-xTB exchange reverse result was already pulled")
      return
   end if
   if (size(gradient, 1) /= 3 .or. size(gradient, 2) /= mol%nat &
      & .or. size(sigma, 1) /= 3 .or. size(sigma, 2) /= 3) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange reverse-result dimensions")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange reverse state was invalidated before result")
      return
   end if
   gradient = stream%reverse_gradient
   sigma = stream%reverse_sigma
   stream%reverse_result_pulled = .true.
end subroutine cp2k_exchange_stream_reverse_result


!> Close a successfully applied exchange stream and release all storage.
subroutine cp2k_exchange_stream_end(stream, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (.not.stream%applied) then
      call clear_exchange_stream(stream)
      call fatal_error(error, &
         & "g-xTB exchange stream ended before successful apply")
      return
   end if
   if (stream%mode == cp2k_exchange_stream_batched &
      & .and. .not.stream%batch_result_pulled) then
      call clear_exchange_stream(stream)
      call fatal_error(error, &
         & "g-xTB exchange stream ended with missing batch result")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_batched &
      & .and. .not.all(stream%forward_pulled)) then
      call clear_exchange_stream(stream)
      call fatal_error(error, &
         & "g-xTB exchange stream ended with missing forward pulls")
      return
   end if
   if (stream%reverse_transaction .and. .not.stream%reverse_applied) then
      call clear_exchange_stream(stream)
      call fatal_error(error, &
         & "g-xTB exchange stream ended before reverse completion")
      return
   end if
   if (stream%reverse_transaction .and. &
      & .not.stream%reverse_result_pulled) then
      call clear_exchange_stream(stream)
      call fatal_error(error, &
         & "g-xTB exchange stream ended with missing reverse result")
      return
   end if
   if (stream%reverse_applied) then
      if (stream%partial_pull_distribution_set) then
         if (any(stream%reverse_pulled .neqv. &
            & stream%partial_pull_mask)) then
            call clear_exchange_stream(stream)
            call fatal_error(error, &
               & "g-xTB exchange stream ended with invalid owned reverse pulls")
            return
         end if
      else if (.not.all(stream%reverse_pulled)) then
         call clear_exchange_stream(stream)
         call fatal_error(error, &
            & "g-xTB exchange stream ended with missing reverse pulls")
         return
      end if
   end if
   call clear_exchange_stream(stream)
end subroutine cp2k_exchange_stream_end


!> Differentiate BvK-supercell-equivalent exchange on a complete k mesh.
!>
!> The overlap response is spin-summed, Hermitian, and unweighted:
!> ``dE = sum_k w_k Re sum_ij conjg(overlap_grad_ij(k))*dS_ij(k)``.
!> Atomic and positive homogeneous-strain derivatives already contain the
!> complete primitive-cell Brillouin-zone contraction and must not be weighted
!> again by CP2K.  The strain response has no inverse-volume factor.
subroutine cp2k_exchange_kmesh_gradient(calc, mol, ecache, nmesh, kfrac, &
   & weights, density, overlap, overlap_grad, gradient, sigma, error, &
   & transform_backend)
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   integer, intent(in) :: nmesh(3)
   real(wp), intent(in) :: kfrac(:, :), weights(:)
   complex(wp), intent(in) :: density(:, :, :, :), overlap(:, :, :)
   complex(wp), intent(out) :: overlap_grad(:, :, :)
   real(wp), intent(out) :: gradient(:, :), sigma(:, :)
   type(error_type), allocatable, intent(out) :: error
   integer, intent(in), optional :: transform_backend

   integer :: backend, idim, nk
   real(wp), allocatable :: bocorr_grad_r(:, :, :), &
      & mulliken_grad_r(:, :, :)

   gradient = 0.0_wp
   sigma = 0.0_wp
   overlap_grad = (0.0_wp, 0.0_wp)
   backend = bvk_transform_dense
   if (present(transform_backend)) backend = transform_backend
   if (backend /= bvk_transform_dense .and. &
      & backend /= bvk_transform_separable_dft) then
      call fatal_error(error, "unknown g-xTB k-to-R transform backend")
      return
   end if
   nk = size(weights)

   if (.not.allocated(calc%exchange)) then
      call fatal_error(error, "g-xTB exchange container is not allocated")
      return
   end if
   if (.not.allocated(ecache%raw)) then
      call fatal_error(error, &
         & "k-point exchange cache is not prepared; call cp2k_prepare_exchange")
      return
   end if
   if (any(nmesh < 1) .or. product(nmesh) /= nk) then
      call fatal_error(error, "g-xTB exchange requires a complete regular k mesh")
      return
   end if
   do idim = 1, 3
      if (.not.mol%periodic(idim) .and. nmesh(idim) /= 1) then
         call fatal_error(error, &
            & "nonperiodic directions cannot be replicated by the g-xTB k mesh")
         return
      end if
   end do
   if (size(kfrac, 1) /= 3 .or. size(kfrac, 2) /= nk &
      & .or. size(overlap, 3) /= nk .or. size(overlap_grad, 3) /= nk &
      & .or. size(density, 4) /= nk) then
      call fatal_error(error, &
         & "inconsistent g-xTB whole-mesh gradient array dimensions")
      return
   end if
   if (.not.all(ieee_is_finite(kfrac))) then
      call fatal_error(error, "g-xTB whole-mesh k points must be finite")
      return
   end if
   if (.not.all(ieee_is_finite(weights)) .or. &
      & abs(sum(weights)-1.0_wp) > 1.0e-12_wp &
      & .or. maxval(abs(weights-1.0_wp/real(nk, wp))) > 1.0e-12_wp) then
      call fatal_error(error, "g-xTB whole-mesh exchange requires uniform weights")
      return
   end if
   if (backend == bvk_transform_separable_dft .and. &
      & maxval(abs(weights-1.0_wp/real(nk, wp))) > &
      & 64.0_wp*epsilon(1.0_wp)) then
      call fatal_error(error, &
         & "separable-DFT g-xTB exchange requires machine-uniform weights")
      return
   end if

   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         if (size(overlap, 1) /= exchange%nao &
            & .or. size(overlap, 2) /= exchange%nao &
            & .or. size(overlap_grad, 1) /= exchange%nao &
            & .or. size(overlap_grad, 2) /= exchange%nao &
            & .or. size(density, 1) /= exchange%nao &
            & .or. size(density, 2) /= exchange%nao &
            & .or. (size(density, 3) /= 1 .and. size(density, 3) /= 2) &
            & .or. size(gradient, 1) /= 3 &
            & .or. size(gradient, 2) /= mol%nat &
            & .or. size(sigma, 1) /= 3 .or. size(sigma, 2) /= 3) then
            call fatal_error(error, &
               & "inconsistent g-xTB whole-mesh gradient AO or atom dimensions")
            return
         end if

         call prepare_bvk_plan(exchange, mol, cache, nmesh, kfrac, weights, &
            & error, retain_dense_phases=backend == bvk_transform_dense)
         if (allocated(error)) return
         if (backend == bvk_transform_separable_dft .and. &
            & .not.machine_regular_bvk_plan(cache, nmesh, kfrac)) then
            call fatal_error(error, &
               & "separable-DFT g-xTB exchange requires a machine-regular grid")
            return
         end if

         allocate(mulliken_grad_r(exchange%nao, exchange%nao, nk), &
            & bocorr_grad_r(exchange%nao, exchange%nao, nk))
         call exchange%get_KGrad_kmesh(mol, cache, cache%bvk_kernel, &
            & kfrac, weights, density, overlap, overlap_grad, &
            & mulliken_grad_r, bocorr_grad_r, backend)
         call exchange%get_bvk_Kmatrix_derivs(mol, cache%bvk_kernel, &
            & mulliken_grad_r, &
            & bocorr_grad_r, gradient, sigma)
      class default
         call fatal_error(error, &
            & "whole-mesh exchange gradient requires exchange_fock")
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
   end select

end subroutine cp2k_exchange_kmesh_gradient


!> Apply the exact complete-mesh reverse exchange evaluator once.
!>
!> This transition is legal only after the forward stream was applied.  The
!> complete primitive-cell atomic and positive-strain derivatives are returned
!> directly exactly once.  The unweighted overlap adjoints remain in the
!> stream and must subsequently be pulled blockwise with `reverse_get`.
subroutine cp2k_exchange_stream_reverse_apply(stream, calc, mol, ecache, &
   & gradient, sigma, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   real(wp), intent(out) :: gradient(:, :), sigma(:, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (.not.stream%applied) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse requires forward apply")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_oracle) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse requires oracle mode")
      return
   end if
   if (stream%reverse_applied) then
      call fatal_error(error, "g-xTB exchange stream reverse was already applied")
      return
   end if
   if (size(gradient, 1) /= 3 .or. size(gradient, 2) /= mol%nat &
      & .or. size(sigma, 1) /= 3 .or. size(sigma, 2) /= 3) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream reverse dimensions")
      return
   end if
   if (.not.allocated(calc%exchange) .or. .not.allocated(ecache%raw)) then
      call fatal_error(error, &
         & "g-xTB exchange stream state was invalidated before reverse apply")
      return
   end if
   if (.not.exchange_stream_state_matches(stream, calc, mol, ecache)) then
      call fatal_error(error, &
         & "g-xTB exchange stream state was invalidated before reverse apply")
      return
   end if

   call cp2k_exchange_kmesh_gradient(calc, mol, ecache, stream%nmesh, &
      & stream%kfrac, stream%weights, stream%density, stream%overlap, &
      & stream%overlap_adjoint, gradient, sigma, error)
   if (allocated(error)) return
   stream%reverse_pulled = .false.
   stream%reverse_applied = .true.
end subroutine cp2k_exchange_stream_reverse_apply


!> Pull one unweighted overlap-adjoint block from the reverse stream.
subroutine cp2k_exchange_stream_reverse_get(stream, ik, overlap_adjoint, error)
   type(cp2k_exchange_stream_type), intent(inout) :: stream
   integer, intent(in) :: ik
   complex(wp), intent(out) :: overlap_adjoint(:, :)
   type(error_type), allocatable, intent(out) :: error

   if (.not.stream%active) then
      call fatal_error(error, "g-xTB exchange stream is not active")
      return
   end if
   if (stream%mode /= cp2k_exchange_stream_oracle) then
      call fatal_error(error, &
         & "blockwise streamed reverse requires reverse-batch pull")
      return
   end if
   if (.not.stream%reverse_applied) then
      call fatal_error(error, "g-xTB exchange stream reverse was not applied")
      return
   end if
   if (ik < 1 .or. ik > stream%nk) then
      call fatal_error(error, &
         & "g-xTB exchange stream reverse block index is out of range")
      return
   end if
   if (stream%reverse_pulled(ik)) then
      call fatal_error(error, "duplicate g-xTB exchange stream reverse pull")
      return
   end if
   if (size(overlap_adjoint, 1) /= stream%nao &
      & .or. size(overlap_adjoint, 2) /= stream%nao) then
      call fatal_error(error, &
         & "inconsistent g-xTB exchange stream overlap-adjoint dimensions")
      return
   end if

   overlap_adjoint = stream%overlap_adjoint(:, :, ik)
   stream%reverse_pulled(ik) = .true.
end subroutine cp2k_exchange_stream_reverse_get


!> Differentiate the g-xTB exchange functional for one complex k-point block.
!>
!> All returned quantities are unweighted.  For a reduced mesh the external
!> driver must expand `gradient` and `sigma` over the complete k star.  The
!> complex Hermitian `overlap_grad` transforms like a density matrix and is
!> intended to be folded to real-space overlap images by the same weighted
!> star transform as an ordinary k-point density.
subroutine cp2k_exchange_kpoint_gradient(calc, mol, ecache, density, overlap, &
   & overlap_grad, gradient, sigma, error)
   type(xtb_calculator), intent(in) :: calc
   type(structure_type), intent(in) :: mol
   type(container_cache), intent(inout) :: ecache
   complex(wp), intent(in) :: density(:, :, :), overlap(:, :)
   complex(wp), intent(out) :: overlap_grad(:, :)
   real(wp), intent(out) :: gradient(:, :), sigma(:, :)
   type(error_type), allocatable, intent(out) :: error

   real(wp), allocatable :: mulliken_grad(:, :), bocorr_grad(:, :)

   gradient = 0.0_wp
   sigma = 0.0_wp
   overlap_grad = (0.0_wp, 0.0_wp)
   if (.not. allocated(calc%exchange)) then
      call fatal_error(error, "g-xTB exchange container is not allocated")
      return
   end if
   if (.not. allocated(ecache%raw)) then
      call fatal_error(error, &
         & "k-point exchange cache is not prepared; call cp2k_prepare_exchange")
      return
   end if

   select type (cache => ecache%raw)
   type is (exchange_cache)
      select type (exchange => calc%exchange)
      type is (exchange_fock)
         allocate(mulliken_grad(exchange%nao, exchange%nao), &
            & bocorr_grad(exchange%nao, exchange%nao))
         call exchange%get_KGrad_kpoint(mol, cache, density, overlap, &
            & mulliken_grad, bocorr_grad, overlap_grad)
         call exchange%get_mulliken_derivs_direct(mol, cache, mulliken_grad, &
            & gradient, sigma)
         call exchange%get_bocorr_derivs_direct(mol, cache, bocorr_grad, &
            & gradient, sigma)
      class default
         call fatal_error(error, &
            & "k-point exchange gradient requires the exchange_fock implementation")
      end select
   class default
      call fatal_error(error, "unexpected g-xTB exchange cache type")
   end select
end subroutine cp2k_exchange_kpoint_gradient

!> Complete Gamma-point H0/ACP/exchange and q-vSZP response for CP2K.
subroutine cp2k_gamma_gradient(calc, mol, bcache, acache, ecache, wfn_aux, &
   & accuracy, selfenergy, dsedcn, overlap, pot, wfn, wdensity, gradient, sigma)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   type(acp_cache), intent(inout) :: acache
   type(container_cache), intent(inout) :: ecache
   type(wavefunction_type), intent(in) :: wfn_aux
   real(wp), intent(in) :: accuracy
   real(wp), intent(in) :: selfenergy(:), dsedcn(:), overlap(:, :)
   type(potential_type), intent(in) :: pot
   type(wavefunction_type), intent(inout) :: wfn
   real(wp), intent(inout) :: wdensity(:, :, :)
   real(wp), intent(out) :: gradient(:, :), sigma(:, :)

   real(wp) :: cutoff
   real(wp), allocatable :: aniso_dip(:, :), cn(:), dcndr(:, :, :), dcndL(:, :, :)
   real(wp), allocatable :: dEdcn(:), dEdad(:, :), dEdcnbas(:), dEdqbas(:)
   real(wp), allocatable :: h1(:, :, :), lattr(:, :)
   type(adjacency_list) :: list
   type(integral_type) :: ints
   type(potential_type) :: pot_work

   gradient = 0.0_wp
   sigma = 0.0_wp
   allocate(aniso_dip(3, mol%nat), dEdcn(mol%nat), dEdad(3, mol%nat), &
      & dEdcnbas(mol%nat), dEdqbas(mol%nat), source=0.0_wp)

   cutoff = cp2k_get_acp_cutoff(calc, accuracy)
   call get_lattice_points(mol%periodic, mol%lattice, cutoff, lattr)
   call new_adjacency_list(list, mol, lattr, cutoff)
   if (any(mol%periodic)) then
      call get_anisotropy(calc%h0, mol, lattr, list, aniso_dip)
   else
      call get_anisotropy(calc%h0, mol, aniso_dip)
   end if

   ! CP2K constructs the potential contribution to its KS matrix directly.
   ! The native gradient kernel additionally expects the atom/shell shifts
   ! spread to pot%vao.  Prepare that representation on a private copy so the
   ! persistent CP2K potential is neither changed nor accumulated twice.
   pot_work = pot
   call new_integral(ints, size(overlap, 1))
   ints%overlap = overlap
   allocate(h1(size(overlap, 1), size(overlap, 2), wfn%nspin))
   call add_pot_to_h1(calc%bas, ints, pot_work, h1)

   if (allocated(calc%ncoord)) then
      allocate(cn(mol%nat), dcndr(3, mol%nat, mol%nat), dcndL(3, 3, mol%nat))
      call calc%ncoord%get_cn(mol, cn, dcndr, dcndL)
   end if

   if (allocated(calc%exchange)) then
      call calc%exchange%get_gradient_w_overlap(mol, ecache, wfn, overlap, &
         & wdensity(:, :, 1), gradient, sigma)
   end if

   if (allocated(calc%acp)) then
      call get_acp_gradient(mol, lattr, list, calc%bas, bcache, calc%acp, acache, &
         & wfn, dEdcnbas, dEdqbas, gradient, sigma)
   end if

   call updown_to_magnet(wfn%density)
   call updown_to_magnet(wdensity)
   call get_hamiltonian_gradient(mol, lattr, list, calc%bas, bcache, calc%h0, &
      & selfenergy, dsedcn, aniso_dip, pot_work, wfn%density, wdensity, dEdcn, dEdad, &
      & dEdcnbas, dEdqbas, gradient, sigma)
   call magnet_to_updown(wfn%density)

   if (allocated(dcndr)) call gemv(dcndr, dEdcn, gradient, beta=1.0_wp)
   if (allocated(dcndL)) call gemv(dcndL, dEdcn, sigma, beta=1.0_wp)

   call cp2k_apply_basis_gradient(calc, mol, wfn_aux, dEdcnbas, dEdqbas, &
      & gradient, sigma)

   if (any(mol%periodic)) then
      call get_anisotropy_gradient(calc%h0, mol, lattr, list, dEdad, gradient, sigma)
   else
      call get_anisotropy_gradient(calc%h0, mol, dEdad, gradient, sigma)
   end if
end subroutine cp2k_gamma_gradient


!> Image-resolved H0/Pulay and q-vSZP response for CP2K.
!>
!> `translations` must be the exact translation list used to construct the
!> supplied real-space matrices.  Their layout is
!> `(nao,nao,ntranslation,nspin)`.  CP2K supplies the spin channels in
!> up/down representation; this wrapper converts private copies to tblite's
!> charge--magnetization convention before the contraction.  The matrices
!> must satisfy P(R)^T=P(-R) and W(R)^T=W(-R).
!>
!> This routine deliberately contains only the one-electron H0, overlap
!> (Pulay), CN, anisotropy, and charge-dependent q-vSZP basis response.  ACP
!> and exchange image responses are independent contributions and must be
!> added by their respective CP2K bridges.
subroutine cp2k_image_h0_gradient(calc, mol, bcache, wfn_aux, accuracy, &
   & translations, selfenergy, dsedcn, overlap_gamma, pot, density_images, &
   & wdensity_images, gradient, sigma)
   type(xtb_calculator), intent(inout) :: calc
   type(structure_type), intent(in) :: mol
   type(basis_cache), intent(in) :: bcache
   type(wavefunction_type), intent(in) :: wfn_aux
   real(wp), intent(in) :: accuracy
   real(wp), intent(in) :: translations(:, :)
   real(wp), intent(in) :: selfenergy(:), dsedcn(:), overlap_gamma(:, :)
   type(potential_type), intent(in) :: pot
   real(wp), intent(in) :: density_images(:, :, :, :)
   real(wp), intent(in) :: wdensity_images(:, :, :, :)
   real(wp), intent(out) :: gradient(:, :), sigma(:, :)

   real(wp) :: cutoff
   real(wp), allocatable :: aniso_dip(:, :), cn(:), dcndr(:, :, :), dcndL(:, :, :)
   real(wp), allocatable :: dEdcn(:), dEdad(:, :), dEdcnbas(:), dEdqbas(:), dEdq(:)
   real(wp), allocatable :: h1(:, :, :), density_work(:, :, :, :), &
      & wdensity_work(:, :, :, :)
   type(adjacency_list) :: list
   type(integral_type) :: ints
   type(potential_type) :: pot_work

   gradient = 0.0_wp
   sigma = 0.0_wp
   allocate(aniso_dip(3, mol%nat), dEdcn(mol%nat), dEdad(3, mol%nat), &
      & dEdcnbas(mol%nat), dEdqbas(mol%nat), dEdq(mol%nat), source=0.0_wp)

   cutoff = get_cutoff(calc%bas, accuracy)
   call new_adjacency_list(list, mol, translations, cutoff)
   if (any(mol%periodic)) then
      call get_anisotropy(calc%h0, mol, translations, list, aniso_dip)
   else
      call get_anisotropy(calc%h0, mol, aniso_dip)
   end if

   ! Match the Gamma bridge: spread the atom/shell shifts to AO potentials on
   ! a private copy, without changing CP2K's persistent potential object.
   pot_work = pot
   call new_integral(ints, size(overlap_gamma, 1))
   ints%overlap = overlap_gamma
   allocate(h1(size(overlap_gamma, 1), size(overlap_gamma, 2), &
      & size(density_images, 4)))
   call add_pot_to_h1(calc%bas, ints, pot_work, h1)

   if (allocated(calc%ncoord)) then
      allocate(cn(mol%nat), dcndr(3, mol%nat, mol%nat), dcndL(3, 3, mol%nat))
      call calc%ncoord%get_cn(mol, cn, dcndr, dcndL)
   end if

   density_work = density_images
   wdensity_work = wdensity_images
   call updown_to_magnet(density_work)
   call updown_to_magnet(wdensity_work)
   call get_hamiltonian_gradient(mol, translations, list, calc%bas, bcache, &
      & calc%h0, selfenergy, dsedcn, aniso_dip, pot_work, density_work, &
      & wdensity_work, dEdcn, dEdad, dEdcnbas, dEdqbas, gradient, sigma)

   if (allocated(dcndr)) call gemv(dcndr, dEdcn, gradient, beta=1.0_wp)
   if (allocated(dcndL)) call gemv(dcndL, dEdcn, sigma, beta=1.0_wp)

   if (calc%bas%charge_dependent) then
      call calc%bas%get_basis_gradient(mol, dEdcnbas, dEdqbas, dEdq, gradient, sigma)
   end if

   if (allocated(wfn_aux%dqatdr)) then
      call gemv(wfn_aux%dqatdr(:, :, :, 1), dEdq, gradient, beta=1.0_wp)
   end if
   if (allocated(wfn_aux%dqatdL)) then
      call gemv(wfn_aux%dqatdL(:, :, :, 1), dEdq, sigma, beta=1.0_wp)
   end if

   if (any(mol%periodic)) then
      call get_anisotropy_gradient(calc%h0, mol, translations, list, dEdad, &
         & gradient, sigma)
   else
      call get_anisotropy_gradient(calc%h0, mol, dEdad, gradient, sigma)
   end if
end subroutine cp2k_image_h0_gradient

!> Extract one effective CGTO in the representation expected by CP2K.
subroutine cp2k_get_cgto(bas, cache, ish, izp, iat, ang, nprim, alpha, coeff)
   class(basis_type), intent(in) :: bas
   type(basis_cache), intent(in) :: cache
   integer, intent(in) :: ish, izp, iat
   integer, intent(out) :: ang, nprim
   real(wp), intent(out) :: alpha(:), coeff(:)

   associate(cgto => bas%cgto(ish, izp)%raw)
      ang = cgto%ang
      nprim = cgto%nprim
      alpha = 0.0_wp
      coeff = 0.0_wp
      alpha(:nprim) = cgto%alpha(:nprim)
      call cgto%get_coeffs(cache%cgto(ish, iat), coeff(:nprim))
   end associate
end subroutine cp2k_get_cgto

!> Evaluate multipole integrals with save_tblite's explicit basis cache.
pure subroutine cp2k_multipole_cgto(bas, cache, jsh, jzp, jat, ish, izp, iat, &
   & r2, vec, overlap, dpint, qpint)
   class(basis_type), intent(in) :: bas
   type(basis_cache), intent(in) :: cache
   integer, intent(in) :: jsh, jzp, jat, ish, izp, iat
   real(wp), intent(in) :: r2, vec(3)
   real(wp), intent(out) :: overlap(*), dpint(3, *), qpint(6, *)

   call multipole_cgto(bas%cgto(jsh, jzp)%raw, bas%cgto(ish, izp)%raw, &
      & cache%cgto(jsh, jat), cache%cgto(ish, iat), r2, vec, bas%intcut, &
      & overlap, dpint, qpint)
end subroutine cp2k_multipole_cgto

!> Evaluate multipole derivatives with save_tblite's explicit basis cache.
pure subroutine cp2k_multipole_grad_cgto(bas, cache, jsh, jzp, jat, ish, izp, iat, &
   & r2, vec, overlap, dpint, qpint, doverlap, ddpintj, dqpintj, ddpinti, dqpinti)
   class(basis_type), intent(in) :: bas
   type(basis_cache), intent(in) :: cache
   integer, intent(in) :: jsh, jzp, jat, ish, izp, iat
   real(wp), intent(in) :: r2, vec(3)
   real(wp), intent(out) :: overlap(*), dpint(3, *), qpint(6, *)
   real(wp), intent(out) :: doverlap(3, *)
   real(wp), intent(out) :: ddpintj(3, 3, *), dqpintj(3, 6, *)
   real(wp), intent(out) :: ddpinti(3, 3, *), dqpinti(3, 6, *)

   call multipole_grad_cgto(bas%cgto(jsh, jzp)%raw, bas%cgto(ish, izp)%raw, &
      & cache%cgto(jsh, jat), cache%cgto(ish, iat), r2, vec, bas%intcut, &
      & overlap, dpint, qpint, doverlap, ddpintj, dqpintj, ddpinti, dqpinti)
end subroutine cp2k_multipole_grad_cgto

end module tblite_cp2k_compat
